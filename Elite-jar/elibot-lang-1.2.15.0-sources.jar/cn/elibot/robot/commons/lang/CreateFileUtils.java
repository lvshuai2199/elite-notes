package cn.elibot.robot.commons.lang;

import java.io.File;
import java.io.IOException;

/**
 * @author Qinshan Qin
 */
public class CreateFileUtils {

    public static boolean createFile(String destFileName) {
        File file = new File(destFileName);
        if (file.exists()) {
            return true;
        }

        if (destFileName.endsWith(File.separator)) {
            return false;
        }

        if (!file.getParentFile().exists()) {
            if (!file.getParentFile().mkdirs()) {
                return false;
            }
        }

        try {
            return file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean createDir(String destDirName) {
        String dirName = destDirName;
        if (!dirName.endsWith(File.separator)) {
            dirName = dirName + File.separator;
        }

        File dir = new File(dirName);
        if (dir.exists()) {
            return false;
        }

        return dir.mkdirs();
    }

    public static String createTempFile(String prefix, String suffix, String dirName) {
        File tempFile = null;
        if (dirName == null) {
            try {
                tempFile = File.createTempFile(prefix, suffix);
                return tempFile.getCanonicalPath();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            File dir = new File(dirName);
            if (!dir.exists()) {
                if (!CreateFileUtils.createDir(dirName)) {
                    return null;
                }
            }
            try {
                tempFile = File.createTempFile(prefix, suffix, dir);
                return tempFile.getCanonicalPath();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}

