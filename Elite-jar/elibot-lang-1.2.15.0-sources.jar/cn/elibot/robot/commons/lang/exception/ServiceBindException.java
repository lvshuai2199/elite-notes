package cn.elibot.robot.commons.lang.exception;

/**
 * Represents the service binding exception
 *
 * @author elt
 */
public class ServiceBindException extends RuntimeException {
    public <T> ServiceBindException(Class<T> serviceInterface) {
        super("Already bound '" + serviceInterface + "' from a different ClassLoader. Class defined twice in different bundles?");
    }
}
