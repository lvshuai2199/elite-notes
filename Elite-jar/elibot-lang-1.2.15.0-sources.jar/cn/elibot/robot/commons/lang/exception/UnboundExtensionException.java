package cn.elibot.robot.commons.lang.exception;

/**
 * Unbound extension exception
 *
 * @author elt
 */
public class UnboundExtensionException extends Exception {
    public UnboundExtensionException(Object extension) {
        super("Failed to bind extension point " + extension.getClass());
    }
}
