package cn.elibot.robot.commons.lang;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wyk
 */
public class CSVUtils {
    /**
     * 写CSV文件
     *
     * @param fileName   csv文件名称
     * @param fileHeader 文件头
     * @param content    内容
     */
    public static void write(final String fileName, final String[] fileHeader, List<String[]> content) {
        File file = new File(fileName);
        write(file, fileHeader, content);
    }

    /**
     * 写CSV文件
     *
     * @param file       csv文件
     * @param fileHeader 文件头
     * @param content    内容
     */
    public static void write(final File file, final String[] fileHeader, List<String[]> content) {
        if (null == file || !file.exists()) {
            return;
        }
        try {
            Appendable fileWriter = new FileWriter(file);
            CSVPrinter printer = CSVFormat.RFC4180.withHeader(fileHeader).print(fileWriter);
            for (String[] strings : content) {
                printer.printRecord((Object) strings);
            }
            printer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 读CSV文件
     *
     * @param fileName   csv文件名称
     */
    public static Iterable<CSVRecord> read(String fileName) {
        File file = new File(fileName);
        return read(file);
    }

    /**
     * 读CSV文件
     *
     * @param file       csv文件
     */
    public static Iterable<CSVRecord> read(File file) {
        if (null == file || !file.exists()) {
            return null;
        }
        Iterable<CSVRecord> records;
        try {
            Reader fileReader = new FileReader(file);
            records = CSVFormat.RFC4180.withFirstRecordAsHeader().parse(fileReader);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return records;
    }

    /**
     * 读CSV文件头
     *
     * @param fileName 文件名
     */
    public static Map<String, Integer> readFileHeader(String fileName) {
        File file = new File(fileName);
        return readFileHeader(file);
    }


    public static Map<String, Integer> readFileHeader(File file) {
        Map<String, Integer> headerMap = new HashMap<>();
        if (null == file || !file.exists()) {
            return headerMap;
        }
        try {
            Reader fileReader = new FileReader(file);
            headerMap = CSVFormat.RFC4180.withFirstRecordAsHeader().parse(fileReader).getHeaderMap();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return headerMap;
    }
}