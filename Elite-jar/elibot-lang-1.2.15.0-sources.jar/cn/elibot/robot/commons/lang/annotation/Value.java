package cn.elibot.robot.commons.lang.annotation;

import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * The value of the resource
 *
 * @author elt
 */
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface Value {
}
