package cn.elibot.robot.commons.lang.commandline;

import cn.elibot.robot.commons.lang.IOUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Script resources
 *
 * @author elt
 */
public class ScriptResource {
    private List<String> theArgs = new ArrayList<>();
    private String script;

    public ScriptResource(String name) throws IOException {
        this.loadScript(name);
    }

    public ScriptResource(String name, ArrayList<String> args) throws IOException {
        this.loadScript(name);
        this.theArgs = args;
    }

    private void loadScript(String name) throws IOException {
        Objects.requireNonNull(name, "Script name cannot be empty or null");

        InputStream resource = this.getClass().getResourceAsStream("/resources/scripts/" + name);
        if (resource == null) {
            throw new IOException("Script \"" + name + "\" is not found.");
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(resource));
        try {
            StringBuilder builder = new StringBuilder();
            for (String line = br.readLine(); line != null; line = br.readLine()) {
                builder.append(line).append("\n");
            }

            this.script = builder.toString();
        } finally {
            IOUtils.closeQuietly(br);
        }
    }

    public String getScript() {
        return this.script;
    }

    public List<String> getArgs() {
        return this.theArgs;
    }

    public void addArgument(int argument) {
        this.theArgs.add((new Integer(argument)).toString());
    }

    public void addArgument(String argument) {
        this.theArgs.add(argument);
    }

    @Override
    public String toString() {
        return this.theArgs.toString() + "\n" + this.script + "\n";
    }
}
