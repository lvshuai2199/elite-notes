package cn.elibot.robot.commons.lang.commandline;

import java.io.PrintStream;

/**
 * Represents script listener
 *
 * @author elt
 */
public interface ScriptListener {
    /**
     * Handle standard command line
     *
     * @param line   the command line
     * @param output the output stream
     */
    void onStdLine(String line, PrintStream output);

    /**
     * Handle error command line
     *
     * @param line   the command line
     * @param output the output stream
     */
    void onErrLine(String line, PrintStream output);

    /**
     * Handle command complete
     *
     * @param code the code of command execution
     */
    void onComplete(int code);
}
