package cn.elibot.robot.commons.lang.commandline;

import cn.elibot.robot.commons.lang.FileUtils;

import java.io.PrintStream;

/**
 * Bash script runner
 *
 * @author elt
 */
public class BashScriptRunner extends BaseScriptRunner {
    public BashScriptRunner(String script) {
        String filename = this.randomFileNameToAvoidConflicts();
        this.prepareScriptExecution(script, filename, "/bin/bash " + filename, System.out, System.err);
    }

    public BashScriptRunner(String script, PrintStream opw) {
        String filename = this.randomFileNameToAvoidConflicts();
        this.prepareScriptExecution(script, filename, "/bin/bash " + filename, opw, opw);
    }

    public BashScriptRunner(String script, PrintStream opw, PrintStream epw) {
        String filename = this.randomFileNameToAvoidConflicts();
        this.prepareScriptExecution(script, filename, "/bin/bash " + filename, opw, epw);
    }

    public BashScriptRunner(ScriptResource script) {
        String filename = this.randomFileNameToAvoidConflicts();
        this.prepareScriptExecution(script, filename, "/bin/bash " + filename, System.out, System.err);
    }

    private String randomFileNameToAvoidConflicts() {
        return "/tmp/" + FileUtils.getRandomFilename("sh");
    }
}
