package cn.elibot.robot.commons.lang.commandline;

import cn.elibot.robot.commons.lang.StringUtils;
import cn.elibot.robot.commons.lang.WaitUtils;
import cn.elibot.robot.commons.lang.thread.ThreadPoolUtils;
import cn.elibot.robot.logger.LogFactory;
import cn.elibot.robot.logger.Logger;

import java.io.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/**
 * Script runner base class
 */
public abstract class BaseScriptRunner implements Runnable {
    private static final Logger LOG = LogFactory.getLogger(BaseScriptRunner.class);

    private String errorString = "";
    private boolean hasRun = false;
    private String outputString = "";
    private int result;
    private String theCommand = "";
    private PrintStream theErrorStream;
    private String theFileOfScript = "";
    private PrintStream theOutputStream;
    private String theScript = "";
    private String allString = "";
    private final CopyOnWriteArrayList<ScriptListener> listeners = new CopyOnWriteArrayList<>();
    private List<String> theArgs = new ArrayList<>();
    private final Map<String, String> theEnvMap = new HashMap<>();

    protected File buildScript(String script, String filename) throws IOException {
        File fl = new File(filename);
        boolean ok = fl.createNewFile();
        if (ok) {
            PrintStream ps = new PrintStream(fl);
            ps.println(script);
            ps.close();

            return fl;
        }

        return null;
    }

    public String getAllString() {
        if (!this.hasRun) {
            throw new RuntimeException("run() was not called");
        } else {
            return this.allString;
        }
    }

    public String getErrorString() {
        if (!this.hasRun) {
            throw new RuntimeException("run() was not called");
        } else {
            return this.errorString;
        }
    }

    public String getOutputString() {
        if (!this.hasRun) {
            throw new RuntimeException("run() was not called");
        } else {
            return this.outputString;
        }
    }

    public int getReturnVal() {
        if (!this.hasRun) {
            throw new RuntimeException("run() was not called");
        } else {
            return this.result;
        }
    }

    public void addEnvVar(String var, String value) {
        this.theEnvMap.put(var, value);
    }

    protected void prepareScriptExecution(String script, String fileOfScript, String command, PrintStream outStream,
                                          PrintStream errStream) {
        this.theScript = script;
        this.theFileOfScript = fileOfScript;
        this.theCommand = command;
        this.theOutputStream = outStream;
        this.theErrorStream = errStream;
        this.hasRun = false;
    }

    protected void prepareScriptExecution(ScriptResource script, String fileOfScript, String command,
                                          PrintStream outStream, PrintStream errStream) {
        this.theScript = script.getScript();
        this.theArgs = script.getArgs();
        this.theFileOfScript = fileOfScript;
        this.theCommand = command;
        this.theOutputStream = outStream;
        this.theErrorStream = errStream;
        this.hasRun = false;
    }

    public synchronized void execute() throws IOException {
        this.execute(0, TimeUnit.SECONDS);
    }

    public synchronized void execute(int timeLimit, TimeUnit unit) throws IOException {
        File scriptFile = null;
        Process ps = null;
        File workingDir = new File("/tmp/");
        try {
            scriptFile = this.buildScript(this.theScript, this.theFileOfScript);

            String args = StringUtils.joinStringsWith(" ", this.theArgs);
            this.theCommand += " " + args;

            if (!this.theEnvMap.isEmpty()) {
                Map<String, String> parentEnv = System.getenv();
                String[] myEnv = new String[parentEnv.size() + this.theEnvMap.size()];
                Arrays.fill(myEnv, "");

                int index = 0;
                for (String key : parentEnv.keySet()) {
                    if (index >= myEnv.length) {
                        if (LOG.isDebugEnabled()) {
                            LOG.debug("WARNING: Index out of bounds copying the parent environment");
                            LOG.debug("I will run the process (" + this.theCommand + ") anyway");
                        }

                        break;
                    }
                    myEnv[index++] = key + "=" + parentEnv.get(key);
                }

                for (String key : theEnvMap.keySet()) {
                    if (index >= myEnv.length) {
                        if (LOG.isDebugEnabled()) {
                            LOG.debug("WARNING: Index out of bounds copying extra environment variables");
                            LOG.debug("I will run the process (" + this.theCommand + ") anyway");
                        }
                        break;
                    }
                    myEnv[index++] = key + "=" + theEnvMap.get(key);
                }

                ps = Runtime.getRuntime().exec(this.theCommand, myEnv, workingDir);
            } else {
                ps = Runtime.getRuntime().exec(this.theCommand, null, workingDir);
            }

            this.result = this.waitFor(ps, this.theOutputStream, this.theErrorStream, timeLimit, unit);
        } catch (Exception e) {
            System.err.println("Fail to execute script.");
        } finally {
            if (ps != null) {
                ps.destroy();
            }

            if (scriptFile != null) {
                boolean ignored = scriptFile.delete();
            }

            this.fireOnComplete();
            this.hasRun = true;
        }
    }

    public void executeBackground() {
        Executor executor = ThreadPoolUtils.newSingleThreadExecutor("execute_bash_thread");
        executor.execute(this);
    }

    protected int waitFor(Process proc, PrintStream opw, PrintStream epw, int timeLimit, TimeUnit unit) {
        long timeout = 0L;
        if (timeLimit > 0) {
            timeout = System.currentTimeMillis() + unit.toMillis(timeLimit);
        }

        while (true) {
            try {
                BufferedReader eReader = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
                BufferedReader aReader = new BufferedReader(new InputStreamReader(proc.getInputStream()));

                PrintStream input;
                String line;
                for (input = new PrintStream(proc.getOutputStream()); eReader.ready(); this.fireOnErrLine(line, input)) {
                    line = eReader.readLine();
                    this.errorString = this.errorString + line;
                    this.allString = this.allString + line;
                    if (epw != null) {
                        epw.println(line);
                    }
                }

                for (; aReader.ready(); this.fireOnStdLine(line, input)) {
                    line = aReader.readLine();
                    this.outputString = this.outputString + line + "\n";
                    this.allString = this.allString + line + "\n";
                    if (opw != null) {
                        opw.println(line);
                    }
                }

                try {
                    return proc.exitValue();
                } catch (IllegalThreadStateException exception) {
                    if (timeout > 0L && System.currentTimeMillis() > timeout) {
                        return -101;
                    }
                }
                WaitUtils.pause(10, TimeUnit.MILLISECONDS);
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        }
    }

    protected void fireOnStdLine(String line, PrintStream output) {
        this.listeners.forEach(scriptListener -> scriptListener.onStdLine(line, output));
    }

    protected void fireOnComplete() {
        this.listeners.forEach(scriptListener -> scriptListener.onComplete(this.result));
    }

    protected void fireOnErrLine(String line, PrintStream output) {
        this.listeners.forEach(scriptListener -> scriptListener.onErrLine(line, output));
    }

    public void addScriptListener(ScriptListener listener) {
        this.listeners.add(listener);
    }

    public void remScriptListener(ScriptListener listener) {
        this.listeners.remove(listener);
    }

    @Override
    public void run() {
        try {
            this.execute();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

    @Override
    public String toString() {
        return "Script: " + this.theScript + ", Args: " + this.theArgs + ", Command: " + this.theCommand;
    }
}
