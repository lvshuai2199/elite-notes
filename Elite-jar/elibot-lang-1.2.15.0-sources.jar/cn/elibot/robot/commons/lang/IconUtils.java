package cn.elibot.robot.commons.lang;

import cn.elibot.robot.commons.lang.swing.ThemeUtils;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 * Utility methods for loading, scaling, coloring, and graying icons.
 *
 * <p>Icons are loaded from the default {@code ICON_DEFAULT_PATH} under the user's home
 * directory. Provides methods to get {@link Icon} or {@link ImageIcon} instances
 * with optional color tinting and scaling, as well as partial gray-out effects.
 *
 * @author ELITECO SDK API
 */
public class IconUtils {
    /**
     * Default file-system path under {@code user.home/resource/icons/} where icons are stored.
     */
    private static final String ICON_DEFAULT_PATH =
        System.getProperty("user.home") + File.separator + "resource" + File.separator + "icons" + File.separator;

    /**
     * Standard size for main navigation icons, in pixels.
     */
    public static int ICON_SIZE_NAV_MAIN = 38;

    /**
     * Standard size for operation-bar icons, in pixels.
     */
    public static int ICON_SIZE_OPERATION_BAR = 38;

    /**
     * Standard size for status-bar icons, in pixels.
     */
    public static int ICON_SIZE_STATUS_BAR = 18;

    /**
     * Standard size for sub-menu icons, in pixels.
     */
    public static int ICON_SIZE_SUB_MENU = 22;

    /**
     * Standard size for tree-view icons, in pixels.
     */
    public static int ICON_SIZE_TREE_ICON = 16;

    /**
     * Default black color for icon tinting.
     */
    public static Color ICON_COLOR_BLACK = new Color(74, 74, 74);

    /**
     * Default white color for icon tinting (from {@link ThemeUtils#WHITE}).
     */
    public static Color ICON_COLOR_WHITE = ThemeUtils.WHITE;

    /**
     * Default gray color for icon tinting.
     */
    public static Color ICON_COLOR_GRAY = new Color(128, 128, 128);

    /**
     * Default green color for icon tinting.
     */
    public static Color ICON_COLOR_GREEN = new Color(14, 209, 69);

    /**
     * Default blue color for icon tinting (from {@link ThemeUtils#BLUE}).
     */
    public static Color ICON_COLOR_BLUE = ThemeUtils.BLUE;

    /**
     * Primary blue color for icon tinting (from {@link ThemeUtils#PRIMARY_BLUE}).
     */
    public static Color ICON_COLOR_PRIMARY_BLUE = ThemeUtils.PRIMARY_BLUE;

    /**
     * Default red color for icon tinting.
     */
    public static Color ICON_COLOR_RED = new Color(225, 27, 27);

    /**
     * Default yellow color for icon tinting.
     */
    public static Color ICON_COLOR_YELLOW = new Color(223, 207, 9);

    /**
     * Loads an icon by name from the default path, applies a color tint, and scales to the given height.
     *
     * @param iconName the filename of the icon (including extension)
     * @param color    the tint color to apply
     * @param height   the desired icon height, in pixels
     * @return a tinted and scaled {@link Icon}
     */
    public static Icon getIcon(String iconName, Color color, double height) {
        return ImageUtils.changeColorAndScale(new ImageIcon(ICON_DEFAULT_PATH + iconName), color, height);
    }

    /**
     * Loads an icon by name from the default path and scales it to the given height.
     *
     * @param iconName the filename of the icon (including extension)
     * @param height   the desired icon height, in pixels
     * @return a scaled {@link Icon}
     */
    public static Icon getIcon(String iconName, double height) {
        return ImageUtils.scaleIcon(new ImageIcon(ICON_DEFAULT_PATH + iconName), height);
    }

    /**
     * Loads an icon by name from the default path without modifications.
     *
     * @param iconName the filename of the icon (including extension)
     * @return the raw {@link Icon}
     */
    public static Icon getIcon(String iconName) {
        return new ImageIcon(ICON_DEFAULT_PATH + iconName);
    }

    /**
     * Applies a color tint to an existing {@link Icon}.
     *
     * @param icon  the original icon
     * @param color the tint color
     * @return a tinted {@link Icon}
     */
    public static Icon colorIcon(Icon icon, Color color) {
        return ImageUtils.changeIconColor(icon, color);
    }

    /**
     * Loads an image icon by name, applies a color tint, and scales to the given height.
     *
     * @param iconName the filename of the icon (including extension)
     * @param color    the tint color to apply
     * @param height   the desired icon height, in pixels
     * @return a tinted and scaled {@link ImageIcon}
     */
    public static ImageIcon getImageIcon(String iconName, Color color, double height) {
        return ImageUtils.changeColorAndScale(new ImageIcon(ICON_DEFAULT_PATH + iconName), color, height);
    }

    /**
     * Loads an image icon by name and scales it to the given height.
     *
     * @param iconName the filename of the icon (including extension)
     * @param height   the desired icon height, in pixels
     * @return a scaled {@link ImageIcon}
     */
    public static ImageIcon getImageIcon(String iconName, double height) {
        return ImageUtils.scaleIcon(new ImageIcon(ICON_DEFAULT_PATH + iconName), height);
    }

    /**
     * Loads an image icon by name without modifications.
     *
     * @param iconName the filename of the icon (including extension)
     * @return the raw {@link ImageIcon}
     */
    public static ImageIcon getImageIcon(String iconName) {
        return new ImageIcon(ICON_DEFAULT_PATH + iconName);
    }

    /**
     * Applies a color tint to an existing {@link ImageIcon}.
     *
     * @param icon  the original image icon
     * @param color the tint color
     * @return a tinted {@link ImageIcon}
     */
    public static ImageIcon colorIcon(ImageIcon icon, Color color) {
        return ImageUtils.changeIconColor(icon, color);
    }

    /**
     * Applies a partial gray-out effect to an {@link Icon}.
     *
     * <p>If the icon is not an {@code ImageIcon} or {@code amount <= 0}, returns the original icon.
     * Otherwise, produces a new {@link ImageIcon} where each pixel is blended toward its grayscale
     * value by the specified amount.
     *
     * @param icon   the original icon (must be an {@code ImageIcon} to process)
     * @param amount gray-out intensity in [0,1]; 0 = no change, 1 = full grayscale
     * @return a new grayed {@link Icon}, or the original if unprocessable
     * @since ELITECO SDK 1.2.14.0
     */
    public static Icon grayedIcon(Icon icon, float amount) {
        if (!(icon instanceof ImageIcon) || amount <= 0f) {
            return icon;
        }
        amount = Math.min(1f, Math.max(0f, amount));
        Image srcImg = ((ImageIcon) icon).getImage();
        int w = srcImg.getWidth(null);
        int h = srcImg.getHeight(null);
        if (w < 0 || h < 0) {
            return icon;
        }

        BufferedImage buf = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = buf.createGraphics();
        g2.drawImage(srcImg, 0, 0, null);
        g2.dispose();

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int argb = buf.getRGB(x, y);
                int newArgb = getArgb(amount, argb);
                buf.setRGB(x, y, newArgb);
            }
        }

        return new ImageIcon(buf);
    }

    /**
     * Computes a blended ARGB value toward grayscale based on the given amount.
     *
     * @param amount blend factor in [0,1]
     * @param argb   original ARGB pixel
     * @return new ARGB pixel blended toward grayscale
     */
    private static int getArgb(float amount, int argb) {
        int a = (argb >> 24) & 0xFF;
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        int gray = (int) (0.299 * r + 0.587 * g + 0.114 * b);

        int nr = (int) (r * (1 - amount) + gray * amount);
        int ng = (int) (g * (1 - amount) + gray * amount);
        int nb = (int) (b * (1 - amount) + gray * amount);

        return (a << 24) | (clamp(nr) << 16) | (clamp(ng) << 8) | clamp(nb);
    }

    /**
     * Clamps an integer value to the [0,255] range.
     *
     * @param v value to clamp
     * @return clamped value
     */
    private static int clamp(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }
}
