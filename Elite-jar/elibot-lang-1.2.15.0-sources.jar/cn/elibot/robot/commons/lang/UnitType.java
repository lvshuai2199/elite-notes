package cn.elibot.robot.commons.lang;

/**
 * Unit Type
 *
 * @author elt
 */
public enum UnitType {
    /**
     * Metric
     */
    METRIC,

    /**
     * Imperial
     */
    IMPERIAL;

    public static UnitType DEFAULT_TYPE = METRIC;

    public static UnitType getUnitType(String unitTypeStr) {
        return (UnitType) PrimitiveUtils.parseEnum(unitTypeStr, UnitType.class, METRIC);
    }

    public boolean isImperial() {
        return this == IMPERIAL;
    }
}
