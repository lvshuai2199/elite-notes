package cn.elibot.robot.commons.lang;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/**
 * Utility class providing methods to interact with the system properties,
 * execute commands, and perform file and system level synchronization.
 * This is particularly tailored to check if the system is a specific type of
 * robot control system running a real-time Linux variant.
 *
 * @author ELITECO SDK API
 */
public class SystemUtils {
    public static final String BASH;
    private static int isRobot = -1;

    static {
        if (SystemUtils.checkSystemIsLinux()) {
            BASH = "/bin/bash";
        } else {
            BASH = "C:\\Program Files\\Git\\bin\\bash.exe";
        }
    }

    /**
     * Checks if the operating system is Linux.
     *
     * @return true if the operating system is Linux, false otherwise.
     */
    public static boolean checkSystemIsLinux() {
        String name = System.getProperty("os.name").toLowerCase();
        return name.contains("linux");
    }

    /**
     * Determines if the current system is a real-time robot control system.
     * This checks for the "preempt-rt" string in the kernel name.
     *
     * @return true if the system is a robot control system, false otherwise.
     * This value is cached after the first check.
     */
    public static boolean isRobot() {
        if (isRobot == -1) {
            boolean ret = false;
            String isRealRobot = System.getenv("IS_REAL_ROBOT");
            if ("TRUE".equals(isRealRobot)) {
                ret = true;
            }
            isRobot = ret ? 1 : 0;
            return ret;
        } else {
            return isRobot != 0;
        }
    }

    /**
     * Forces synchronization of all file system buffers to disk using the 'sync' command.
     * This method only works on Linux systems.
     */
    public static void Sync() {
        try {
            if (!SystemUtils.checkSystemIsLinux()) {
                return;
            }
            Process process = Runtime.getRuntime().exec("sync");
            process.waitFor(5, TimeUnit.SECONDS);
        } catch (Exception ignored) {
        }
    }

    /**
     * Forces synchronization of the specific file's buffers to disk.
     *
     * @param file the file to be synchronized.
     * @since ELITECO SDK 1.2.13.0
     */
    public static void Sync(File file) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            fileOutputStream.getFD().sync();
            fileOutputStream.close();
        } catch (Exception ignored) {
        }
    }

    /**
     * Executes a system command and waits for completion.
     *
     * @param cmd the system command to execute.
     */
    public static void execute(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[] {BASH, "-c", cmd});
            p.waitFor(10000, TimeUnit.MILLISECONDS);
        } catch (Exception ignored) {
        }
    }

    /**
     * Internal helper method to get a BufferedReader for reading the output of a shell command.
     *
     * @param cmd the command to execute.
     * @return a BufferedReader for the command's output.
     * @throws IOException, InterruptedException if an error occurs during command execution.
     */
    private static BufferedReader getInputReader(String cmd) throws IOException, InterruptedException {
        Process p = Runtime.getRuntime().exec(new String[] {BASH, "-c", cmd});
        p.waitFor(3000, TimeUnit.MILLISECONDS);
        InputStream inputStream = p.getInputStream();
        InputStreamReader reader = new InputStreamReader(inputStream);
        return new BufferedReader(reader);
    }
}
