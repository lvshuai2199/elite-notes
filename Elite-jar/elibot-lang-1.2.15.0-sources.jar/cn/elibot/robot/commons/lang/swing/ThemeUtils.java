package cn.elibot.robot.commons.lang.swing;

import javax.swing.plaf.ColorUIResource;
import java.awt.Color;

/**
 * The {@code ThemeUtils} class serves as a central utility class for defining and managing consistent color resources used
 * throughout the application.
 * It provides a collection of {@link ColorUIResource} objects that can be used to maintain a unified look and feel across
 * various UI components.
 *
 * <p>This class simplifies the application-wide management of UI themes, enabling easy adjustments and ensuring that UI elements
 * are uniformly styled.
 * Colors are organized into a series of constants that can be applied to backgrounds, text, borders, and other interface
 * elements to enhance user experience and interface clarity.</p>
 *
 * <p>Utilizing this centralized approach for theme management helps facilitate changes to the application's visual design and
 * can support dynamic theming capabilities if required.</p>
 *
 * @author ELITECO SDK API
 */
public class ThemeUtils {
    public static final ColorUIResource BLUE = new ColorUIResource(86, 160, 211);
    public static final ColorUIResource LIGHT_BLUE = new ColorUIResource(165, 220, 240);
    public static final ColorUIResource PRIMARY_BLUE = new ColorUIResource(55, 190, 240);
    public static final ColorUIResource LIGHT_GRAY = new ColorUIResource(202, 202, 202);
    public static final ColorUIResource DARK_GRAY = new ColorUIResource(180, 180, 180);
    public static final ColorUIResource WHITE = new ColorUIResource(245, 245, 245);
    public static final ColorUIResource LIGHT_WHITE = new ColorUIResource(240, 240, 240);
    public static final ColorUIResource RED = new ColorUIResource(255, 77, 79);
    public static final ColorUIResource DARK = new ColorUIResource(Color.BLACK);
    public static final ColorUIResource EXTRA_DARK_GRAY = new ColorUIResource(93, 93, 93);
    public static final ColorUIResource DARK_SHADOW = new ColorUIResource(120, 120, 120);
    public static final ColorUIResource BORDER_GRAY = new ColorUIResource(217, 217, 217);
    public static final ColorUIResource SELECT_BLUE = new ColorUIResource(new Color(55, 190, 255, 64));
    public static final ColorUIResource SELECT_BLUE_EX = new ColorUIResource(55, 190, 255);
    public static final ColorUIResource DISABLE_WHITE = new ColorUIResource(230, 230, 230);
    public static final ColorUIResource FONT_BLUE_COLOR = new ColorUIResource(10, 179, 241);
    public static final ColorUIResource FAVORITE_YELLOW = new ColorUIResource(255, 178, 5);
    public static final ColorUIResource NORMAL_FONT_COLOR = new ColorUIResource(52, 52, 52);
    public static final ColorUIResource MAIN_MENU_COLOR = new ColorUIResource(34, 39, 115);
    public static final ColorUIResource INFO_COLOR = ThemeUtils.PRIMARY_BLUE;
    public static final ColorUIResource INFO_BACKGROUND_COLOR = new ColorUIResource(230, 247, 255);
    public static final ColorUIResource ERROR_COLOR = new ColorUIResource(255, 163, 158);
    public static final ColorUIResource ERROR_BACKGROUND_COLOR = new ColorUIResource(253, 227, 226);
    public static final ColorUIResource WARNING_COLOR = new ColorUIResource(255, 229, 143);

    public static final ColorUIResource WARNING_BACKGROUND_COLOR = new ColorUIResource(255, 251, 230);
    public static final ColorUIResource SUCCESS_COLOR = new ColorUIResource(183, 235, 143);
    public static final ColorUIResource SUCCESS_BACKGROUND_COLOR = new ColorUIResource(230, 249, 210);

    public static final ColorUIResource FRAME_RED = new ColorUIResource(255, 150, 150);
    public static final ColorUIResource FRAME_GREEN = new ColorUIResource(90, 220, 110);
    public static final ColorUIResource FRAME_BLUE = new ColorUIResource(50, 190, 240);
}
