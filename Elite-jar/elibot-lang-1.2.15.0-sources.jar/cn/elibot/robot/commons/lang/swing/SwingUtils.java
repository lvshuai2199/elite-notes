package cn.elibot.robot.commons.lang.swing;

import cn.elibot.robot.logger.LogFactory;
import cn.elibot.robot.logger.Logger;
import com.google.common.collect.Lists;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;

/**
 * Static utility methods pertaining to {@code SwingUtils} instances.
 *
 * @author elt
 */
public class SwingUtils {
    private static final Logger LOG = LogFactory.getLogger(SwingUtils.class);

    private SwingUtils() {
    }

    public static boolean isUiOrEventThread() {
        return SwingUtilities.isEventDispatchThread() || Thread.currentThread().getName().startsWith("AWT-EventQueue-");
    }

    public static <T> FutureTask<T> invokeLater(Callable<T> callable) {
        FutureTask<T> task = new FutureTask<>(callable);
        SwingUtilities.invokeLater(task);

        return task;
    }

    public static <T> T invokeAndWaitForAnswer(Callable<T> callable) {
        return invokeAndWaitForAnswer(new FutureTask<>(callable), null);
    }

    public static <T> T invokeAndWaitForAnswer(FutureTask<T> request, T defaultValue) {
        invokeAndWait(request);

        try {
            return request.get(5L, TimeUnit.SECONDS);
        } catch (InterruptedException exception) {
            LOG.warn("Execution was interrupted: ", exception);
        } catch (ExecutionException exception) {
            LOG.warn("Failed to execute task: ", exception);
        } catch (TimeoutException ignored) {
        }

        return defaultValue;
    }

    public static void invokeAndWait(Runnable run) {
        if (isUiOrEventThread()) {
            run.run();
        } else {
            try {
                SwingUtilities.invokeAndWait(run);
            } catch (Exception ex) {
                throw new InvocationInterruptedException(ex);
            }
        }

    }

    public static FutureTask<Runnable> invokeLater(Runnable runnable) {
        FutureTask<Runnable> task = new FutureTask<>(runnable, runnable);
        SwingUtilities.invokeLater(task);

        return task;
    }

    private static boolean isSupportedType(Object object, Class<?>... componentTypes) {
        Objects.requireNonNull(componentTypes);

        return Arrays.stream(componentTypes)
                .anyMatch(type -> type.isInstance(object));
    }

    public static int getComponentIndex(Container container, Component component) {
        Component[] components = container.getComponents();

        for (int i = 0; i < components.length; ++i) {
            if (components[i].equals(component)) {
                return i;
            }
        }

        return -1;
    }

    public static List<Component> getAllComponents(Container parentContainer, Class<?>... componentTypes) {
        Objects.requireNonNull(parentContainer);
        Objects.requireNonNull(componentTypes);

        List<Component> result = Lists.newArrayList();
        Arrays.stream(parentContainer.getComponents())
                .filter(component -> {
                    if (componentTypes.length == 0 || isSupportedType(component, componentTypes)) {
                        return true;
                    }

                    return component instanceof Container;
                })
                .forEach(result::add);

        return result;
    }

    public static Component createFlowPanel(JComponent... components) {
        JPanel result = new JPanel();
        result.setLayout(new FlowLayout());
        for (JComponent component : components) {
            result.add(component);
        }

        return result;
    }

    public static JFrame getFrame(Component component) {
        return getContainerOfType(JFrame.class, component);
    }

    @SuppressWarnings("unchecked")
    public static <T> T getContainerOfType(Class<T> clazz, Component component) {
        while (true) {
            if (!clazz.isInstance(component)) {
                component = component.getParent();
                if (component != null) {
                    continue;
                }
            }

            return clazz.isInstance(component) ? (T) component : null;
        }
    }

    @SuppressWarnings("unchecked")
    public static <T extends JComponent> T getComponentByName(Class<T> clazz, JComponent fromNode, String name) {
        List<Component> components = getAllComponents(fromNode, clazz);
        for (Component component : components) {
            if (component.getName().equals(name)) {
                return (T) component;
            }
        }

        return null;
    }

    public static void setEnabledRecursive(Container container, boolean enable, List<Component> componentsToggled, String... exceptions) {
        List<String> exceptionsList = Arrays.asList(exceptions);
        toggleComponent(container, enable, componentsToggled, exceptionsList);
        setEnabledChildren(container, enable, componentsToggled, exceptionsList);
    }

    private static void setEnabledChildren(Container container, boolean enable, List<Component> componentsToggled, List<String> exceptions) {
        for (Component component : container.getComponents()) {
            toggleComponent(component, enable, componentsToggled, exceptions);
            if (component instanceof Container) {
                setEnabledChildren((Container) component, enable, componentsToggled, exceptions);
            }
        }
    }

    private static void toggleComponent(Component component, boolean enable, List<Component> componentsToggled, List<String> exceptions) {
        if (component.isEnabled() != enable && !exceptions.contains(component.getName())) {
            component.setEnabled(enable);
            if (!componentsToggled.contains(component)) {
                componentsToggled.add(component);
            }
        }
    }

    public static void setEnabledComponents(List<Component> components, boolean enable) {
        components.forEach(component -> component.setEnabled(enable));
    }

    /**
     * Invocation interrupted exception
     */
    public static class InvocationInterruptedException extends RuntimeException {
        public InvocationInterruptedException(Exception e) {
            super(e);
        }
    }
}
