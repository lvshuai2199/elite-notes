package cn.elibot.robot.commons.lang.swing;

import java.awt.*;

/**
 * The {@code GridBagConstraintsFactory} class simplifies the creation and management of
 * {@link GridBagConstraints} for use with {@link GridBagLayout}. This factory allows for easy
 * configuration and reuse of common layout constraints.
 *
 * <p>
 * Example usage:
 * <pre>{@code
 * JPanel panel = new JPanel();
 * panel.setLayout(new GridBagLayout());
 *
 * GridBagConstraintsFactory factory = new GridBagConstraintsFactory();
 * factory.setDefaultInsets(new Insets(0, 0, 0, 0));
 * panel.add(createComponent(), factory.createCollapsing(0, 0, 1, 1));
 * panel.add(createAnotherComponent(), factory.createCollapsing(0, 1, 1, 1));
 * panel.add(Box.createGlue(), factory.createExpanding(0, 2, 1, 1));
 * }</pre>
 * </p>
 *
 * @author ELITECO SDK API
 * @see GridBagConstraints
 * @see GridBagLayout
 * @since ELITECO SDK 1.2.13.0
 */
public class GridBagConstraintsFactory {
    private int defaultWidthX = 1;
    private int defaultWidthY = 1;
    private int defaultAnchor = GridBagConstraints.NORTHWEST;
    private int defaultFill = GridBagConstraints.BOTH;
    private Insets defaultInsets = new Insets(2, 2, 2, 2);
    private int defaultPadX = 0;
    private int defaultPadY = 0;

    /**
     * Constructs a new {@code GridBagConstraintsFactory} with default settings.
     */
    public GridBagConstraintsFactory() {
    }

    /**
     * Sets the default anchor and fill for the factory.
     *
     * @param anchor the anchor value
     * @param fill   the fill value
     */
    public void setAnchorAndFill(int anchor, int fill) {
        this.setDefaultAnchor(anchor);
        this.setDefaultFill(fill);
    }

    /**
     * Sets the default insets to zero.
     */
    public void setNoInsets() {
        this.setDefaultInsets(new Insets(0, 0, 0, 0));
    }

    /**
     * Sets the default padding.
     *
     * @param padX the horizontal padding
     * @param padY the vertical padding
     */
    public void setPadding(int padX, int padY) {
        this.setDefaultPadX(padX);
        this.setDefaultPadY(padY);
    }

    /**
     * Sets the default anchor.
     *
     * @param defaultAnchor the anchor value
     */
    public void setDefaultAnchor(int defaultAnchor) {
        this.defaultAnchor = defaultAnchor;
    }

    /**
     * Sets the default fill.
     *
     * @param defaultFill the fill value
     */
    public void setDefaultFill(int defaultFill) {
        this.defaultFill = defaultFill;
    }

    /**
     * Sets the default insets.
     *
     * @param defaultInsets the insets value
     */
    public void setDefaultInsets(Insets defaultInsets) {
        this.defaultInsets = defaultInsets;
    }

    /**
     * Sets the default horizontal padding.
     *
     * @param defaultPadX the horizontal padding value
     */
    public void setDefaultPadX(int defaultPadX) {
        this.defaultPadX = defaultPadX;
    }

    /**
     * Sets the default vertical padding.
     *
     * @param defaultPadY the vertical padding value
     */
    public void setDefaultPadY(int defaultPadY) {
        this.defaultPadY = defaultPadY;
    }

    /**
     * Sets the default horizontal width.
     *
     * @param defaultWidthX the width value
     */
    public void setDefaultWidthX(int defaultWidthX) {
        this.defaultWidthX = defaultWidthX;
    }

    /**
     * Sets the default vertical width.
     *
     * @param defaultWidthY the width value
     */
    public void setDefaultWidthY(int defaultWidthY) {
        this.defaultWidthY = defaultWidthY;
    }

    /**
     * Creates a {@link GridBagConstraints} with default settings and expands in both directions.
     *
     * @param x the gridX value
     * @param y the gridY value
     * @return a new {@link GridBagConstraints} instance
     */
    public GridBagConstraints createExpanding(int x, int y) {
        return this.createExpanding(x, y, this.defaultWidthX, this.defaultWidthY);
    }

    /**
     * Creates a {@link GridBagConstraints} with specified width and expands in both directions.
     *
     * @param x      the gridX value
     * @param y      the gridY value
     * @param widthX the gridWidth value
     * @param widthy the gridHeight value
     * @return a new {@link GridBagConstraints} instance
     */
    public GridBagConstraints createExpanding(int x, int y, int widthX, int widthy) {
        return this.create(x, y, widthX, widthy, 1.0D, 1.0D);
    }

    /**
     * Creates a {@link GridBagConstraints} with specified width and expands horizontally.
     *
     * @param x      the gridX value
     * @param y      the gridY value
     * @param widthX the gridWidth value
     * @param widthY the gridHeight value
     * @return a new {@link GridBagConstraints} instance
     */
    public GridBagConstraints createExpandingHorizontal(int x, int y, int widthX, int widthY) {
        return this.create(x, y, widthX, widthY, 1.0D, 0.0D);
    }

    /**
     * Creates a {@link GridBagConstraints} with specified width and expands vertically.
     *
     * @param x      the gridX value
     * @param y      the gridY value
     * @param widthX the gridWidth value
     * @param widthY the gridHeight value
     * @return a new {@link GridBagConstraints} instance
     */
    public GridBagConstraints createExpandingVertical(int x, int y, int widthX, int widthY) {
        return this.create(x, y, widthX, widthY, 0.0D, 1.0D);
    }

    /**
     * Creates a {@link GridBagConstraints} with default settings and collapses in both directions.
     *
     * @param x the gridX value
     * @param y the gridY value
     * @return a new {@link GridBagConstraints} instance
     */
    public GridBagConstraints createCollapsing(int x, int y) {
        return this.createCollapsing(x, y, this.defaultWidthX, this.defaultWidthY);
    }

    /**
     * Creates a {@link GridBagConstraints} with specified width and collapses in both directions.
     *
     * @param x      the gridX value
     * @param y      the gridY value
     * @param widthX the gridWidth value
     * @param widthY the gridHeight value
     * @return a new {@link GridBagConstraints} instance
     */
    public GridBagConstraints createCollapsing(int x, int y, int widthX, int widthY) {
        return this.create(x, y, widthX, widthY, 0.0D, 0.0D);
    }

    /**
     * Creates a {@link GridBagConstraints} with specified weight.
     *
     * @param x       the gridX value
     * @param y       the gridY value
     * @param weightX the weightX value
     * @param weightY the weightY value
     * @return a new {@link GridBagConstraints} instance
     */
    public GridBagConstraints create(int x, int y, double weightX, double weightY) {
        return this.create(x, y, this.defaultWidthX, this.defaultWidthY, weightX, weightY);
    }

    /**
     * Creates a {@link GridBagConstraints} with specified parameters.
     *
     * @param x       the gridX value
     * @param y       the gridY value
     * @param widthX  the gridWidth value
     * @param widthY  the gridHeight value
     * @param weightX the weightX value
     * @param weightY the weightY value
     * @return a new {@link GridBagConstraints} instance
     */
    public GridBagConstraints create(int x, int y, int widthX, int widthY, double weightX, double weightY) {
        return new GridBagConstraints(x, y, widthX, widthY, weightX, weightY, this.defaultAnchor, this.defaultFill, this.defaultInsets, this.defaultPadX, this.defaultPadY);
    }
}
