package cn.elibot.robot.commons.lang.swing;

import cn.elibot.robot.commons.lang.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.examples.HtmlToPlainText;

import javax.swing.text.html.HTML.Tag;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.net.URL;
import java.text.Format;
import java.util.Arrays;
import java.util.Iterator;
import java.util.regex.Pattern;

/**
 * Utility class for creating and formatting HTML content.
 * This class provides methods for various HTML tags and styles, and is intended to simplify the generation of HTML strings.
 *
 * @author ELITECO SDK API
 */
public class HtmlUtils {
    public static final String PADDING_TOP_STR = "padding-top";
    public static final String PADDING_LEFT_STR = "padding-left";
    public static final String PADDING_BOTTOM_STR = "padding-bottom";
    public static final String PADDING_RIGHT_STR = "padding-right";
    public static final String SPACE_STR = "&nbsp;";
    public static final String ALIGN_RIGHT_STR = "align='right'";
    public static final String FONT_LABEL_STR = "<font %s=%s>%s</font>";
    private static final String TAG_START_STR = "\\<\\w+((\\s+\\w+(\\s*\\=\\s*(?:\".*?\"|'.*?'|[^'\"\\>\\s]+))?)+\\s*|\\s*)\\>";
    private static final String TAG_END_STR = "\\</\\w+\\>";
    private static final String TAG_SELF_CLOSING_STR = "\\<\\w+((\\s+\\w+(\\s*\\=\\s*(?:\".*?\"|'.*?'|[^'\"\\>\\s]+))?)" + "+\\s" + "*|\\s*)/\\>";
    private static final String HTML_ENTITY_STR = "&[a-zA-Z][a-zA-Z0-9]+;";
    private static final Pattern HTML_PATTERN = Pattern.compile("(<\\w+((\\s+\\w+(\\s*=\\s*(?:\".*?\"|'.*?'|[^'\">\\s]+))?)+\\s*|\\s*)>.*</\\w+>)|(<\\w+((\\s+\\w+(\\s*=\\s*(?:\"" + ".*?\"|'.*?'|[^'\">\\s]+))?)+\\s*|\\s*)/>)|(&[a-zA-Z][a-zA-Z0-9]+;)", Pattern.DOTALL);
    private static final Font ARIEL_FONT = FontUtils.NORMAL_FONT;

    /**
     * Default constructor.
     */
    public HtmlUtils() {
    }

    /**
     * Wraps the provided content in an HTML tag.
     *
     * @param page the content to be wrapped
     * @return the content wrapped in an HTML tag
     */
    public static String html(String page) {
        return wrapTag(Tag.HTML.toString(), page, true);
    }

    /**
     * Converts the given content to HTML with the specified font and option to use font size.
     *
     * @param font        the font to be used
     * @param page        the content to be converted
     * @param useFontSize whether to include font size in the style
     * @return the HTML formatted string
     * @since ELITECO SDK 1.2.13.0
     */
//    public static String toHtml(Font font, String page, boolean useFontSize) {
//        return html(useFontSize ? fontType(font, page) : fontTypeWithoutSize(font, page));
//    }

    public static String toHtml(Font font, String page, boolean useFontSize) {
        String content = useFontSize ? fontType(font, page) : fontTypeWithoutSize(font, page);

        content = content.replace("<p ", "<p style=\"word-wrap: break-word; overflow-wrap: break-word;\" ");

        return html(content);
    }

    /**
     * Converts the given content to HTML with the specified font.
     *
     * @param font the font to be used
     * @param page the content to be converted
     * @return the HTML formatted string
     * @since ELITECO SDK 1.2.13.0
     */
    public static String toHtml(Font font, String page) {
        return toHtml(font, page, true);
    }

    /**
     * Converts the given content to HTML with the option to bold the text.
     *
     * @param page   the content to be converted
     * @param isBold whether the text should be bold
     * @return the HTML formatted string
     * @since ELITECO SDK 1.2.13.0
     */
    public static String toHtml(String page, boolean isBold) {
        return toHtml(isBold ? FontUtils.NORMAL_BOLD_FONT : FontUtils.NORMAL_FONT, page, false);
    }

    /**
     * Converts the given content to HTML.
     *
     * @param page the content to be converted
     * @return the HTML formatted string
     * @since ELITECO SDK 1.2.13.0
     */
    public static String toHtml(String page) {
        return toHtml(page, false);
    }

    /**
     * Wraps the provided content in a BODY tag.
     *
     * @param page the content to be wrapped
     * @return the content wrapped in a BODY tag
     */
    public static String body(String page) {
        return wrapTag(Tag.BODY.toString(), page, true);
    }

    /**
     * Wraps the provided content in a PRE tag.
     *
     * @param page the content to be wrapped
     * @return the content wrapped in a PRE tag
     */
    public static String pre(String page) {
        return wrapTag(Tag.PRE.toString(), page, true);
    }

    /**
     * Returns a space HTML entity.
     *
     * @return the space HTML entity
     */
    public static String space() {
        return SPACE_STR;
    }

    /**
     * Wraps the provided content in a FORM tag.
     *
     * @param content the content to be wrapped
     * @return the content wrapped in a FORM tag
     */
    public static String form(String content) {
        return wrapTag(Tag.FORM.toString(), content);
    }

    /**
     * Wraps the provided text in a LABEL tag.
     * This method is useful for associating text with form controls in HTML.
     *
     * @param text the text to be wrapped
     * @return the text wrapped in a LABEL tag
     */
    public static String label(String text) {
        return wrapTag("label", text);
    }

    /**
     * Creates a SELECT tag with the given ID.
     *
     * @param id the ID of the select element
     * @return the HTML string for the SELECT element
     */
    public static String selector(String id) {
        return "<select id=\"" + id + "\" />";
    }

    /**
     * Wraps the provided content in an H1 tag.
     *
     * @param text the content to be wrapped
     * @return the content wrapped in an H1 tag
     */
    public static String h1(String text) {
        return wrapTag("h1", text);
    }

    /**
     * Wraps the provided content in an H2 tag.
     *
     * @param text the content to be wrapped
     * @return the content wrapped in an H2 tag
     */
    public static String h2(String text) {
        return wrapTag("h2", text);
    }

    /**
     * Wraps the provided content in an H3 tag.
     *
     * @param text the content to be wrapped
     * @return the content wrapped in an H3 tag
     */
    public static String h3(String text) {
        return wrapTag("h3", text);
    }

    /**
     * Wraps the provided content in a B (bold) tag.
     *
     * @param text the content to be wrapped
     * @return the content wrapped in a B tag
     */
    public static String fontBold(String text) {
        return wrapTag("b", text);
    }

    /**
     * Wraps the provided content in an I (italic) tag.
     *
     * @param text the content to be wrapped
     * @return the content wrapped in an I tag
     */
    public static String fontItalic(String text) {
        return wrapTag("i", text);
    }

    /**
     * Wraps the provided content in a CENTER tag.
     *
     * @param content the content to be wrapped
     * @return the content wrapped in a CENTER tag
     */
    public static String center(String content) {
        return wrapTag("center", content);
    }

    /**
     * Creates an IMG tag with the given alignment and URL.
     *
     * @param alignment   the alignment of the image
     * @param urlToSource the URL of the image source
     * @return the HTML string for the IMG element
     */
    public static String image(HtmlUtils.Align alignment, URL urlToSource) {
        return "<img align=\"" + alignment.name() + "\" src=\"" + urlToSource.toString() + "\">";
    }

    /**
     * Wraps the provided content in a P (paragraph) tag.
     *
     * @param paragraph the content to be wrapped
     * @return the content wrapped in a P tag
     */
    public static String p(String paragraph) {
        return wrapTag("p", paragraph);
    }

    /**
     * Returns a BR (break) tag.
     *
     * @return the BR tag
     */
    public static String br() {
        return "<br/>";
    }

    /**
     * Wraps the provided content in a SMALL tag.
     *
     * @param content the content to be wrapped
     * @return the content wrapped in a SMALL tag
     */
    public static String small(String content) {
        return "<small>" + content + "</small>";
    }

    /**
     * Creates an HR (horizontal rule) tag with the specified color.
     *
     * @param color the color of the horizontal rule
     * @return the HR tag
     */
    public static String hr(String color) {
        return "<hr color=" + color + ">";
    }

    /**
     * Wraps the provided content in a DIV tag.
     *
     * @param content the content to be wrapped
     * @return the content wrapped in a DIV tag
     */
    public static String div(String content) {
        return wrapTag("div", content);
    }

    /**
     * Creates a TABLE tag with the specified width and rows.
     *
     * @param width the width of the table
     * @param rows  the rows of the table
     * @return the TABLE tag with the specified rows
     */
    public static String table(int width, String... rows) {
        return table(width, Arrays.asList(rows));
    }

    /**
     * Creates a TABLE tag with the specified width and rows.
     *
     * @param width the width of the table
     * @param rows  the rows of the table
     * @return the TABLE tag with the specified rows
     */
    public static String table(int width, Iterable<String> rows) {
        String ret = "";

        String each;
        for (Iterator<String> ite = rows.iterator(); ite.hasNext(); ret = ret + each) {
            each = ite.next();
        }

        return tableWithProperties("Cellpadding=\"3\" Cellspacing=\"0.5\" Align=\"center\" Width=\"" + width + "\"", ret);
    }

    /**
     * Creates a TABLE tag with the specified properties and rows.
     *
     * @param properties the properties of the table
     * @param rows       the rows of the table
     * @return the TABLE tag with the specified properties and rows
     */
    public static String tableWithProperties(String properties, String... rows) {
        return tableWithProperties(properties, Arrays.asList(rows));
    }

    /**
     * Creates a TABLE tag with the specified properties and rows.
     *
     * @param properties the properties of the table
     * @param rows       the rows of the table
     * @return the TABLE tag with the specified properties and rows
     */
    public static String tableWithProperties(String properties, Iterable<String> rows) {
        StringBuilder sb = new StringBuilder();
        rows.forEach(sb::append);

        return wrapTag("table", properties, sb.toString());
    }

    /**
     * Creates a TR (table row) tag with the specified cells.
     *
     * @param cells the cells of the row
     * @return the TR tag with the specified cells
     */
    public static String tableRow(String... cells) {
        return tableRowWithProperties("", cells);
    }

    /**
     * Creates a TR (table row) tag with the specified cells.
     *
     * @param cells the cells of the row
     * @return the TR tag with the specified cells
     */
    public static String tableRow(Iterable<String> cells) {
        return tableRowWithProperties("", cells);
    }

    /**
     * Creates a TR (table row) tag with the specified properties and cells.
     *
     * @param properties the properties of the row
     * @param cells      the cells of the row
     * @return the TR tag with the specified properties and cells
     */
    public static String tableRowWithProperties(String properties, String... cells) {
        StringBuilder sb = new StringBuilder();
        for (String cell : cells) {
            sb.append(cell);
        }

        return wrapTag("tr", properties, sb.toString());
    }

    /**
     * Creates a TR (table row) tag with the specified properties and cells.
     *
     * @param properties the properties of the row
     * @param cells      the cells of the row
     * @return the TR tag with the specified properties and cells
     */
    public static String tableRowWithProperties(String properties, Iterable<String> cells) {
        StringBuilder sb = new StringBuilder();
        cells.forEach(sb::append);

        return wrapTag("tr", properties, sb.toString());
    }

    /**
     * Creates a TH (table header) tag with the specified data.
     *
     * @param data the data of the header
     * @return the TH tag with the specified data
     */
    public static String tableHeader(String data) {
        return tableHeaderWithProperties("", data);
    }

    /**
     * Creates a TH (table header) tag with the specified properties and data, wrapping after the first word.
     *
     * @param properties the properties of the header
     * @param data       the data of the header
     * @return the TH tag with the specified properties and data
     */
    public static String tableHeaderWithPropertiesWrappedAfterFirstWord(String properties, String data) {
        return tableHeaderWithProperties(properties, data.replaceFirst("\\s", "<br/>"));
    }

    /**
     * Creates a TH (table header) tag with the specified properties and data.
     *
     * @param properties the properties of the header
     * @param data       the data of the header
     * @return the TH tag with the specified properties and data
     */
    public static String tableHeaderWithProperties(String properties, String data) {
        return wrapTag("th", properties, data.replaceAll("\\s", SPACE_STR));
    }

    /**
     * Creates a TH (table header) spacer tag.
     *
     * @return the TH spacer tag
     */
    public static String tableHeaderSpacer() {
        return wrapTag("th", SPACE_STR);
    }

    /**
     * Creates a TD (table cell) tag with the specified data.
     *
     * @param data the data of the cell
     * @return the TD tag with the specified data
     */
    public static String tableCell(String data) {
        return tableCellWithProperties("", data);
    }

    /**
     * Creates a TD (table cell) tag with the specified number data.
     *
     * @param data the data of the cell
     * @return the TD tag with the specified number data
     */
    public static String tableCellNumber(double data) {
        return tableCellWithProperties(ALIGN_RIGHT_STR, Double.toString(data));
    }

    /**
     * Creates a TD (table cell) tag with the specified number data.
     *
     * @param data the data of the cell
     * @return the TD tag with the specified number data
     */
    public static String tableCellNumber(long data) {
        return tableCellWithProperties(ALIGN_RIGHT_STR, Long.toString(data));
    }

    /**
     * Creates a TD (table cell) tag with the specified number data.
     *
     * @param data the data of the cell
     * @return the TD tag with the specified number data
     */
    public static String tableCellNumber(String data) {
        return tableCellWithProperties(ALIGN_RIGHT_STR, data);
    }

    /**
     * Creates a TD (table cell) tag with the specified number data and format.
     *
     * @param value  the data of the cell
     * @param format the format of the data
     * @return the TD tag with the specified number data and format
     */
    public static String tableCellNumber(String value, Format format) {
        String formattedValue = format.format(value);
        return tableCellWithProperties(ALIGN_RIGHT_STR, formattedValue);
    }

    /**
     * Creates a TD (table cell) tag with the specified data, aligned to the top.
     *
     * @param data the data of the cell
     * @return the TD tag with the specified data, aligned to the top
     */
    public static String tableCellAlignTop(String data) {
        return tableCellWithProperties("valign='top'", data);
    }

    /**
     * Creates a TD (table cell) tag with the specified properties and data.
     *
     * @param properties the properties of the cell
     * @param data       the data of the cell
     * @return the TD tag with the specified properties and data
     */
    public static String tableCellWithProperties(String properties, String data) {
        return wrapTag("td", properties, data);
    }

    /**
     * Wraps the provided content in a font tag with the specified size.
     *
     * @param size    the font size
     * @param content the content to be wrapped
     * @return the content wrapped in a font tag with the specified size
     */
    public static String fontSize(String size, String content) {
        return format(FONT_LABEL_STR, "size", size, content);
    }

    /**
     * Wraps the provided content in a font tag with the specified font.
     *
     * @param font    the font to be used
     * @param content the content to be wrapped
     * @return the content wrapped in a font tag with the specified font
     * @since ELITECO SDK 1.2.13.0
     */
    public static String fontType(Font font, String content) {
        if (StringUtils.isNullOrEmpty(content)) {
            return p(content);
        }

        String format = String.format("style=\"font-family:%s;font-size:%dpt;font-weight: %s;\"", font.getName(), font.getSize(), font.isBold() ? "bold" : "normal");
        return "<p " + format + ">" + content + "</p>";
    }

    /**
     * Wraps the provided content in a font tag with the specified font, excluding the font size.
     *
     * @param font    the font to be used
     * @param content the content to be wrapped
     * @return the content wrapped in a font tag with the specified font, excluding the font size
     * @since ELITECO SDK 1.2.13.0
     */
    public static String fontTypeWithoutSize(Font font, String content) {
        if (StringUtils.isNullOrEmpty(content)) {
            return p(content);
        }

        String format = String.format("style=\"font-family:%s;\"", font.getName());
        return "<p " + format + ">" + content + "</p>";
    }

    /**
     * Wraps the provided content in a font tag with the specified background color.
     *
     * @param color   the background color
     * @param content the content to be wrapped
     * @return the content wrapped in a font tag with the specified background color
     */
    public static String fontBackgroundColor(String color, String content) {
        return format(FONT_LABEL_STR, "bgcolor", color, content);
    }

    /**
     * Wraps the provided content in a font tag with the specified font color.
     *
     * @param color   the font color
     * @param content the content to be wrapped
     * @return the content wrapped in a font tag with the specified font color
     */
    public static String fontColor(String color, String content) {
        return format(FONT_LABEL_STR, "color", color, content);
    }

    /**
     * Wraps the provided content in a font tag with the specified RGB color.
     *
     * @param rgb     the RGB color
     * @param content the content to be wrapped
     * @return the content wrapped in a font tag with the specified RGB color
     */
    public static String fontRGBColor(String rgb, String content) {
        return format(FONT_LABEL_STR, "color", rgb, content);
    }

    /**
     * Converts HTML content to plain text.
     *
     * @param content the HTML content to be converted
     * @return the plain text content
     */
    public static String unHtml(String content) {
        return Jsoup.parse(content).text();
    }

    /**
     * Creates an anchor (link) tag with the specified link and text.
     *
     * @param link the URL of the link
     * @param text the text of the link
     * @return the anchor tag with the specified link and text
     */
    public static String link(String link, String text) {
        return format("<a href=\"%s\">%s</a>", link, text);
    }

    /**
     * Wraps the provided content in the specified tag.
     *
     * @param tag     the tag to be used
     * @param content the content to be wrapped
     * @return the content wrapped in the specified tag
     */
    private static String wrapTag(String tag, String content) {
        return wrapTag(tag, content, false);
    }

    /**
     * Wraps the provided content in the specified tag, with an option to remove existing wrapping.
     *
     * @param tag                    the tag to be used
     * @param content                the content to be wrapped
     * @param removeExistingWrapping whether to remove existing wrapping
     * @return the content wrapped in the specified tag
     */
    private static String wrapTag(String tag, String content, boolean removeExistingWrapping) {
        if (content == null) {
            content = "";
        }

        if (removeExistingWrapping) {
            content = StringUtils.trimStartAndEnd("<" + tag + ">", "</" + tag + ">", content);
        }

        return format("<%s>%s</%s>", tag, content, tag);
    }

    /**
     * Wraps the provided content in the specified tag with properties.
     *
     * @param tag        the tag to be used
     * @param properties the properties of the tag
     * @param content    the content to be wrapped
     * @return the content wrapped in the specified tag with properties
     */
    private static String wrapTag(String tag, String properties, String content) {
        return format("<%s %s>%s</%s>", tag, properties, content, tag);
    }

    /**
     * Wraps the provided content in an italic (I) tag.
     *
     * @param label the content to be wrapped
     * @return the content wrapped in an italic tag
     */
    public static String italic(String label) {
        return format("<i>%s</i>", label);
    }

    /**
     * Wraps the provided content in a DIV tag with the specified top padding.
     *
     * @param paddingTop the top padding
     * @param message    the content to be wrapped
     * @return the content wrapped in a DIV tag with the specified top padding
     */
    public static String indentTop(int paddingTop, String message) {
        return format(divWithStyles(message, new HtmlAttribute(PADDING_TOP_STR, Integer.toString(paddingTop))));
    }

    /**
     * Wraps the provided content in a DIV tag with the specified left padding.
     *
     * @param paddingLeft the left padding
     * @param message     the content to be wrapped
     * @return the content wrapped in a DIV tag with the specified left padding
     */
    public static String indentLeft(int paddingLeft, String message) {
        return format(divWithStyles(message, new HtmlAttribute(PADDING_LEFT_STR, Integer.toString(paddingLeft))));
    }

    /**
     * Wraps the provided content in a DIV tag with the specified bottom padding.
     *
     * @param paddingBottom the bottom padding
     * @param message       the content to be wrapped
     * @return the content wrapped in a DIV tag with the specified bottom padding
     */
    public static String indentBottom(int paddingBottom, String message) {
        return format(divWithStyles(message, new HtmlAttribute(PADDING_BOTTOM_STR, Integer.toString(paddingBottom))));
    }

    /**
     * Wraps the provided content in a DIV tag with the specified right padding.
     *
     * @param paddingRight the right padding
     * @param message      the content to be wrapped
     * @return the content wrapped in a DIV tag with the specified right padding
     */
    public static String indentRight(int paddingRight, String message) {
        return format(divWithStyles(message, new HtmlAttribute(PADDING_RIGHT_STR, Integer.toString(paddingRight))));
    }

    /**
     * Wraps the provided content in a DIV tag with the specified padding on all sides.
     *
     * @param paddingTop    the top padding
     * @param paddingLeft   the left padding
     * @param paddingBottom the bottom padding
     * @param paddingRight  the right padding
     * @param message       the content to be wrapped
     * @return the content wrapped in a DIV tag with the specified padding on all sides
     */
    public static String indent(int paddingTop, int paddingLeft, int paddingBottom, int paddingRight, String message) {
        return format(divWithStyles(message, new HtmlAttribute(PADDING_TOP_STR, Integer.toString(paddingTop)), new HtmlAttribute(PADDING_LEFT_STR, Integer.toString(paddingLeft)), new HtmlAttribute(PADDING_BOTTOM_STR, Integer.toString(paddingBottom)), new HtmlAttribute(PADDING_RIGHT_STR, Integer.toString(paddingRight))));
    }

    /**
     * Creates a DIV tag with the specified styles.
     *
     * @param message    the content to be wrapped
     * @param attributes the attributes for the styles
     * @return the content wrapped in a DIV tag with the specified styles
     */
    private static String divWithStyles(String message, HtmlAttribute... attributes) {
        String divStyleBegin = "<div style=\"";
        String divStyleEnd = "\">%s</div>";
        StringBuilder style = new StringBuilder();
        String[] args = new String[attributes.length * 2 + 1];
        int index = 0;

        for (HtmlAttribute attribute : attributes) {
            style.append("%s:%spx;");
            args[index++] = attribute.name;
            args[index++] = attribute.value;
        }

        args[index] = message;
        return format(divStyleBegin + style + divStyleEnd, args);
    }

    /**
     * Wraps the provided content in a DIV tag with the specified width if it exceeds the maximum width.
     *
     * @param maxWidth the maximum width
     * @param message  the content to be wrapped
     * @return the content wrapped in a DIV tag with the specified width if it exceeds the maximum width
     */
    public static String maxWidth(int maxWidth, String message) {
        if (message == null) {
            return "";
        } else {
            return widthOfStringInPixels(message) > maxWidth ? format(divWithStyle("width", Integer.toString(maxWidth), message)) : message;
        }
    }

    /**
     * Creates a DIV tag with the specified style and argument.
     *
     * @param style    the style to be used
     * @param argument the argument for the style
     * @param message  the content to be wrapped
     * @return the content wrapped in a DIV tag with the specified style and argument
     */
    public static String divWithStyle(String style, String argument, String message) {
        return format("<div style=\"%s:%spx\">%s</div>", style, argument, message);
    }

    /**
     * Wraps the provided content in a centered DIV tag.
     *
     * @param message the content to be wrapped
     * @return the content wrapped in a centered DIV tag
     */
    public static String centerText(String message) {
        return format("<div style='text-align:center'>%s</div>", message);
    }

    /**
     * Formats the provided content with the specified format and arguments.
     *
     * @param format the format string
     * @param args   the arguments for the format
     * @return the formatted content
     */
    private static String format(String format, String... args) {
        for (int i = 0; i < args.length; ++i) {
            args[i] = args[i].replace("%", "&#37;");
        }

        return String.format(format, args);
    }

    /**
     * Calculates the width of the provided string in pixels.
     *
     * @param message the string to be measured
     * @return the width of the string in pixels
     */
    private static double widthOfStringInPixels(String message) {
        if (message.contains("</html>")) {
            return 0.0D;
        } else {
            Object antiAliasHint = RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB;
            Object fractionalMetricsHint = RenderingHints.VALUE_FRACTIONALMETRICS_DEFAULT;
            FontRenderContext fontRenderContext = new FontRenderContext(null, antiAliasHint, fractionalMetricsHint);
            return ARIEL_FONT.getStringBounds(message, fontRenderContext).getWidth();
        }
    }

    /**
     * Wraps the provided content in an unordered list (UL) tag.
     *
     * @param content the content to be wrapped
     * @return the content wrapped in an unordered list tag
     */
    public static String unorderedList(String content) {
        return wrapTag("ul", content);
    }

    /**
     * Wraps the provided content in an unordered list (UL) tag.
     *
     * @param content the content to be wrapped
     * @return the content wrapped in an unordered list tag
     */
    public static String unorderedList(Iterable<String> content) {
        StringBuilder listItems = new StringBuilder();
        content.forEach(listItems::append);

        return unorderedList(listItems.toString());
    }

    /**
     * Wraps the provided content in an ordered list (OL) tag.
     *
     * @param content the content to be wrapped
     * @return the content wrapped in an ordered list tag
     */
    public static String orderedList(String content) {
        return wrapTag("ol", content);
    }

    /**
     * Wraps the provided content in a list item (LI) tag.
     *
     * @param content the content to be wrapped
     * @return the content wrapped in a list item tag
     */
    public static String li(String content) {
        return wrapTag("li", content);
    }

    /**
     * Converts the provided string to HTML by escaping special characters.
     *
     * @param programName the string to be converted
     * @return the HTML string with escaped special characters
     */
    public static String convertToHtml(String programName) {
        StringBuilder result = new StringBuilder();
        for (char each : programName.toCharArray()) {
            switch (each) {
                case '"':
                    result.append("&quot;");
                    break;
                case '&':
                    result.append("&amp;");
                    break;
                case '<':
                    result.append("&lt;");
                    break;
                case '>':
                    result.append("&gt;");
                    break;
                default:
                    result.append(each);
            }
        }

        return result.toString();
    }

    /**
     * Inserts line breaks into the provided text at the specified line length.
     *
     * @param text       the text to be formatted
     * @param lineLength the maximum line length before inserting a line break
     * @return the formatted text with line breaks
     */
    public static String lineBreakText(String text, int lineLength) {
        if (text.length() > lineLength) {
            int i = text.indexOf(" ", lineLength);
            if (i > 0) {
                text = String.format("%s%s%s", text.substring(0, i), br(), lineBreakText(text.substring(i).trim(), lineLength));
            }
        }

        return text;
    }

    /**
     * Truncates long words in the provided text with ellipsis if they exceed the specified maximum width in pixels.
     *
     * @param maxPixels the maximum width in pixels
     * @param line      the text to be truncated
     * @return the truncated text with ellipsis
     */
    public static String truncateLongWordsWithDots(double maxPixels, String line) {
        return isHtml(line) ? line : truncateWordsWithDots(maxPixels, line);
    }

    /**
     * Truncates long words in the provided text with ellipsis if they exceed the specified maximum width in pixels.
     *
     * @param maxPixels the maximum width in pixels
     * @param line      the text to be truncated
     * @return the truncated text with ellipsis
     */
    private static String truncateWordsWithDots(double maxPixels, String line) {
        String[] longestWords = findWordsLongerThan(maxPixels, line);
        String result = line;
        if (line != null && !line.isEmpty() && longestWords.length > 0) {
            for (String longWord : longestWords) {
                result = truncateWordWithDots(longWord, maxPixels, line);
            }
        }

        return result;
    }

    /**
     * Truncates text with ellipsis if it exceeds the specified maximum width in pixels.
     *
     * @param maxPixels the maximum width in pixels
     * @param line      the text to be truncated
     * @return the truncated text with ellipsis
     */
    public static String truncateTextWithDots(double maxPixels, String line) {
        if (isHtml(line)) {
            return line;
        } else {
            String result = truncateWordsWithDots(maxPixels, line);
            result = truncateLineWithDots(result, maxPixels);
            return result;
        }
    }

    /**
     * Checks if the provided string contains HTML.
     *
     * @param string the string to be checked
     * @return true if the string contains HTML, false otherwise
     */
    public static boolean isHtml(String string) {
        boolean ret = false;
        if (string != null) {
            ret = HTML_PATTERN.matcher(string).find();
        }

        return ret;
    }

    /**
     * Converts the provided HTML content to plain text.
     *
     * @param line the HTML content to be converted
     * @return the plain text content
     */
    public static String toPlainText(String line) {
        return (new HtmlToPlainText()).getPlainText(Jsoup.parse(line));
    }

    /**
     * Truncates the specified word with ellipsis if it exceeds the specified maximum width in pixels.
     *
     * @param word      the word to be truncated
     * @param maxPixels the maximum width in pixels
     * @param line      the original text
     * @return the text with the truncated word
     */
    private static String truncateWordWithDots(String word, double maxPixels, String line) {
        String result = line;
        if (word != null && !word.isEmpty()) {
            double letterSize = widthOfStringInPixels(word) / word.length();
            if (letterSize > 0.0D) {
                int maxNoOfLetters = (int) Math.round(maxPixels / letterSize);
                result = line.replace(word, StringUtils.safeLimitedSizeStringWithDots(maxNoOfLetters, word));
            }
        }

        return result;
    }

    /**
     * Truncates the specified line with ellipsis if it exceeds the specified maximum width in pixels.
     *
     * @param line      the line to be truncated
     * @param maxPixels the maximum width in pixels
     * @return the truncated line with ellipsis
     */
    private static String truncateLineWithDots(String line, double maxPixels) {
        String result = line;
        if (line != null && !line.isEmpty()) {
            double letterSize = widthOfStringInPixels(line) / line.length();
            if (letterSize > 0.0D) {
                int maxNoOfLetters = (int) Math.round(maxPixels / letterSize);
                result = StringUtils.safeLimitedSizeStringWithDots(maxNoOfLetters, line);
            }
        }

        return result;
    }

    /**
     * Finds words longer than the specified maximum width in pixels.
     *
     * @param maxPixels the maximum width in pixels
     * @param line      the text to be checked
     * @return an array of words longer than the specified maximum width
     */
    private static String[] findWordsLongerThan(double maxPixels, String line) {
        List longestWords = new List();
        if (line != null) {
            String[] words = line.split("\\s+");
            for (String word : words) {
                double width = widthOfStringInPixels(word);
                if (width >= maxPixels) {
                    longestWords.add(word);
                }
            }
        }

        return longestWords.getItems();
    }

    /**
     * Fills the provided string with spaces to reach the specified minimum length.
     *
     * @param s      the string to be filled
     * @param length the minimum length
     * @return the string filled with spaces to reach the specified minimum length
     */
    public static String fillToMinimumLength(String s, int length) {
        int additionalLength = length - s.length();

        StringBuilder sBuilder = new StringBuilder(s);
        for (int i = 0; i < additionalLength; ++i) {
            sBuilder.append(SPACE_STR);
        }
        return sBuilder.toString();
    }

    /**
     * Enumeration for text alignment.
     */
    public enum Align {
        /**
         * Top alignment.
         */
        Top,

        /**
         * Center alignment.
         */
        Center,

        /**
         * Bottom alignment.
         */
        Bottom
    }

    /**
     * Helper class for HTML attributes.
     */
    private static class HtmlAttribute {
        public String name;
        public String value;

        public HtmlAttribute(String name, String value) {
            this.name = name;
            this.value = value;
        }
    }

}
