package cn.elibot.robot.commons.lang.swing;

import java.awt.*;

/**
 * The {@code FontUtils} class provides a centralized repository of predefined {@link Font} constants for use throughout the
 * application.
 * This class ensures that font sizes and styles are consistent and easily maintainable across different parts of the UI.
 *
 * <p>This utility class categorizes fonts based on their hierarchical importance typically used in user interfaces. It helps
 * maintain typographical consistency and enhances the readability and aesthetic of the application.</p>
 * <p>Using these predefined fonts helps in achieving a uniform look and feel across the application, making the UI more
 * user-friendly and visually appealing.</p>
 *
 * @author ELITECO SDK API
 * @since ELITECO SDK 1.2.13.0
 */
public class FontUtils {
    public static final String FONT_TYPE = System.getProperty("default.font", "");
    public static final String FONT_TYPE_BOLD = System.getProperty("default.bold.font", "");
    public static final Font SIZE_6_FONT = new FontResource(Font.PLAIN, 6);
    public static final Font SIZE_6_FONT_BOLD = new FontResource(Font.BOLD, 6);
    public static final Font SIZE_10_FONT = new FontResource(Font.PLAIN, 10);
    public static final Font SIZE_10_FONT_BOLD = new FontResource(Font.BOLD, 10);
    public static final Font SIZE_11_FONT = new FontResource(Font.PLAIN, 11);
    public static final Font SIZE_11_FONT_BOLD = new FontResource(Font.BOLD, 11);
    public static final Font SIZE_12_FONT = new FontResource(Font.PLAIN, 12);
    public static final Font SIZE_12_FONT_BOLD = new FontResource(Font.BOLD, 12);
    public static final Font SIZE_13_FONT = new FontResource(Font.PLAIN, 13);
    public static final Font SIZE_13_FONT_BOLD = new FontResource(Font.BOLD, 13);
    public static final Font SIZE_14_FONT = new FontResource(Font.PLAIN, 14);
    public static final Font SIZE_14_FONT_BOLD = new FontResource(Font.BOLD, 14);
    public static final Font SIZE_15_FONT = new FontResource(Font.PLAIN, 15);
    public static final Font SIZE_15_FONT_BOLD = new FontResource(Font.BOLD, 15);
    public static final Font SIZE_16_FONT = new FontResource(Font.PLAIN, 16);
    public static final Font SIZE_16_FONT_BOLD = new FontResource(Font.BOLD, 16);
    public static final Font SIZE_17_FONT = new FontResource(Font.PLAIN, 17);
    public static final Font SIZE_17_FONT_BOLD = new FontResource(Font.BOLD, 17);
    public static final Font SIZE_18_FONT = new FontResource(Font.PLAIN, 18);
    public static final Font SIZE_18_FONT_BOLD = new FontResource(Font.BOLD, 18);
    public static final Font SIZE_20_FONT = new FontResource(Font.PLAIN, 20);
    public static final Font SIZE_20_FONT_BOLD = new FontResource(Font.BOLD, 20);
    public static final Font SIZE_22_FONT = new FontResource(Font.PLAIN, 22);
    public static final Font SIZE_22_FONT_BOLD = new FontResource(Font.BOLD, 22);
    public static final Font SIZE_24_FONT = new FontResource(Font.PLAIN, 24);
    public static final Font SIZE_24_FONT_BOLD = new FontResource(Font.BOLD, 24);
    public static final Font SIZE_25_FONT = new FontResource(Font.PLAIN, 25);
    public static final Font SIZE_25_FONT_BOLD = new FontResource(Font.BOLD, 25);
    public static final Font SIZE_30_FONT = new FontResource(Font.PLAIN, 30);
    public static final Font SIZE_30_FONT_BOLD = new FontResource(Font.BOLD, 30);
    public static final Font H1_FONT = SIZE_30_FONT;
    public static final Font H1_BOLD_FONT = SIZE_30_FONT_BOLD;
    public static final Font H2_FONT = SIZE_24_FONT;
    public static final Font H2_BOLD_FONT = SIZE_24_FONT_BOLD;
    public static final Font H3_FONT = SIZE_20_FONT;
    public static final Font H3_BOLD_FONT = SIZE_20_FONT_BOLD;
    public static final Font H4_FONT = SIZE_18_FONT;
    public static final Font H4_BOLD_FONT = SIZE_18_FONT_BOLD;
    public static final Font H5_FONT = SIZE_16_FONT;
    public static final Font H5_BOLD_FONT = SIZE_16_FONT_BOLD;
    public static final Font NORMAL_FONT = SIZE_15_FONT;
    public static final Font NORMAL_BOLD_FONT = SIZE_15_FONT_BOLD;
    public static final Font SMALL_FONT = SIZE_12_FONT;
    public static final Font SMALL_BOLD_FONT = SIZE_12_FONT_BOLD;
}
