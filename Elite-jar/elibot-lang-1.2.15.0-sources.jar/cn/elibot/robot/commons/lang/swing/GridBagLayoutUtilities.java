package cn.elibot.robot.commons.lang.swing;

import javax.swing.*;
import java.awt.*;

/**
 * Utility class for adding components to a {@link JPanel} using {@link GridBagLayout}.
 * This class provides various overloaded methods to simplify the process of adding components with specific layout constraints.
 *
 * <p>
 * Example usage:
 * <pre>{@code
 * JPanel configurableOutputPanel = new JPanel();
 * configurableOutputPanel.setLayout(new GridBagLayout());
 *
 * for (int i = 0; i < 10; i++) {
 *     JButton button = new JButton("Button " + i);
 *     if (i < 5) {
 *         GridBagLayoutUtilities.addComponent(configurableOutputPanel, button, 1, i + 1, 5, 1, 0, 0, 0, 5, GridBagConstraints.HORIZONTAL, GridBagConstraints.NORTH);
 *     } else {
 *         GridBagLayoutUtilities.addComponent(configurableOutputPanel, button, 3, i - 3, 1, 1, 0, 5, 0, 0, GridBagConstraints.HORIZONTAL, GridBagConstraints.SOUTH);
 *     }
 * }
 * }</pre>
 * </p>
 *
 * @author ELITECO SDK API
 * @since ELITECO SDK 1.2.13.0
 */
public class GridBagLayoutUtilities {

    /**
     * Adds a component to the specified panel with detailed GridBagConstraints.
     *
     * @param panel  the panel to which the component is added
     * @param c      the component to be added
     * @param x      the gridx value
     * @param y      the gridy value
     * @param width  the gridwidth value
     * @param height the gridheight value
     * @param wx     the weightx value
     * @param wy     the weighty value
     * @param ipadx  the internal padding in x direction
     * @param ipady  the internal padding in y direction
     * @param top    the top inset
     * @param left   the left inset
     * @param bottom the bottom inset
     * @param right  the right inset
     * @param fill   the fill constraint
     * @param anchor the anchor constraint
     */
    public static void addComponent(JPanel panel, Component c, int x, int y, int width, int height, double wx, double wy, int ipadx, int ipady, int top, int left, int bottom, int right, int fill, int anchor) {
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = x;
        gridBagConstraints.gridy = y;
        gridBagConstraints.gridwidth = width;
        gridBagConstraints.gridheight = height;
        gridBagConstraints.weightx = wx;
        gridBagConstraints.weighty = wy;
        gridBagConstraints.ipadx = ipadx;
        gridBagConstraints.ipady = ipady;
        gridBagConstraints.anchor = anchor;
        gridBagConstraints.fill = fill;
        gridBagConstraints.insets = new Insets(top, left, bottom, right);
        panel.add(c, gridBagConstraints);
    }

    /**
     * Adds a component to the specified panel with detailed GridBagConstraints, but without internal padding.
     *
     * @param panel  the panel to which the component is added
     * @param c      the component to be added
     * @param x      the gridx value
     * @param y      the gridy value
     * @param width  the gridwidth value
     * @param height the gridheight value
     * @param wx     the weightx value
     * @param wy     the weighty value
     * @param top    the top inset
     * @param left   the left inset
     * @param bottom the bottom inset
     * @param right  the right inset
     * @param fill   the fill constraint
     * @param anchor the anchor constraint
     */
    public static void addComponent(JPanel panel, Component c, int x, int y, int width, int height, double wx, double wy, int top, int left, int bottom, int right, int fill, int anchor) {
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = x;
        gridBagConstraints.gridy = y;
        gridBagConstraints.gridwidth = width;
        gridBagConstraints.gridheight = height;
        gridBagConstraints.weightx = wx;
        gridBagConstraints.weighty = wy;
        gridBagConstraints.anchor = anchor;
        gridBagConstraints.fill = fill;
        gridBagConstraints.insets = new Insets(top, left, bottom, right);
        panel.add(c, gridBagConstraints);
    }

    /**
     * Adds a component to the specified panel with minimal GridBagConstraints.
     *
     * @param panel  the panel to which the component is added
     * @param c      the component to be added
     * @param x      the gridx value
     * @param y      the gridy value
     * @param ipadx  the internal padding in x direction
     * @param ipady  the internal padding in y direction
     * @param top    the top inset
     * @param left   the left inset
     * @param bottom the bottom inset
     * @param right  the right inset
     * @param anchor the anchor constraint
     */
    public static void addComponent(JPanel panel, Component c, int x, int y, int ipadx, int ipady, int top, int left, int bottom, int right, int anchor) {
        addComponent(panel, c, x, y, 1, 1, 0.0, 0.0, ipadx, ipady, top, left, bottom, right, 0, anchor);
    }

    /**
     * Adds a component to the specified panel with minimal GridBagConstraints and no insets.
     *
     * @param panel  the panel to which the component is added
     * @param c      the component to be added
     * @param x      the gridx value
     * @param y      the gridy value
     * @param ipadx  the internal padding in x direction
     * @param ipady  the internal padding in y direction
     * @param anchor the anchor constraint
     */
    public static void addComponent(JPanel panel, Component c, int x, int y, int ipadx, int ipady, int anchor) {
        addComponent(panel, c, x, y, 1, 1, ipadx, ipady, 0, 0, 0, 0.0, 0, anchor);
    }

    /**
     * Adds a component to the specified panel with specified width and height, weight, fill, and anchor constraints.
     *
     * @param panel  the panel to which the component is added
     * @param c      the component to be added
     * @param x      the gridx value
     * @param y      the gridy value
     * @param width  the gridwidth value
     * @param height the gridheight value
     * @param wx     the weightx value
     * @param wy     the weighty value
     * @param fill   the fill constraint
     * @param anchor the anchor constraint
     */
    public static void addComponent(JPanel panel, Component c, int x, int y, int width, int height, double wx, double wy, int fill, int anchor) {
        addComponent(panel, c, x, y, width, height, wx, wy, 0, 0, 0, 0, fill, anchor);
    }

    /**
     * Adds a component to the specified panel with specified width and height.
     *
     * @param panel  the panel to which the component is added
     * @param c      the component to be added
     * @param x      the gridx value
     * @param y      the gridy value
     * @param width  the gridwidth value
     * @param height the gridheight value
     */
    public static void addComponent(JPanel panel, Component c, int x, int y, int width, int height) {
        int dx = 2;
        int dy = 2;
        int ipadx = 0;
        int ipady = 0;
        double weightx = 0.0;
        double weighty = 0.0;
        int fill = GridBagConstraints.BOTH;
        int anchor = GridBagConstraints.CENTER;

        addComponent(panel, c, x, y, width, height, ipadx, ipady, dx, dy, weightx, weighty, fill, anchor);
    }

    /**
     * Adds a component to the specified panel with detailed GridBagConstraints and specific conditions for JComboBox and JTextField components.
     *
     * @param panel   the panel to which the component is added
     * @param c       the component to be added
     * @param x       the gridx value
     * @param y       the gridy value
     * @param width   the gridwidth value
     * @param height  the gridheight value
     * @param ipadx   the internal padding in x direction
     * @param ipady   the internal padding in y direction
     * @param dx      the x inset
     * @param dy      the y inset
     * @param weightx the weightx value
     * @param weighty the weighty value
     * @param fill    the fill constraint
     * @param anchor  the anchor constraint
     */
    public static void addComponent(JPanel panel, Component c, int x, int y, int width, int height, int ipadx, int ipady, int dx, int dy, double weightx, double weighty, int fill, int anchor) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = width;
        gbc.gridheight = height;
        gbc.ipadx = c instanceof JComboBox ? Math.max(4, ipadx) : ipadx;
        gbc.ipady = c instanceof JTextField ? Math.max(6, ipady) : ipady;
        gbc.insets = new Insets(dy, dx, dy, dx);
        gbc.weightx = weightx;
        gbc.weighty = weighty;
        gbc.fill = fill;
        gbc.anchor = anchor;
        panel.add(c, gbc);
    }
}
