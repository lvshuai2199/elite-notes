package cn.elibot.robot.commons.lang.swing;

import cn.elibot.robot.commons.lang.StringUtils;
import java.awt.Font;

/**
 * The {@code FontResource} class is a custom extension of the {@link Font} class.
 * It is designed for specific font management within the application and is primarily used by the {@link FontUtils} class.
 * Users of the application generally do not need to interact with this class directly.
 *
 * <p>
 * This class provides a way to create fonts with specific styles and sizes, based on configuration properties.
 * </p >
 *
 * <p>
 * Example usage within {@link FontUtils}:
 * <pre>{@code
 * public static final Font SIZE_12_FONT = new FontResource(Font.PLAIN, 12);
 * public static final Font SIZE_12_FONT_BOLD = new FontResource(Font.BOLD, 12);
 * }</pre>
 * </p >
 *
 * @author ELITECO SDK API
 * @see Font
 * @see FontUtils
 * @since ELITECO SDK 1.2.13.0
 */
public class FontResource extends Font {

    private int realStyle = Font.PLAIN;

    /**
     * Constructs a new {@code FontResource} with the specified style and size.
     *
     * @param style the style of the font (e.g., {@link Font#PLAIN}, {@link Font#BOLD})
     * @param size  the size of the font
     */
    public FontResource(int style, int size) {
        super(getFontName(style), getFontType(style), size);
        this.realStyle = style;
    }

    /**
     * Returns the appropriate font type based on the specified style.
     *
     * @param type the style of the font
     * @return the font type
     */
    static int getFontType(int type) {
        if (type == Font.BOLD) {
            return StringUtils.isNullOrEmpty(FontUtils.FONT_TYPE_BOLD) ? Font.BOLD : Font.PLAIN;
        } else {
            return Font.PLAIN;
        }
    }

    /**
     * Returns the appropriate font name based on the specified style.
     *
     * @param type the style of the font
     * @return the font name
     */
    static String getFontName(int type) {
        if (type == Font.PLAIN) {
            return FontUtils.FONT_TYPE;
        } else {
            return StringUtils.isNullOrEmpty(FontUtils.FONT_TYPE_BOLD) ? FontUtils.FONT_TYPE : FontUtils.FONT_TYPE_BOLD;
        }
    }

    public boolean isBoldFont() {
        return this.realStyle == Font.BOLD;
    }
}