package cn.elibot.robot.commons.lang;

import cn.elibot.robot.commons.lang.resource.LocaleProvider;
import cn.elibot.robot.commons.lang.translation.ResourceSupport;
import cn.elibot.robot.commons.lang.translation.UnitsResource;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * @author shi
 */
public class UnitsUtils {
    private static final double M_2_IN = 39.3701D;
    private static final double KG_2_LB = 2.20462262D;
    private static final double N_2_LB_FORCE = 0.224808943D;
    private static final double NM_2_LBFT = 0.7375621D;
    private static final DecimalFormat ONE_DECIMAL_DF;
    private static final DecimalFormat TWO_DECIMALS_DF;
    private static final DecimalFormat THREE_DECIMALS_DF;
    private static final DecimalFormat ONE_2_TWO_DECIMALS_DF;
    private static final DecimalFormat ONE_2_THREE_DECIMALS_DF;
    private static final DecimalFormat DEFAULT_INCH_FORMAT_DF;
    private static UnitType unitType;

    static {
        ONE_DECIMAL_DF = new DecimalFormat("##0.0", new DecimalFormatSymbols(Locale.ENGLISH));
        TWO_DECIMALS_DF = new DecimalFormat("##0.00", new DecimalFormatSymbols(Locale.ENGLISH));
        THREE_DECIMALS_DF = new DecimalFormat("##0.000", new DecimalFormatSymbols(Locale.ENGLISH));
        ONE_2_TWO_DECIMALS_DF = new DecimalFormat("##0.0#", new DecimalFormatSymbols(Locale.ENGLISH));
        ONE_2_THREE_DECIMALS_DF = new DecimalFormat("##0.0##", new DecimalFormatSymbols(Locale.ENGLISH));
        DEFAULT_INCH_FORMAT_DF = new DecimalFormat("##0.00#", new DecimalFormatSymbols(Locale.ENGLISH));
    }

    private UnitsUtils() {
    }

    public static String getUnitName(String key) {
        String keyText;
        try {
            keyText = getUnitName().get(key);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            keyText = "'" + key + "'";
        }

        return keyText;
    }

    public static String getTemperatureUnit() {
        return unitType == UnitType.METRIC ? getUnitName().unitDegC() : getUnitName().unitDegF();
    }

    public static String getMassUnit_kg_lb() {
        return unitType == UnitType.METRIC ? getUnitName().unitKg() : getUnitName().unitLb();
    }

    public static String getAngleUnits(){
        return getUnitName().unitDegrees();
    }

    public static String getTorqueUnit_NM() {
        return getUnitName().unitNm();
    }

    public static String getCurrentUnit_A() {
        return getUnitName().unitA();
    }

    public static String getVoltageUnit_V() {
        return getUnitName().unitV();
    }

    public static String getPowerfulUnit_W() {
        return getUnitName().unitW();
    }

    public static String getCurrentUnit_MA() {
        return getUnitName().unitMa();
    }


    public static String getLengthUnit_M_IN() {
        return unitType == UnitType.METRIC ? getUnitName().unitM() : getUnitName().unitIn();
    }

    public static UnitsResource getUnitName() {
        return ResourceSupport.textResource();
    }

    public static double convert_to_m(String n) {
        return convert_to_m(PrimitiveUtils.parseDouble(n));
    }

    public static double convert_to_m(double n) {
        return unitType.isImperial() ? in_to_m(n) : n / 1000.0D;
    }

    public static String convert_from_m(String n) {
        return convert_from_m(PrimitiveUtils.parseDouble(n));
    }

    public static String convert_from_m(double n) {
        return unitType.isImperial() ? ONE_2_THREE_DECIMALS_DF.format(m_to_in(n)) : ONE_2_TWO_DECIMALS_DF.format(n * 1000.0D);
    }

    public static String convert_from_m_movetab(double n) {
        return unitType.isImperial() ? THREE_DECIMALS_DF.format(m_to_in(n)) : TWO_DECIMALS_DF.format(n * 1000.0D);
    }

    public static String convert_from_m_max3dec(double n) {
        return convert_from_m(n, ONE_2_THREE_DECIMALS_DF);
    }

    public static String convert_from_m(double n, DecimalFormat df) {
        return unitType.isImperial() ? df.format(m_to_in(n)) : df.format(n * 1000.0D);
    }

    public static double convert_to_kg(double n) {
        return unitType.isImperial() ? lb_to_kg(n) : n;
    }

    public static String convert_from_kg(double n) {
        return unitType.isImperial() ? TWO_DECIMALS_DF.format(kg_to_lb(n)) : TWO_DECIMALS_DF.format(n);
    }

    public static double convert_to_celsius(double n) {
        return unitType.isImperial() ? F_to_celsius(n) : n;
    }

    public static String convert_from_celsius(double n) {
        return unitType.isImperial() ? ONE_DECIMAL_DF.format(celsius_to_F(n)) : ONE_DECIMAL_DF.format(n);
    }

    public static double[] convert_from_celsius(double[] n) {
        double[] arr = new double[n.length];
        for (int i = 0; i < n.length; i++) {
            arr[i] = unitType.isImperial() ? celsius_to_F(n[i]) : n[i];
        }
        return arr;
    }

    public static double convert_to_N(String n) {
        return convert_to_N(PrimitiveUtils.parseDouble(n));
    }

    public static double convert_to_N(double n) {
        return unitType.isImperial() ? lb_force_to_N(n) : n;
    }

    public static String convert_from_N(double n) {
        return unitType.isImperial() ? ONE_2_TWO_DECIMALS_DF.format(N_to_lb_force(n)) : ONE_2_TWO_DECIMALS_DF.format(n);
    }

    public static double convert_to_Nm(String n) {
        return convert_to_Nm(PrimitiveUtils.parseDouble(n));
    }

    public static double convert_to_Nm(double n) {
        return unitType.isImperial() ? lbft_to_Nm(n) : n;
    }

    public static String convert_from_Nm(double n) {
        return unitType.isImperial() ? ONE_2_TWO_DECIMALS_DF.format(Nm_to_lbft(n)) : ONE_2_TWO_DECIMALS_DF.format(n);
    }

    public static double convert_to_m_s(double n) {
        return unitType.isImperial() ? in_s_to_m_s(n) : n / 1000.0D;
    }

    public static double convert_to_m_s(String n) {
        return convert_to_m_s(PrimitiveUtils.parseDouble(n));
    }

    public static String convert_from_m_s(double n, DecimalFormat metricFormat, DecimalFormat inchFormat) {
        return unitType.isImperial() ? inchFormat.format(m_s_to_in_s(n)) : metricFormat.format(n * 1000.0D);
    }

    public static double convert_to_m_s2(String n) {
        return convert_to_m_s2(PrimitiveUtils.parseDouble(n));
    }

    public static double convert_to_m_s2(double n) {
        return unitType.isImperial() ? in_s2_to_m_s2(n) : n / 1000.0D;
    }

    public static String convert_from_m_s2(double n, DecimalFormat metricFormat, DecimalFormat inchFormat) {
        return unitType.isImperial() ? inchFormat.format(m_s2_to_in_s2(n)) : metricFormat.format(n * 1000.0D);
    }

    public static double convert_to_kg_m_s(double n) {
        return unitType.isImperial() ? lb_to_kg(in_to_m(n)) : n;
    }

    public static String convert_from_kg_m_s(double n) {
        return unitType.isImperial() ? ONE_DECIMAL_DF.format(kg_to_lb(m_to_in(n))) : ONE_DECIMAL_DF.format(n);
    }

    private static double m_to_in(double m) {
        return m * M_2_IN;
    }

    private static double in_to_m(double in) {
        return in / M_2_IN;
    }

    private static double kg_to_lb(double kg) {
        return kg * KG_2_LB;
    }

    private static double lb_to_kg(double lb) {
        return lb / KG_2_LB;
    }

    public static double celsius_to_F(double C) {
        return C * 1.8D + 32.0D;
    }

    public static double F_to_celsius(double F) {
        return (F - 32.0D) * 0.5555555555555556D;
    }

    private static double N_to_lb_force(double N) {
        return N * N_2_LB_FORCE;
    }

    private static double lb_force_to_N(double lb_force) {
        return lb_force / N_2_LB_FORCE;
    }

    private static double Nm_to_lbft(double Nm) {
        return Nm * NM_2_LBFT;
    }

    private static double lbft_to_Nm(double lbft) {
        return lbft / NM_2_LBFT;
    }

    private static double m_s_to_in_s(double m_s) {
        return m_s * M_2_IN;
    }

    private static double in_s_to_m_s(double in_s) {
        return in_s / M_2_IN;
    }

    private static double m_s2_to_in_s2(double m_s2) {
        return m_s2 * M_2_IN;
    }

    private static double in_s2_to_m_s2(double in_s2) {
        return in_s2 / M_2_IN;
    }


    public static void setProvider(LocaleProvider provider) {
        ResourceSupport.setProvider(provider);
    }

    public static UnitType getUnitType() {
        return UnitsUtils.unitType;
    }

    public static void setUnitType(UnitType unitType) {
        UnitsUtils.unitType = unitType;
    }
}
