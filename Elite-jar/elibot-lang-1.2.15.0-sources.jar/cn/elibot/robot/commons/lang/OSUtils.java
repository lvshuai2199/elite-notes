package cn.elibot.robot.commons.lang;

/**
 * @author ELITECO SDK API
 */
public class OSUtils {
    public static final OSType OS_TYPE = getOSType();
    public static final boolean WINDOWS = (OS_TYPE == OSType.OS_TYPE_WIN);
    public static final boolean LINUX = (OS_TYPE == OSType.OS_TYPE_LINUX);
    public static final boolean SOLARIS = (OS_TYPE == OSType.OS_TYPE_SOLARIS);
    public static final boolean MAC = (OS_TYPE == OSType.OS_TYPE_MAC);
    public static final boolean FREE_BSD = (OS_TYPE == OSType.OS_TYPE_FREE_BSD);
    public static final boolean OTHER = (OS_TYPE == OSType.OS_TYPE_OTHER);

    public static final OSArch OS_ARCH = getOSArch();
    public static final boolean AARCH64 = (OS_ARCH == OSArch.AARCH64);
    public static final boolean AMD64 = (OS_ARCH == OSArch.AMD64);

    private static OSType getOSType() {
        String osName = System.getProperty("os.name").toLowerCase();
        if (osName.startsWith("win")) {
            return OSType.OS_TYPE_WIN;
        } else if (osName.contains("sunos") || osName.contains("solaris")) {
            return OSType.OS_TYPE_SOLARIS;
        } else if (osName.contains("mac")) {
            return OSType.OS_TYPE_MAC;
        } else if (osName.contains("freebsd")) {
            return OSType.OS_TYPE_FREE_BSD;
        } else if (osName.contains("nux") || osName.contains("nix") || osName.contains("aix")) {
            return OSType.OS_TYPE_LINUX;
        } else {
            return OSType.OS_TYPE_OTHER;
        }
    }

    private static OSArch getOSArch() {
        String osName = System.getProperty("os.arch").toLowerCase();
        if (osName.startsWith("aarch64")) {
            return OSArch.AARCH64;
        } else if (osName.contains("amd64") || osName.contains("x86_64")) {
            return OSArch.AMD64;
        } else {
            return OSArch.OTHER;
        }
    }

    public enum OSArch {
        /**
         * aarch64 arch.
         */
        AARCH64("aarch64"),
        /**
         * amd64 arch.
         */
        AMD64("amd64"),
        /**
         * other arch.
         */
        OTHER("other");

        private final String name;

        OSArch(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    public enum OSType {
        /**
         * Linux os.
         */
        OS_TYPE_LINUX,

        /**
         * Windows os.
         */
        OS_TYPE_WIN,

        /**
         * Solaris os.
         */
        OS_TYPE_SOLARIS,

        /**
         * MAC os.
         */
        OS_TYPE_MAC,

        /**
         * FreeBSD os.
         */
        OS_TYPE_FREE_BSD,

        /**
         * Unknown os.
         */
        OS_TYPE_OTHER
    }
}
