package cn.elibot.robot.commons.lang;

import cn.elibot.robot.logger.LogFactory;
import cn.elibot.robot.logger.Logger;

/**
 * Script Utility
 *
 * @author elt
 */
public final class ScriptUtils {
    private static final Logger LOG = LogFactory.getLogger(ScriptUtils.class);

    private ScriptUtils() {
    }

    private static StringBuilder toScriptCode(char c, boolean bijective, StringBuilder s) {
        if (bijective && c == 'u') {
            s.append("uu");
        } else if (c < 128) {
            s.append(c);
        } else {
            s.append('u').append(c);
        }

        return s;
    }

    public static String toScriptCode(String content, boolean bijective) {
        if (content == null) {
            return null;
        }

        StringBuilder result = new StringBuilder();

        for (char c: content.toCharArray()) {
            toScriptCode(c, bijective, result);
        }

        return result.toString();
    }

    public static String fromScriptCode(String content) {
        if (content == null) {
            return null;
        }

        StringBuilder result = new StringBuilder();

        int index = 0;
        for (; index < content.length(); ++index) {
            char c = content.charAt(index);
            if (c == 'u') {
                boolean isValid = index + 1 < content.length();
                boolean isNextFormatChar = false;
                if (isValid) {
                    char firstEscapeCharacter = content.charAt(index + 1);
                    isNextFormatChar = firstEscapeCharacter == 'u';
                    isValid =  isNextFormatChar || Character.isDigit(firstEscapeCharacter);
                }

                if (!isValid) {
                    LOG.error("Malformed escape sequence in string: " + content);
                    result.append(c);
                } else if (isNextFormatChar) {
                    result.append('u');
                    ++index;
                } else {
                    int escapedChar = 0;
                    int nextIndex = index + 1;
                    while (nextIndex < content.length() && Character.isDigit(content.charAt(nextIndex))) {
                        escapedChar = escapedChar * 10 + (content.charAt(nextIndex) - 48);
                        ++index;
                    }

                    result.append((char) escapedChar);
                }
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }
}
