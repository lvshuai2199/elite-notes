package cn.elibot.robot.commons.lang;

import java.io.*;
import java.util.Collection;
import java.util.Collections;
import java.util.Properties;
import java.util.Set;

/**
 * Rich Properties
 *
 * @author elt
 */
public class RichProperties {
    private Properties primitiveProperties;
    private Properties properties;

    public RichProperties(Properties properties) {
        this.properties = properties;
        this.resetPrimitiveProperties();
    }

    @Override
    public RichProperties clone() {
        return new RichProperties((Properties) this.properties.clone());
    }

    public boolean hasChanges() {
        return !this.primitiveProperties.equals(this.properties);
    }

    public boolean containsKey(String key) {
        return this.properties.containsKey(key);
    }

    public void setProperty(String key, String value) {
        this.properties.setProperty(key, value);
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        if (!this.properties.containsKey(key)) {
            return defaultValue;
        }

        String booleanValue = this.properties.getProperty(key);
        return Boolean.parseBoolean(booleanValue);
    }

    public short getShort(String key, short defaultValue) {
        String intValue = this.properties.getProperty(key);

        try {
            return Short.parseShort(intValue);
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    public int getInteger(String key, int defaultValue) {
        String intValue = this.properties.getProperty(key);

        try {
            return Integer.parseInt(intValue);
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    public long getLong(String key, long defaultValue) {
        String longValue = this.properties.getProperty(key);

        try {
            return Long.parseLong(longValue);
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    public float getFloat(String key, float defaultValue) {
        String floatValue = this.properties.getProperty(key);

        try {
            return Float.parseFloat(floatValue);
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    public double getDouble(String key, double defaultValue) {
        String doubleValue = this.properties.getProperty(key);

        try {
            return PrimitiveUtils.parseDouble(doubleValue, defaultValue);
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    public <T> Collection<T> getClassInstances(String key, String... classNames) {
        String names = this.properties.getProperty(key);

        try {
            Collection<T> instancesByName = ClassUtils.getInstancesByName(names.split(" "));
            if (instancesByName.isEmpty()) {
                instancesByName = ClassUtils.getInstancesByName(classNames);
            }

            return instancesByName;
        } catch (Exception ex) {
            try {
                return ClassUtils.getInstancesByName(classNames);
            } catch (Exception subEx) {
                return Collections.emptyList();
            }
        }
    }

    public String[] getStringArray(String key, String[] defaultValue) {
        String strings = this.properties.getProperty(key);

        try {
            return StringUtils.split(" ", strings);
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    public <T extends Enum<T>> T getEnum(String key, T defaultValue) {
        String enumValue = this.properties.getProperty(key);

        try {
            return Enum.valueOf(defaultValue.getDeclaringClass(), enumValue);
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    public void store(OutputStream stream) throws IOException {
        this.properties.store(stream, "");
        this.resetPrimitiveProperties();
    }

    public void store(Writer writer) throws IOException {
        this.properties.store(writer, "");
        this.resetPrimitiveProperties();
    }

    public String getProperty(String key, String defaultValue) {
        return this.properties.getProperty(key, defaultValue);
    }

    public Set<String> getPropertyNames() {
        return this.properties.stringPropertyNames();
    }

    private void resetPrimitiveProperties() {
        primitiveProperties = new Properties();
        try {
            StringWriter stringWriter = new StringWriter();
            properties.store(stringWriter, "");
            primitiveProperties.load(new StringReader(stringWriter.toString()));
        } catch (IOException ignored) {
        }
    }
}
