package cn.elibot.robot.commons.lang;

import cn.elibot.robot.commons.lang.swing.FontUtils;
import cn.elibot.robot.commons.lang.swing.HtmlUtils;

import javax.swing.*;
import java.awt.*;
import java.util.Set;

/**
 * Naming Utility
 *
 * @author elt
 */
public final class NamingUtils {
    public static final int MAX_LENGTH_OF_SUPPORT_NUMBERING = 23;
    public static final int MAX_LENGTH_OF_NAME = 25;
    public static final int MAX_LENGTH_OF_FREE_NAME = 32;
    public static final String VAR_SUFFIX_STR = "";
    public static final String ILLEGAL_CHAR = ".*?[#%&{}\\\\|<>*?/$!'\":@,^;=()+].*?";

    /**
     * Add var suffix
     *
     * @param name the name to add suffix
     * @return new name with var suffix
     */
    public static String addVarSuffix(String name) {
        return name + VAR_SUFFIX_STR;
    }

    /**
     * Strip number characters off from the end of the name
     *
     * @param originalName the original name
     * @return the new name that has striped number characters off end of the name
     */
    public static String stripNumbersOffEndOfName(String originalName) {
        if (!hasAppendedNumber(originalName)) {
            return originalName;
        }

        String res = originalName;
        while (Character.isDigit(res.charAt(res.length() - 1))) {
            res = res.substring(0, res.length() - 1);
        }

        res = stripUnderscoreOffEndOfName(res);
        return res;
    }

    /**
     * Strip '_' character off from end of the name
     *
     * @param originalName the original name
     * @return the new name that has striped '_' characters off end of the name
     */
    public static String stripUnderscoreOffEndOfName(String originalName) {
        while (originalName.endsWith("_")) {
            originalName = originalName.substring(0, originalName.length() - 1);
        }

        return originalName;
    }

    /**
     * Truncate name that it`s length can not be greater than {@link NamingUtils#MAX_LENGTH_OF_SUPPORT_NUMBERING} value.
     *
     * @param originalName the original name to truncate
     * @return new name
     */
    public static String truncateNameToSupportNumbering(String originalName) {
        return truncateName(originalName, MAX_LENGTH_OF_SUPPORT_NUMBERING);
    }

    /**
     * Truncate name that it`s length can not be greater than {@link NamingUtils#MAX_LENGTH_OF_NAME} value.
     *
     * @param originalName the original name to truncate
     * @return new name
     */
    public static String truncateName(String originalName) {
        return truncateName(originalName, MAX_LENGTH_OF_NAME);
    }

    /**
     * Truncate name that it`s length can not be greater than specify length value.
     *
     * @param originalName the original name to truncate
     * @param length       the max length for name
     * @return new name that it
     */
    public static String truncateName(String originalName, int length) {
        if (originalName != null && originalName.length() > length) {
            originalName = originalName.substring(0, length);
        }

        return originalName;
    }

    /**
     * Returns a java valid name
     *
     * @param candidateName the candidate name
     * @return a java valid name
     */
    public static String convertToJavaValidName(String candidateName) {
        if (candidateName == null) {
            return null;
        } else {
            candidateName = candidateName.trim();
            StringBuilder builder = new StringBuilder();
            boolean isFirstCharacter = true;

            for (int index = 0; index < candidateName.length(); ++index) {
                char ch = candidateName.charAt(index);
                if (!isFirstCharacter) {
                    if (ch != ' ' && ch != '-' && ch != '_') {
                        if (Character.isLetterOrDigit(ch)) {
                            builder.append(ch);
                        } else {
                            builder.append('x');
                        }
                    } else {
                        builder.append('_');
                    }
                } else {
                    if (Character.isDigit(ch)) {
                        builder.append('a');
                        builder.append(ch);
                    } else if (Character.isLetter(ch)) {
                        builder.append(ch);
                    } else if (ch != '_' && ch != '-') {
                        builder.append('x');
                    } else {
                        builder.append('_');
                    }

                    isFirstCharacter = false;
                }
            }

            candidateName = builder.toString();
            return candidateName;
        }
    }

    // 名称校验不可输入非法字符
    public static boolean illegalCharValid(String uncheckedString) {
        for (int index = 0; index < uncheckedString.length(); ++index) {
            char ch = uncheckedString.charAt(index);
            if (index == 0) {
                if (!Character.isLetter(ch)) {
                    return false;
                }
            } else if (!Character.isLetterOrDigit(ch) && ch != '_') {
                return false;
            }
        }
        return !uncheckedString.matches(ILLEGAL_CHAR);
    }

    public static boolean isNameLengthValid(String uncheckedString) {
        uncheckedString = uncheckedString.trim();
        return uncheckedString.length() <= MAX_LENGTH_OF_FREE_NAME;
    }

    public static boolean isNameValid(String uncheckedString, int maxLength) {
        if (uncheckedString != null && uncheckedString.trim().length() != 0) {
            uncheckedString = uncheckedString.trim();

            for (int index = 0; index < uncheckedString.length(); ++index) {
                char ch = uncheckedString.charAt(index);
                if (index == 0) {
                    if (!Character.isLetter(ch)) {
                        return false;
                    }
                } else if (!Character.isLetterOrDigit(ch) && ch != '_') {
                    return false;
                }
            }

            return uncheckedString.length() <= maxLength;
        } else {
            return false;
        }
    }

    public static boolean hasAppendedNumber(String name) {
        int number = getAppendedNumberFromName(name);
        return number > -1;
    }

    public static int getAppendedNumberFromName(String name) {
        if (StringUtils.isNullOrEmpty(name) || name.endsWith("_")) {
            return -1;
        }

        String[] strings = name.trim().split("_");
        String lastPart = strings[strings.length - 1];
        return PrimitiveUtils.isInteger(lastPart) ? Integer.parseInt(lastPart) : -1;
    }

    public static String replaceAppendedNumber(String name, int number) {
        if (!hasAppendedNumber(name)) {
            return name;
        } else {
            int numberIndex = name.lastIndexOf("_");
            return name.substring(0, numberIndex + 1) + number;
        }
    }

    public static String addNumberToEndOfString(String name, int number) {
        return name == null ? "_" + number : name + "_" + number;
    }

    public static String createUniqueName(String name, Set<String> usedNames) {
        return createUniqueName(name, usedNames, MAX_LENGTH_OF_NAME);
    }

    public static String createUniqueName(String name, Set<String> usedNames, int maxLengthOfName) {
        if (!usedNames.contains(name)) {
            return name;
        } else {
            name = stripNumbersOffEndOfName(name);
            name = truncateName(name, maxLengthOfName - 2);
            String newUniqueName = name;
            boolean cleared = false;
            int i = 1;

            while (!cleared) {
                if (i == 10 && name.length() > maxLengthOfName - 3) {
                    name = name.substring(0, name.length() - 1);
                }

                if (i == 100 && name.length() > maxLengthOfName - 4) {
                    name = name.substring(0, name.length() - 1);
                }

                newUniqueName = name + "_" + i;
                boolean foundConflict = false;
                if (usedNames.contains(newUniqueName)) {
                    foundConflict = true;
                }

                if (!foundConflict) {
                    cleared = true;
                } else {
                    ++i;
                }
            }

            return newUniqueName;
        }
    }

    public static String replaceSpacesWithUnderscores(String str) {
        return str.trim().replace(" ", "_");
    }

    public static String makeFirstCharLetter(String candidate) {
        return !Character.isLetter(candidate.charAt(0)) ? "P" + candidate : candidate;
    }

    public static String makeLegalCharacters(String candidate) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < candidate.length(); ++i) {
            char c = candidate.charAt(i);
            switch (c) {
                case '\t':
                case '\n':
                case ' ':
                case '_':
                    sb.append('_');
                    break;
                default:
                    if (Character.isLetterOrDigit(c)) {
                        sb.append(c);
                    }
                    break;
            }
        }

        return sb.toString();
    }

    public static String makeReservedNamePrefixed(String candidate, String[] reservedNames) {
        for (String reservedName : reservedNames) {
            if (candidate.equals(reservedName)) {
                return "P" + candidate;
            }
        }

        return candidate;
    }

    public static String formatNameIfTooLong(JComponent component, String name) {
        FontMetrics fontMetrics = component.getFontMetrics(component.getFont());
        int height = component instanceof JLabel ? 160 : 110;
        if (fontMetrics.stringWidth(name) > height) {
            StringBuilder firstLine = new StringBuilder();
            StringBuilder lastLine = new StringBuilder();
            boolean lineIsDivided = false;
            String divideBy = " ";
            if (!name.contains(divideBy)) {
                divideBy = "-";
            }

            if (!name.contains(divideBy)) {
                divideBy = "/";
            }
            String[] arrayOfString;
            for (int i = 0; i < (arrayOfString = StringUtils.split(divideBy, name)).length; ++i) {
                String each = arrayOfString[i];
                if (!lineIsDivided) {
                    if (fontMetrics.stringWidth(firstLine + divideBy + each) < height) {
                        firstLine.append(each).append(divideBy);
                    } else if (firstLine.length() > 0) {
                        lineIsDivided = true;
                        firstLine = new StringBuilder(ellipsizeText(firstLine.toString().trim(), fontMetrics, height));
                        lastLine = new StringBuilder(each);
                    } else {
                        lineIsDivided = true;
                        firstLine = new StringBuilder(ellipsizeText(each.trim(), fontMetrics, height));
                    }
                } else if (lastLine.length() == 0) {
                    if (fontMetrics.stringWidth(each) >= height) {
                        lastLine = new StringBuilder(ellipsizeText(each, fontMetrics, height));
                        break;
                    }

                    lastLine = new StringBuilder(each);
                } else {
                    if (fontMetrics.stringWidth(lastLine + divideBy + each) >= height) {
                        lastLine = new StringBuilder(ellipsizeText(lastLine + divideBy + each, fontMetrics, height));
                        break;
                    }
                    lastLine.append(divideBy).append(each);
                }
            }

            if (lineIsDivided && (lastLine.length() > 0)) {
                return HtmlUtils.html(HtmlUtils.indentRight(27, HtmlUtils.maxWidth(height, firstLine + HtmlUtils.br() + lastLine)));
            } else {
                return HtmlUtils.toHtml(firstLine.toString(), false);
            }
        }
        return HtmlUtils.toHtml(name, false);
    }

    private static String ellipsizeText(String text, FontMetrics fontMetrics, int height) {
        while (fontMetrics.stringWidth(text) >= height && text.length() > 4) {
            text = text.substring(0, text.length() - 4) + "...";
        }
        return text;
    }
}
