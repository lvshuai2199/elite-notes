package cn.elibot.robot.commons.lang;

import cn.elibot.robot.logger.LogFactory;
import cn.elibot.robot.logger.Logger;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.util.*;

/**
 * Static utility methods pertaining to {@code Class} instances.
 *
 * @author elt
 * @since 1.0
 */
public final class ClassUtils {
    private static final Logger LOG = LogFactory.getLogger(ClassUtils.class);

    private ClassUtils() {
    }

    @SuppressWarnings("unchecked")
    public static <T> T cast(Object target) {
        return (T) target;
    }

    public static <T> Collection<T> getInstancesByName(String... namedClasses)
            throws IllegalAccessException {
        Collection<Class<T>> classesByName = getClassesByName(namedClasses);
        return instantiateClasses(classesByName);
    }

    @SuppressWarnings("unchecked")
    public static <T> Collection<Class<T>> getClassesByName(String... namedClasses) {
        List<Class<T>> result = new ArrayList<>();

        for (String each : namedClasses) {
            try {
                result.add((Class<T>) Class.forName(each));
            } catch (ClassNotFoundException ex) {
                LOG.warn("Failed to find class: " + each, ex);
            }
        }

        return result;
    }

    public static <T> Collection<T> instantiateClasses(Iterable<Class<T>> classes)
            throws IllegalAccessException {
        List<T> result = new ArrayList<>();

        classes.forEach(clazz -> {
            try {
                result.add(clazz.newInstance());
            } catch (InstantiationException | IllegalAccessException e) {
                LOG.warn("Failed to instance class: " + clazz);
            }
        });

        return result;
    }

    public static boolean isInstanceOfAny(Object unknownInstance, Class<?>... classes) {
        return isInstanceOfAny(unknownInstance, Arrays.asList(classes));
    }

    public static boolean isInstanceOfAny(Object unknownInstance, Iterable<Class<?>> classes) {
        Class<?> item;
        Iterator<Class<?>> iterator = classes.iterator();
        do {
            if (!iterator.hasNext()) {
                return false;
            }

            item = iterator.next();
        } while (!item.isInstance(unknownInstance));

        return true;
    }

    public static boolean isAssignableFromAny(Class<?> unknownType, Class<?>... classes) {
        return isAssignableFromAny(unknownType, Arrays.asList(classes));
    }

    public static boolean isAssignableFromAny(Class<?> unknownType, Collection<Class<?>> classes) {
        Class<?> item;
        Iterator<Class<?>> iterator = classes.iterator();
        do {
            if (!iterator.hasNext()) {
                return false;
            }

            item = iterator.next();
        } while (!item.isAssignableFrom(unknownType));

        return true;
    }

    public static String getClassName(Object subject) {
        return subject == null ? "unknown" : subject.getClass().getName();
    }

    public static boolean hasAnnotation(Object object, Class<? extends Annotation> annotationType) {
        return getAnnotation(object, annotationType) != null;
    }

    public static <A extends Annotation> A getAnnotation(Object object, Class<A> annotationType) {
        AnnotatedElement element = null;
        if (object instanceof AnnotatedElement) {
            element = (AnnotatedElement) object;
        } else if (object != null) {
            element = object.getClass();
        }

        return element == null ? null : element.getAnnotation(annotationType);
    }

    public static Class<?> getClass(Object instance) {
        return instance == null ? null : instance.getClass();
    }
}
