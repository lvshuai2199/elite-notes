package cn.elibot.robot.commons.lang;

import cn.elibot.robot.commons.lang.commandline.BaseScriptRunner;
import cn.elibot.robot.commons.lang.commandline.BashScriptRunner;
import cn.elibot.robot.logger.LogFactory;
import cn.elibot.robot.logger.Logger;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Static utility methods pertaining to {@code File} instances.
 *
 * @author elt
 * @since 1.0
 */
public final class FileUtils {
    public static final Charset UTF_8 = StandardCharsets.UTF_8;
    private static final Logger LOG = LogFactory.getLogger(FileUtils.class);
    private static final int MAX_NUMBER = 9999;
    private static final int BUFFER_SIZE = 2 * 1024;

    private FileUtils() {
    }

    public static File getCurrentWorkingDir() {
        return (new File("")).getAbsoluteFile();
    }

    public static boolean copyFile(String sourceFilePath, String destinationFilePath) {
        FileInputStream inputStream = null;
        FileOutputStream outputStream = null;

        try {
            // 创建文件流
            inputStream = new FileInputStream(sourceFilePath);
            outputStream = new FileOutputStream(destinationFilePath);

            // 读取和写入信息
            int bytesRead;
            byte[] buffer = new byte[1024];
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            // 关闭流
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (outputStream != null) {
                    outputStream.getFD().sync();
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    public static boolean filesMove(FileFilter fileFilter, File fromDirectory, File toDirectory) {
        Defense.isCondition(fromDirectory.exists(), "fromDirectory does not exist");
        Defense.isCondition(fromDirectory.isDirectory(), "fromDirectory is not a directory");
        if (!toDirectory.exists()) {
            toDirectory.mkdirs();
        }

        Defense.isCondition(toDirectory.isDirectory(), "toDirectory is not a directory");

        try {
            File[] files = fromDirectory.listFiles(fileFilter);
            if (files == null) {
                return false;
            }

            Arrays.stream(files).forEach(file -> {
                file.renameTo(new File(toDirectory, file.getName()));
            });

            return true;
        } catch (Exception ex) {
            LOG.error("No files moved", ex);
            return false;
        }
    }

    public static boolean filesDelete(FileFilter fileFilter, File fromDirectory) {
        Defense.isCondition(fromDirectory.exists(), "fromDirectory does not exist");
        Defense.isCondition(fromDirectory.isDirectory(), "fromDirectory is not a directory");

        try {
            File[] files = fromDirectory.listFiles(fileFilter);
            if (files != null) {
                for (File file : files) {
                    file.delete();
                }
            }

            return true;
        } catch (Exception e) {
            LOG.error("No files were deleted", e);
            return false;
        }
    }

    public static String getNextAvailableFileName(File directory, String defaultFileName, String extension) {
        int i = 1;

        while (true) {
            String ret = defaultFileName + "_" + i;
            if (i > MAX_NUMBER) {
                throw new NumberIsTooLargeException(MAX_NUMBER);
            }

            if (!(new File(directory, ret + extension)).exists()) {
                return ret;
            }

            ++i;
        }
    }

    public static void copy(String sourceFilename, String destinationFilename) throws IOException {
        copy(new File(sourceFilename), new File(destinationFilename));
    }

    public static void copy(File srcFile, File destFile) throws IOException {
        if (!srcFile.exists()) {
            throw new FileNotFoundException(srcFile.getAbsolutePath());
        } else {
            try (FileChannel source = (new FileInputStream(srcFile)).getChannel(); FileChannel destination = (new FileOutputStream(
                destFile)).getChannel()) {
                destination.transferFrom(source, 0L, source.size());
            } catch (Exception ignore) {

            }
        }
    }

    public static void copy(URL source, File destination) throws IOException {
        InputStream input = source.openStream();
        copy(input, destination);
    }

    public static void copy(URL source, File destination, int connectionTimeout, int readTimeout) throws IOException {
        URLConnection connection = source.openConnection();
        connection.setConnectTimeout(connectionTimeout);
        connection.setReadTimeout(readTimeout);
        InputStream input = connection.getInputStream();
        copy(input, destination);
    }

    public static void copy(InputStream source, File destination) throws IOException {
        try {
            FileOutputStream output = openOutputStream(destination);

            try {
                IOUtils.copy(source, output);
                output.getFD().sync();
                output.close();
            } finally {
                IOUtils.closeQuietly(output);
            }
        } finally {
            IOUtils.closeQuietly(source);
        }
    }

    public static FileOutputStream openOutputStream(File file) throws IOException {
        return openOutputStream(file, false);
    }

    public static FileOutputStream openOutputStream(File file, boolean append) throws IOException {
        if (file.exists()) {
            if (file.isDirectory()) {
                throw new IOException("File '" + file + "' exists, but a directory");
            }

            if (!file.canWrite()) {
                throw new IOException("File '" + file + "' Unable to write");
            }
        } else {
            File parentFile = file.getParentFile();
            if (parentFile != null && !parentFile.mkdirs() && !parentFile.isDirectory()) {
                throw new IOException("Directory '" + parentFile + "' could not be built");
            }
        }

        return new FileOutputStream(file, append);
    }

    public static void copyDir(File srcDir, File targetDir) throws IOException {
        if (targetDir.isDirectory()) {
            if (srcDir.isDirectory()) {
                File desDir = new File(targetDir.getPath() + File.separator + srcDir.getName());
                recursiveCopyFiles(srcDir, desDir);
            } else {
                recursiveCopyFiles(srcDir, targetDir);
            }
        }
    }

    private static void recursiveCopyFiles(File src, File des) throws IOException {
        if (src.exists()) {
            String cmd = "cp -r -P \"" + src.getPath() + "\" \"" + des.getPath() + "\"";
            BaseScriptRunner runner = new BashScriptRunner(cmd);
            runner.execute();
        }

    }

    public static void writeToFile(String text, File file) {
        FileWriter writer = null;

        try {
            writer = new FileWriter(file);
            writer.append(text);
            writer.flush();
        } catch (IOException ex) {
            throw new RuntimeException("File is not saved: " + file.getName(), ex);
        } finally {
            IOUtils.closeQuietly(writer);
        }

    }

    public static String readFromFile(File file, String defaultText) {
        try {
            return StreamUtils.readFromStream(new FileInputStream(file), defaultText);
        } catch (FileNotFoundException ex) {
            LOG.error("File not found: " + file.getName(), ex);
            return defaultText;
        }
    }

    public static String removeSuffix(String name) {
        int index = name.lastIndexOf(".");
        return index >= 0 ? name.substring(0, index) : name;
    }


    public static String removeSuffixBySuffixName(String name, String suffix) {
        int index = name.lastIndexOf(".");
        if (name.substring(index + 1, name.length()).equalsIgnoreCase(suffix)) {
            return index >= 0 ? name.substring(0, index) : name;
        }
        return name;
    }

    public static void packZip(List<File> sourceList, String output) {
        ZipOutputStream zos = null;
        try {
            FileOutputStream out = new FileOutputStream(output);
            zos = new ZipOutputStream(out);
            for (File srcFile : sourceList) {
                writeZipFile(srcFile, zos, srcFile.getName(), true);
            }
        } catch (Exception e) {
            LOG.error("zip error from ZipUtils", e);
        } finally {
            if (zos != null) {
                try {
                    zos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    LOG.error(e.getMessage(), e);
                }
            }
        }
    }

    /**
     * 递归压缩方法
     *
     * @param sourceFile       源文件
     * @param zos              zip输出流
     * @param name             压缩后的名称
     * @param KeepDirStructure 是否保留原来的目录结构,true:保留目录结构;
     *                         false:所有文件跑到压缩包根目录下(注意：不保留目录结构可能会出现同名文件,会压缩失败)
     * @throws Exception
     */
    private static void writeZipFile(File sourceFile, ZipOutputStream zos, String name, boolean KeepDirStructure) throws Exception {
        byte[] buf = new byte[BUFFER_SIZE];
        if (sourceFile.isFile()) {
            // 向zip输出流中添加一个zip实体，构造器中name为zip实体的文件的名字
            zos.putNextEntry(new ZipEntry(name));
            // copy文件到zip输出流中
            int len;
            FileInputStream in = new FileInputStream(sourceFile);
            while ((len = in.read(buf)) != -1) {
                zos.write(buf, 0, len);
            }
            // Complete the entry
            zos.closeEntry();
            in.close();
        } else {
            File[] listFiles = sourceFile.listFiles();
            if (listFiles == null || listFiles.length == 0) {
                // 需要保留原来的文件结构时,需要对空文件夹进行处理
                if (KeepDirStructure) {
                    // 空文件夹的处理
                    zos.putNextEntry(new ZipEntry(name + "/"));
                    // 没有文件，不需要文件的copy
                    zos.closeEntry();
                }

            } else {
                for (File file : listFiles) {
                    // 判断是否需要保留原来的文件结构
                    if (KeepDirStructure) {
                        // 注意：file.getName()前面需要带上父文件夹的名字加一斜杠,
                        // 不然最后压缩包中就不能保留原来的文件结构,即：所有文件都跑到压缩包根目录下了
                        writeZipFile(file, zos, name + "/" + file.getName(), KeepDirStructure);
                    } else {
                        writeZipFile(file, zos, file.getName(), KeepDirStructure);
                    }

                }
            }
        }
    }

    public static void unZip(File zipFile, File outputFolder) {
        byte[] buffer = new byte[1024];

        try {
            if (!outputFolder.exists()) {
                outputFolder.mkdir();
            }

            ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(zipFile));
            ZipEntry ze = zipInputStream.getNextEntry();
            for (; ze != null; ze = zipInputStream.getNextEntry()) {
                String fileName = ze.getName();
                File newFile = new File(outputFolder + File.separator + fileName);
                if (LOG.isDebugEnabled()) {
                    LOG.debug("file unzip : " + newFile.getAbsoluteFile());
                }
                if (ze.isDirectory()) {
                    newFile.mkdirs();
                } else {
                    (new File(newFile.getParent())).mkdirs();
                    FileOutputStream fileOutputStream = new FileOutputStream(newFile);

                    int length;
                    while ((length = zipInputStream.read(buffer)) > 0) {
                        fileOutputStream.write(buffer, 0, length);
                    }

                    fileOutputStream.close();
                }
            }

            zipInputStream.closeEntry();
            zipInputStream.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

    public static void copyDirectory(File src, File des) throws IOException {
        if (src.isDirectory()) {
            if (!des.exists()) {
                if (!des.mkdirs()) {
                    return;
                }
            }

            String[] fileNames = src.list();
            if (fileNames != null) {
                for (String file : fileNames) {
                    File srcFile = new File(src, file);
                    File desFile = new File(des, file);
                    copyDirectory(srcFile, desFile);
                }
            }

            return;
        }

        try (InputStream in = new FileInputStream(src); FileOutputStream out = new FileOutputStream(des)) {
            byte[] buffer = new byte[1024];

            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
        }
    }

    public static void appendToFile(File file, String text) {
        String content = readFromFile(file, "");
        content = content + text;
        writeToFile(content, file);
    }

    public static boolean allowedFileName(String fileName) {
        return !fileName.startsWith(".") && !fileName.contains("&") && !fileName.contains("*") && !fileName.contains(
            "/") && !fileName.contains(";") && !fileName.contains(":") && !fileName.contains("?") && !fileName.contains(
            "\"") && !fileName.contains("<") && !fileName.contains(">") && !fileName.contains("|") && !fileName.contains("\\");
    }

    public static String relativize(File subPath, File path) {
        return subPath.toURI().relativize(path.toURI()).getPath();
    }

    public static String getPath(File file) {
        if (file == null) {
            return "";
        } else {
            return file.isDirectory() ? file.getPath() : file.getParent();
        }
    }

    public static String getSuffix(String file) {
        if (file == null) {
            return null;
        }

        String ext = null;
        int i = file.lastIndexOf(46);
        if (i >= 0 && i < file.length() - 1) {
            ext = file.substring(i + 1).toLowerCase();
        }

        return ext;
    }

    public static String getSuffixWithCase(String file) {
        if (file == null) {
            return null;
        }

        String ext = null;
        int i = file.lastIndexOf(46);
        if (i >= 0 && i < file.length() - 1) {
            ext = file.substring(i + 1);
        }

        return ext;
    }

    public static String getSuffix(File f) {
        return f == null ? null : getSuffix(f.getName());
    }

    public static String getRandomFilename(String suffix) {
        return UUID.randomUUID().toString() + "." + suffix;
    }

    public static boolean delete(File path) {
        boolean ret = true;
        if (path.isDirectory()) {
            File[] files = path.listFiles();
            if (files != null) {
                for (File file : files) {
                    ret &= delete(file);
                }
            }
        }

        ret &= path.delete();
        return ret;
    }

    public static File createTempDir() {
        File tmpDir = new File("/tmp/");
        if (!tmpDir.exists() && !tmpDir.mkdirs()) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Unable to create tmp dir " + tmpDir);
            }
            return null;
        } else {
            File retDir;
            int count = 0;

            do {
                retDir = new File(tmpDir, getRandomFilename("d"));
                ++count;
            } while (retDir.exists() && count < 50);

            if (retDir.exists()) {
                LOG.error(count + " attempt to generate a nonexistent directory name failed, aborting");
                return null;
            } else if (!retDir.mkdir()) {
                LOG.error("Failed to create tmp directory");
                return null;
            } else {
                return retDir;
            }
        }
    }

    public static File createDir(String path) {
        File tmpDir = new File(path);
        if (!tmpDir.exists() && !tmpDir.mkdirs()) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Unable to create tmp dir " + tmpDir);
            }
            return null;
        }
        return tmpDir;
    }

    public static Properties readPropertiesFromFile(String file) throws IOException {
        Properties ret = new Properties();

        try (FileInputStream inFile = new FileInputStream(file)) {
            ret.load(inFile);
        }

        return ret;
    }

    public static void writePropertiesToFile(String fileNameAndPath, Properties properties) throws IOException {
        try (FileOutputStream outFile = new FileOutputStream(fileNameAndPath)) {
            properties.store(outFile, "");
        }

    }

    public static void writePropertiesToFile(String fileNameAndPath, RichProperties properties) throws IOException {
        try (FileOutputStream outFile = new FileOutputStream(fileNameAndPath)) {
            properties.store(outFile);
        }

    }

    public enum FileSize {
        /**
         * MB
         */
        MB(1048576),

        /**
         * KB
         */
        KB(1024);

        private final int converterPolicy;

        FileSize(int converter) {
            this.converterPolicy = converter;
        }

        public int toBits(int amount) {
            return this.converterPolicy * amount;
        }
    }

    private static class NumberIsTooLargeException extends RuntimeException {
        public NumberIsTooLargeException(Number maxNumber) {
            super("The number is too large:  " + maxNumber);
        }
    }
}
