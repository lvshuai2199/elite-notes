package cn.elibot.robot.commons.lang;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ColorModel;
import java.awt.image.DirectColorModel;
import java.awt.image.FilteredImageSource;
import java.awt.image.RGBImageFilter;
import java.util.Objects;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 * Utility class for loading, scaling, and tinting images and icons.
 *
 * <p>Provides methods to:
 * <ul>
 *   <li>Scale {@link ImageIcon}, {@link Icon}, or {@link Image} instances to a given height
 *       while preserving aspect ratio.</li>
 *   <li>Apply a color tint to {@link ImageIcon}, {@link Icon}, or {@link Image} instances.</li>
 *   <li>Combine tinting and scaling in one call.</li>
 * </ul>
 *
 * @author ELITECO SDK API
 */
public class ImageUtils {
    /**
     * Scales the given {@link ImageIcon} to the specified height, preserving aspect ratio.
     *
     * <p>If scaling fails, returns {@code null}.
     *
     * @param imageIcon  the original image icon to scale
     * @param iconHeight the desired height, in pixels
     * @return the scaled {@link ImageIcon}, or {@code null} if scaling fails
     */
    public static ImageIcon scaleIcon(final ImageIcon imageIcon, double iconHeight) {
        try {
            double scaleFactor = iconHeight / imageIcon.getIconHeight();
            int scaledWidth = (int) (imageIcon.getIconWidth() * scaleFactor);
            int scaledHeight = (int) (imageIcon.getIconHeight() * scaleFactor);
            Image scaledImage = imageIcon.getImage().getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
            return new ImageIcon(scaledImage);
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * Scales the given {@link Icon} to the specified height, preserving aspect ratio.
     *
     * <p>If scaling fails or the icon is not an {@code ImageIcon}, returns {@code null}.
     *
     * @param icon       the original icon to scale
     * @param iconHeight the desired height, in pixels
     * @return the scaled {@link Icon}, or {@code null} if scaling fails
     */
    public static Icon scaleIcon(final Icon icon, double iconHeight) {
        try {
            double scaleFactor = iconHeight / icon.getIconHeight();
            int scaledWidth = (int) (icon.getIconWidth() * scaleFactor);
            int scaledHeight = (int) (icon.getIconHeight() * scaleFactor);
            Image scaledImage = ((ImageIcon) icon).getImage().getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
            return new ImageIcon(scaledImage);
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * Scales the given {@link Image} to the specified height, preserving aspect ratio.
     *
     * <p>If scaling fails, returns {@code null}.
     *
     * @param image  the original image to scale
     * @param height the desired height, in pixels
     * @return the scaled {@link Image}, or {@code null} if scaling fails
     */
    public static Image scaleImage(final Image image, double height) {
        try {
            ImageIcon imageIcon = new ImageIcon(image);
            double scaleFactor = height / imageIcon.getIconHeight();
            int scaledWidth = (int) (imageIcon.getIconWidth() * scaleFactor);
            int scaledHeight = (int) (imageIcon.getIconHeight() * scaleFactor);
            return imageIcon.getImage().getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * Tints the given {@link ImageIcon} with the specified color and scales it to the given height,
     * preserving aspect ratio.
     *
     * @param imageIcon the original image icon
     * @param color     the tint color to apply
     * @param height    the desired height, in pixels
     * @return the tinted and scaled {@link ImageIcon}, or {@code null} if processing fails
     */
    public static ImageIcon changeColorAndScale(final ImageIcon imageIcon, Color color, double height) {
        return scaleIcon(changeIconColor(imageIcon, color), height);
    }

    /**
     * Tints the given {@link Icon} with the specified color and scales it to the given height,
     * preserving aspect ratio.
     *
     * @param icon   the original icon
     * @param color  the tint color to apply
     * @param height the desired height, in pixels
     * @return the tinted and scaled {@link ImageIcon}, or {@code null} if processing fails
     */
    public static ImageIcon changeColorAndScale(final Icon icon, Color color, double height) {
        return scaleIcon(changeIconColor(icon, color), height);
    }

    /**
     * Tints the given {@link ImageIcon} with the specified color.
     *
     * <p>If tinting fails, returns {@code null}.
     *
     * @param imageIcon the original image icon
     * @param color     the tint color to apply
     * @return the tinted {@link ImageIcon}, or {@code null} if processing fails
     */
    public static ImageIcon changeIconColor(final ImageIcon imageIcon, Color color) {
        try {
            Image sourceImg = imageIcon.getImage();
            Image tinted = Objects.requireNonNull(changeImageColor(sourceImg, color));
            return new ImageIcon(tinted);
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * Tints the given {@link Icon} with the specified color.
     *
     * <p>If the icon is not an {@code ImageIcon}, returns {@code null}.
     *
     * @param icon  the original icon
     * @param color the tint color to apply
     * @return the tinted {@link ImageIcon}, or {@code null} if the input is not an ImageIcon
     */
    public static ImageIcon changeIconColor(final Icon icon, Color color) {
        if (icon instanceof ImageIcon) {
            return changeIconColor((ImageIcon) icon, color);
        }
        return null;
    }

    /**
     * Tints the given {@link Image} with the specified color.
     *
     * <p>If tinting fails, returns {@code null}.
     *
     * @param sourceImage the original image to tint
     * @param color       the tint color to apply
     * @return the tinted {@link Image}, or {@code null} if processing fails
     */
    public static Image changeImageColor(final Image sourceImage, Color color) {
        try {
            ImageFilter filter = new ImageFilter(color);
            return Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(sourceImage.getSource(), filter));
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * Internal image filter that replaces each pixel's color with the specified paint color,
     * preserving the original alpha channel.
     */
    private static class ImageFilter extends RGBImageFilter {
        private final Color paintColor;

        /**
         * Constructs an ImageFilter with the given paint color.
         *
         * @param c the color to use for tinting
         */
        ImageFilter(Color c) {
            canFilterIndexColorModel = true;
            paintColor = c;
        }

        @Override
        public int filterRGB(int x, int y, int rgb) {
            DirectColorModel cm = (DirectColorModel) ColorModel.getRGBdefault();
            int alpha = cm.getAlpha(rgb);
            int red = paintColor.getRed();
            int green = paintColor.getGreen();
            int blue = paintColor.getBlue();
            return (alpha << 24) | (red << 16) | (green << 8) | blue;
        }
    }
}
