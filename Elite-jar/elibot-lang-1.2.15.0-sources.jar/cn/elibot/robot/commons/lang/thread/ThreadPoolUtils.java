package cn.elibot.robot.commons.lang.thread;

import org.apache.commons.lang3.concurrent.BasicThreadFactory;

import java.util.concurrent.*;

/**
 * Thread pool utils
 *
 * @author elt
 */
public class ThreadPoolUtils {
    public static ScheduledThreadPoolExecutor timerThreadPool = new ScheduledThreadPoolExecutor(16,
            new BasicThreadFactory.Builder().namingPattern("timer-schedule-pool-%d").daemon(true).build(),
            new ThreadPoolExecutor.DiscardPolicy());
    /**
     * IO intensive max thread pool size
     */
    private static int ioIntensiveMaxPoolSize = 64;

    private ThreadPoolUtils() {
    }

    /**
     * New single thread pool
     *
     * @param name the thread prefix name
     * @return a {@link Executor} instance
     */
    public static Executor newSingleThreadExecutor(String name) {
        return new ThreadPoolExecutor(1, 1,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(),
                new NamedThreadFactory(name));
    }

    public static ExecutorService newCachedThreadPool(String name) {
        return new ThreadPoolExecutor(0, Integer.MAX_VALUE,
                60L, TimeUnit.SECONDS,
                new SynchronousQueue<Runnable>(),
                new NamedThreadFactory(name));
    }
    /**
     * New cpu intensive thread pool
     *
     * @param name the thread prefix name
     * @return a {@link Executor} instance
     */
    public static Executor newCpuIntensiveThreadExecutor(String name) {
        int coreSize = Runtime.getRuntime().availableProcessors();
        int maxPoolSize = coreSize * 2;
        return new ThreadPoolExecutor(coreSize, maxPoolSize,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(),
                new NamedThreadFactory(name));
    }

    /**
     * New io intensive thread pool
     *
     * @param name the thread prefix name
     * @return a {@link Executor} instance
     */
    public static Executor newIoIntensiveThreadExecutor(String name) {
        int coreSize = Runtime.getRuntime().availableProcessors();
        int maxPoolSize = coreSize * 2;
        return new ThreadPoolExecutor(coreSize, maxPoolSize,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(),
                new NamedThreadFactory(name));
    }

}
