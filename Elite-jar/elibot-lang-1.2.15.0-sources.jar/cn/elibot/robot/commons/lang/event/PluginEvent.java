package cn.elibot.robot.commons.lang.event;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleEvent;

import java.util.EventObject;
import java.util.Objects;

/**
 * Plugin Event
 *
 * @author elt
 */
public class PluginEvent extends EventObject {
    /**
     * Notifies this listener that the given view is unknown.
     */
    public static final int UNKNOWN = 0x00000000;

    /**
     * Notifies this listener that the given view is being started.
     */
    public static final int STARTING = 0x00000001;

    /**
     * Notifies this listener that the given view has been started.
     */
    public static final int STARTED = 0x00000002;

    /**
     * Notifies this listener that the given view has been completed.
     */
    public static final int COMPLETED = 0x00000004;

    private int type;
    private Bundle bundle;

    public PluginEvent(int type, Bundle bundle) {
        super(Objects.requireNonNull(bundle, "bundle not allow null."));
        this.type = type;
        this.bundle = bundle;
    }

    public static PluginEvent newEvent(BundleEvent event) {
        return new PluginEvent(getTypeFromBundleEventType(event.getType()), event.getBundle());
    }

    public static PluginEvent newEvent(BundleEvent event, int defaultType) {
        int eventType = getTypeFromBundleEventType(event.getType());
        if (eventType == UNKNOWN) {
            eventType = defaultType;
        }

        return new PluginEvent(eventType, event.getBundle());
    }

    public static PluginEvent newEvent(int type, Bundle bundle) {
        return new PluginEvent(type, bundle);
    }

    public static int getTypeFromBundleEventType(int type) {
        int result = UNKNOWN;
        switch (type) {
            case BundleEvent.STARTED:
                result = STARTED;
                break;
            case BundleEvent.STARTING:
                result = STARTING;
                break;
            default:
                break;
        }

        return result;
    }

    public int getType() {
        return type;
    }

    public Bundle getBundle() {
        return bundle;
    }
}
