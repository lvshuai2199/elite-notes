package cn.elibot.robot.commons.lang.concurrent;

/**
 * @author wuyongkang
 */
public abstract class ParallelTask extends Task {
    public ParallelTask(String name) {
        super(name);
    }

    public ParallelTask(String name, boolean showCancelButton) {
        super(name, showCancelButton);
    }

    public ParallelTask(String name, int progressTicks) {
        super(name, progressTicks);
    }

    public ParallelTask(String name, int progressTicks, boolean showCancelButton) {
        super(name, progressTicks, showCancelButton);
    }
}
