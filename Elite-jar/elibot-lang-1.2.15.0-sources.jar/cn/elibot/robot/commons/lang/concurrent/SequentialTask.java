package cn.elibot.robot.commons.lang.concurrent;

/**
 * @author wuyongkang
 */
public abstract class SequentialTask extends Task {
    public SequentialTask(String name) {
        super(name);
    }

    public SequentialTask(String name, boolean showCancelButton) {
        super(name, showCancelButton);
    }

    public SequentialTask(String name, int progressTicks) {
        super(name, progressTicks);
    }

    public SequentialTask(String name, int progressTicks, boolean showCancelButton) {
        super(name, progressTicks, showCancelButton);
    }
}
