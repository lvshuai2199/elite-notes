package cn.elibot.robot.commons.lang.concurrent;

/**
 * @author wuyongkang
 */
public abstract class Task implements Runnable {
    private boolean cancelled;
    private final String name;
    private final int progressTicks;
    private boolean isCancellable;

    public Task(String name) {
        this(name, 0, false);
    }

    public Task(String name, boolean isCancellable) {
        this(name, 0, isCancellable);
    }

    public Task(String name, int progressTicks) {
        this(name, progressTicks, false);
    }

    public Task(String name, int progressTicks, boolean isCancellable) {
        this.cancelled = false;
        this.name = name;
        this.progressTicks = progressTicks;
        this.isCancellable = isCancellable;
    }

    public String getName() {
        return this.name;
    }

    public int getProgressTicks() {
        return this.progressTicks;
    }

    public void setIsCancellable(boolean isCancellable) {
        this.isCancellable = isCancellable;
    }

    public void onBefore() {
    }

    public void onAfter() {
    }

    public void onError(Throwable throwable) {
    }

    public boolean isCancellable() {
        return this.isCancellable;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void cancel() {
        this.cancelled = true;
    }
}
