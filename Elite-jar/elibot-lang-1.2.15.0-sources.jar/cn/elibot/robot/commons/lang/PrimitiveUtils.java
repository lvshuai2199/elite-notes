package cn.elibot.robot.commons.lang;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;

/**
 * Static utility methods pertaining to {@code Primitive} instances.
 *
 * @author elt
 * @since 1.0
 */
public final class PrimitiveUtils {
    public static final DecimalFormat WHOLE_NUMBER_FORMAT = new DecimalFormat("0", new DecimalFormatSymbols(Locale.ENGLISH));

    static {
        WHOLE_NUMBER_FORMAT.setRoundingMode(RoundingMode.HALF_UP);
    }

    private PrimitiveUtils() {
    }

    public static double between(double value, double min, double max) {
        if (min > max) {
            return between(value, max, min);
        }
        value = Math.min(value, max);
        value = Math.max(value, min);
        return value;
    }

    public static int between(int value, int min, int max) {
        if (min > max) {
            return between(value, max, min);
        }

        value = Math.min(value, max);
        value = Math.max(value, min);
        return value;
    }

    public static boolean isWithinRange(double value, double min, double max) {
        return value >= min && value <= max;
    }

    public static double parseDouble(String text, double defaultValue) {
        try {
            return parseDouble(text);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    public static double parseDouble(String text) {
        return Double.parseDouble(text.replace(",", "."));
    }

    public static float parseFloat(String text, float defaultValue) {
        try {
            return parseFloat(text);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    public static float parseFloat(String text) {
        return Float.parseFloat(text.replace(",", "."));
    }

    public static int parseInteger(String text, int defaultValue) {
        try {
            return Integer.parseInt(text);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    public static boolean parseBoolean(String value, boolean defaultValue) {
        try {
            return Boolean.parseBoolean(value);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    @SuppressWarnings("unchecked")
    public static <T extends Enum<T>> T parseEnum(String value, Class<T> type, T defaultValue) {
        try {
            Enum[] enums = type.getEnumConstants();
            for (Enum each : enums) {
                if (value.equalsIgnoreCase(each.name())) {
                    return (T) each;
                }
            }

            return Enum.valueOf(type, value);
        } catch (Exception ignore) {
            return defaultValue;
        }
    }

    @SuppressWarnings("unchecked")
    public static <T extends Enum<T>> T[] parseEnumArray(String[] values, Class<T> type) {
        List<T> res = new ArrayList<>();

        for (String value : values) {
            res.add(parseEnum(value, type, null));
        }

        return (T[]) (res.toArray());
    }

    public static int[] parseIntegerArray(String[] strings) {
        int[] res = new int[strings.length];

        for (int i = 0; i < strings.length; ++i) {
            res[i] = Integer.parseInt(strings[i]);
        }

        return res;
    }

    public static short[] parseShortArray(String[] strings) {
        short[] res = new short[strings.length];

        for (int i = 0; i < strings.length; ++i) {
            res[i] = Short.parseShort(strings[i]);
        }

        return res;
    }

    public static byte[] parseByteArray(String[] strings) {
        byte[] res = new byte[strings.length];

        for (int i = 0; i < strings.length; ++i) {
            res[i] = Byte.parseByte(strings[i]);
        }

        return res;
    }

    public static char[] parseCharArray(String[] strings) {
        char[] res = new char[strings.length];

        for (int i = 0; i < strings.length; ++i) {
            res[i] = strings[i].charAt(0);
        }

        return res;
    }

    public static long[] parseLongArray(String[] strings) {
        long[] res = new long[strings.length];

        for (int i = 0; i < strings.length; ++i) {
            res[i] = Long.parseLong(strings[i]);
        }

        return res;
    }

    public static float[] parseFloatArray(String[] strings) {
        float[] res = new float[strings.length];

        for (int i = 0; i < strings.length; ++i) {
            res[i] = Float.parseFloat(strings[i]);
        }

        return res;
    }

    public static double[] parseDoubleArray(String[] strings) {
        double[] res = new double[strings.length];

        for (int i = 0; i < strings.length; ++i) {
            res[i] = parseDouble(strings[i]);
        }

        return res;
    }

    public static boolean[] parseBooleanArray(String[] strings) {
        boolean[] res = new boolean[strings.length];

        for (int i = 0; i < strings.length; ++i) {
            res[i] = Boolean.parseBoolean(strings[i]);
        }

        return res;
    }

    public static int getDecimals(double value) {
        return (new BigDecimal(Double.toString(value))).stripTrailingZeros().scale();
    }

    public static String moveNumberIfLower(String leader, String follower) {
        if (StringUtils.isNullOrOnlyWhitespace(leader) ||
                StringUtils.isNullOrOnlyWhitespace(follower)) {
            return null;
        }

        try {
            double leaderDouble = parseDouble(leader);
            double followerDouble = parseDouble(follower);
            return leaderDouble <= followerDouble ? leader : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static double applyDecimalFormat(DecimalFormat format, double number) {
        return parseDouble(format.format(number));
    }

    public static boolean[] initBooleanArray(boolean withValue, int length) {
        return initBooleanArray(new boolean[length], withValue);
    }

    public static boolean[] initBooleanArray(boolean[] array, boolean value) {
        Arrays.fill(array, value);
        return array;
    }

    public static double[] initDoubleArray(double withValue, int length) {
        return initDoubleArray(new double[length], withValue);
    }

    public static double[] initDoubleArray(double[] array, double value) {
        Arrays.fill(array, value);
        return array;
    }

    public static int[] initIntArray(int[] array, int value) {
        Arrays.fill(array, value);
        return array;
    }

    public static int[] initIntArray(int withValue, int ofLength) {
        return initIntArray(new int[ofLength], withValue);
    }

    public static byte[] initByteArray(byte[] array, byte value) {
        Arrays.fill(array, value);
        return array;
    }

    public static <T> T[] initArray(T[] arr, T value) {
        Arrays.fill(arr, value);
        return arr;
    }

    public static boolean isInteger(String uncheckedStr) {
        if (StringUtils.isNullOrOnlyWhitespace(uncheckedStr)) {
            return false;
        } else {
            Scanner sca = new Scanner(uncheckedStr);
            if (sca.hasNextInt()) {
                sca.nextInt();
                return !sca.hasNext();
            } else {
                return false;
            }
        }
    }

    public static boolean allSameValue(boolean[] verifiedAsToggled, boolean b) {
        for (boolean value : verifiedAsToggled) {
            if (value != b) {
                return false;
            }
        }

        return true;
    }
}
