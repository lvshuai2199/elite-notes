package cn.elibot.robot.commons.lang.translation;

import cn.elibot.robot.commons.lang.annotation.*;

/**
 * Used to provide a nice interface over the
 * translated strings in file units.units.properties
 * and of course it's locale specific implementations
 *
 * @author shi
 */
public interface UnitsResource {
	/**
	 * UNIT_KG
	 *
	 * @return String
    */
	@Key("UNIT_KG")
	String unitKg();

	/**
	 * UNIT_rad_s
	 *
	 * @return String
    */
	@Key("UNIT_rad_s")
	String unitRadS();

	/**
	 * UNIT_s
	 *
	 * @return String
    */
	@Key("UNIT_s")
	String unitS();

	/**
	 * UNIT_Amps
	 *
	 * @return String
    */
	@Key("UNIT_Amps")
	String unitAmps();

	/**
	 * UNIT_seconds
	 *
	 * @return String
    */
	@Key("UNIT_seconds")
	String unitSeconds();

	/**
	 * UNIT_in_s
	 *
	 * @return String
    */
	@Key("UNIT_in_s")
	String unitInS();

	/**
	 * UNIT_kg_m_s
	 *
	 * @return String
    */
	@Key("UNIT_kg_m_s")
	String unitKgMS();

	/**
	 * UNIT_MM
	 *
	 * @return String
    */
	@Key("UNIT_MM")
	String unitMm();

	/**
	 * UNIT_m_s2
	 *
	 * @return String
    */
	@Key("UNIT_m_s2")
	String unitMS2();

	/**
	 * revolutions
	 *
	 * @return String
    */
	@Key("revolutions")
	String revolutions();

	/**
	 * UNIT_rad
	 *
	 * @return String
    */
	@Key("UNIT_rad")
	String unitRad();

	/**
	 * UNIT_Ms
	 *
	 * @return String
    */
	@Key("UNIT_Ms")
	String unitMs();

	/**
	 * UNIT_DEG_C
	 *
	 * @return String
    */
	@Key("UNIT_DEG_C")
	String unitDegC();

	/**
	 * UNIT_deg_F
	 *
	 * @return String
    */
	@Key("UNIT_deg_F")
	String unitDegF();

	/**
	 * UNIT_deg_s2
	 *
	 * @return String
    */
	@Key("UNIT_deg_s2")
	String unitDegS2();

	/**
	 * UNIT_lb_force
	 *
	 * @return String
    */
	@Key("UNIT_lb_force")
	String unitLbForce();

	/**
	 * UNIT_lbft
	 *
	 * @return String
    */
	@Key("UNIT_lbft")
	String unitLbft();

	/**
	 * UNIT_lb_in_s
	 *
	 * @return String
    */
	@Key("UNIT_lb_in_s")
	String unitLbInS();

	/**
	 * UNIT_V
	 *
	 * @return String
    */
	@Key("UNIT_V")
	String unitV();

	/**
	 * UNIT_W
	 *
	 * @return String
    */
	@Key("UNIT_W")
	String unitW();

	/**
	 * UNIT_degrees
	 *
	 * @return String
    */
	@Key("UNIT_degrees")
	String unitDegrees();

	/**
	 * UNIT_lb
	 *
	 * @return String
    */
	@Key("UNIT_lb")
	String unitLb();

	/**
	 * UNIT_N
	 *
	 * @return String
    */
	@Key("UNIT_N")
	String unitN();

	/**
	 * UNIT_in_s2
	 *
	 * @return String
    */
	@Key("UNIT_in_s2")
	String unitInS2();

	/**
	 * UNIT_M
	 *
	 * @return String
    */
	@Key("UNIT_M")
	String unitM();

	/**
	 * UNIT_NM
	 *
	 * @return String
    */
	@Key("UNIT_NM")
	String unitNm();

	/**
	 * UNIT_m_s
	 *
	 * @return String
    */
	@Key("UNIT_m_s")
	String unitMS();

	/**
	 * UNIT_deg_s
	 *
	 * @return String
    */
	@Key("UNIT_deg_s")
	String unitDegS();

	/**
	 * UNIT_mA
	 *
	 * @return String
    */
	@Key("UNIT_mA")
	String unitMa();

	/**
	 * UNIT_in
	 *
	 * @return String
    */
	@Key("UNIT_in")
	String unitIn();

	/**
	 * UNIT_MM_S2
	 *
	 * @return String
    */
	@Key("UNIT_MM_S2")
	String unitMmS2();

	/**
	 * UNIT_Volts
	 *
	 * @return String
    */
	@Key("UNIT_Volts")
	String unitVolts();

	/**
	 * UNIT_MM_S
	 *
	 * @return String
    */
	@Key("UNIT_MM_S")
	String unitMmS();

	/**
	 * UNIT_A
	 *
	 * @return String
    */
	@Key("UNIT_A")
	String unitA();

	/**
	 * Intended for use where the keyName is concatenated
     * together, such as when using error codes from the controller
	 *
	 * @param key the resource key
	 * @return a {@link String} resource value
	 */
	String get(String key);

	/**
	 * Allows a check to be made to ensure the given key is available
	 *
	 * @param key the resource key
	 * @return a {@link Boolean} value if the resource contain the key
	 */
	boolean contains(String key);

	/**
	 * Return all the keys
	 * @return all the keys
	 */
	Iterable<String> getKeys();
}