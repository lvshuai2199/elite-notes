package cn.elibot.robot.commons.lang.translation;

import java.util.ResourceBundle;
import java.util.Locale;
import cn.elibot.robot.commons.lang.resource.*;

import javax.inject.Inject;

/**
 * Test Resource Class, This class is generated.
 *
 * @author elt
 */
public class UnitsResourceImpl implements UnitsResource {
	
	private final String fileName = "i18n.units.units";
	private ResourceBundle resource;
	private ResourceBundle defaultResource;

	@Inject
	public UnitsResourceImpl(LocaleProvider provider) {
		this(provider.getLocale());
	}

	public UnitsResourceImpl(Locale locale) {
		defaultResource = ResourceBundle.getBundle(fileName, Locale.ROOT, new UTF8Control());
		resource = ResourceBundle.getBundle(fileName, locale, new UTF8Control());
	}
	
	private UnitsResourceImpl(ResourceBundle defaultBundle) {
		defaultResource = defaultBundle;
		resource = defaultBundle;
	}

	@Override
	public String unitKg() {
		try {
			return resource.getString("UNIT_KG");
		} catch (Exception e) {
			return "!UNIT_KG!";
		}
	}

	@Override
	public String unitRadS() {
		try {
			return resource.getString("UNIT_rad_s");
		} catch (Exception e) {
			return "!UNIT_rad_s!";
		}
	}

	@Override
	public String unitS() {
		try {
			return resource.getString("UNIT_s");
		} catch (Exception e) {
			return "!UNIT_s!";
		}
	}

	@Override
	public String unitAmps() {
		try {
			return resource.getString("UNIT_Amps");
		} catch (Exception e) {
			return "!UNIT_Amps!";
		}
	}

	@Override
	public String unitSeconds() {
		try {
			return resource.getString("UNIT_seconds");
		} catch (Exception e) {
			return "!UNIT_seconds!";
		}
	}

	@Override
	public String unitInS() {
		try {
			return resource.getString("UNIT_in_s");
		} catch (Exception e) {
			return "!UNIT_in_s!";
		}
	}

	@Override
	public String unitKgMS() {
		try {
			return resource.getString("UNIT_kg_m_s");
		} catch (Exception e) {
			return "!UNIT_kg_m_s!";
		}
	}

	@Override
	public String unitMm() {
		try {
			return resource.getString("UNIT_MM");
		} catch (Exception e) {
			return "!UNIT_MM!";
		}
	}

	@Override
	public String unitMS2() {
		try {
			return resource.getString("UNIT_m_s2");
		} catch (Exception e) {
			return "!UNIT_m_s2!";
		}
	}

	@Override
	public String revolutions() {
		try {
			return resource.getString("revolutions");
		} catch (Exception e) {
			return "!revolutions!";
		}
	}

	@Override
	public String unitRad() {
		try {
			return resource.getString("UNIT_rad");
		} catch (Exception e) {
			return "!UNIT_rad!";
		}
	}

	@Override
	public String unitMs() {
		try {
			return resource.getString("UNIT_Ms");
		} catch (Exception e) {
			return "!UNIT_Ms!";
		}
	}

	@Override
	public String unitDegC() {
		try {
			return resource.getString("UNIT_DEG_C");
		} catch (Exception e) {
			return "!UNIT_DEG_C!";
		}
	}

	@Override
	public String unitDegF() {
		try {
			return resource.getString("UNIT_deg_F");
		} catch (Exception e) {
			return "!UNIT_deg_F!";
		}
	}

	@Override
	public String unitDegS2() {
		try {
			return resource.getString("UNIT_deg_s2");
		} catch (Exception e) {
			return "!UNIT_deg_s2!";
		}
	}

	@Override
	public String unitLbForce() {
		try {
			return resource.getString("UNIT_lb_force");
		} catch (Exception e) {
			return "!UNIT_lb_force!";
		}
	}

	@Override
	public String unitLbft() {
		try {
			return resource.getString("UNIT_lbft");
		} catch (Exception e) {
			return "!UNIT_lbft!";
		}
	}

	@Override
	public String unitLbInS() {
		try {
			return resource.getString("UNIT_lb_in_s");
		} catch (Exception e) {
			return "!UNIT_lb_in_s!";
		}
	}

	@Override
	public String unitV() {
		try {
			return resource.getString("UNIT_V");
		} catch (Exception e) {
			return "!UNIT_V!";
		}
	}

	@Override
	public String unitW() {
		try {
			return resource.getString("UNIT_W");
		} catch (Exception e) {
			return "!UNIT_W!";
		}
	}

	@Override
	public String unitDegrees() {
		try {
			return resource.getString("UNIT_degrees");
		} catch (Exception e) {
			return "!UNIT_degrees!";
		}
	}

	@Override
	public String unitLb() {
		try {
			return resource.getString("UNIT_lb");
		} catch (Exception e) {
			return "!UNIT_lb!";
		}
	}

	@Override
	public String unitN() {
		try {
			return resource.getString("UNIT_N");
		} catch (Exception e) {
			return "!UNIT_N!";
		}
	}

	@Override
	public String unitInS2() {
		try {
			return resource.getString("UNIT_in_s2");
		} catch (Exception e) {
			return "!UNIT_in_s2!";
		}
	}

	@Override
	public String unitM() {
		try {
			return resource.getString("UNIT_M");
		} catch (Exception e) {
			return "!UNIT_M!";
		}
	}

	@Override
	public String unitNm() {
		try {
			return resource.getString("UNIT_NM");
		} catch (Exception e) {
			return "!UNIT_NM!";
		}
	}

	@Override
	public String unitMS() {
		try {
			return resource.getString("UNIT_m_s");
		} catch (Exception e) {
			return "!UNIT_m_s!";
		}
	}

	@Override
	public String unitDegS() {
		try {
			return resource.getString("UNIT_deg_s");
		} catch (Exception e) {
			return "!UNIT_deg_s!";
		}
	}

	@Override
	public String unitMa() {
		try {
			return resource.getString("UNIT_mA");
		} catch (Exception e) {
			return "!UNIT_mA!";
		}
	}

	@Override
	public String unitIn() {
		try {
			return resource.getString("UNIT_in");
		} catch (Exception e) {
			return "!UNIT_in!";
		}
	}

	@Override
	public String unitMmS2() {
		try {
			return resource.getString("UNIT_MM_S2");
		} catch (Exception e) {
			return "!UNIT_MM_S2!";
		}
	}

	@Override
	public String unitVolts() {
		try {
			return resource.getString("UNIT_Volts");
		} catch (Exception e) {
			return "!UNIT_Volts!";
		}
	}

	@Override
	public String unitMmS() {
		try {
			return resource.getString("UNIT_MM_S");
		} catch (Exception e) {
			return "!UNIT_MM_S!";
		}
	}

	@Override
	public String unitA() {
		try {
			return resource.getString("UNIT_A");
		} catch (Exception e) {
			return "!UNIT_A!";
		}
	}

	/**
	 * Intended for use where the keyName is concatenated
	 * together, such as when using error codes from the controller
	 */
	@Override
	@Deprecated
	public String get(String key) {
		try {
			return resource.getString(key);
		} catch (Exception e) {
			return "!" + key + "!";
		}
	}

	@Override
	public boolean contains(String key) {
		return resource.containsKey(key);
	}

	/**
	 * Helper method to get all defined keys
	 */
	@Override
	public Iterable<String> getKeys() {
		return new IterableEnumerationWrapper<>(resource.getKeys());
	}

	public UnitsResource getDefaultLocale() {
		return new UnitsResourceImpl(defaultResource);
	}
}