package cn.elibot.robot.commons.lang.translation;

import cn.elibot.robot.commons.lang.UnitsUtils;
import cn.elibot.robot.commons.lang.resource.LocaleProvider;

import javax.inject.Inject;

/**
 * Resource support
 *
 * @author elt
 */
public class ResourceSupport {
    private static UnitsResource UNITS_RESOURCE;
    private static ImperialUnitsResourceImpl IMPERIAL_UNITS_RESOURCE;
    private static LocaleProvider provider;

    @Inject
    public static void setProvider(LocaleProvider provider) {
        ResourceSupport.provider = provider;
        init();
    }

    private static void init() {
        UNITS_RESOURCE = new UnitsResourceImpl(provider);
        IMPERIAL_UNITS_RESOURCE = new ImperialUnitsResourceImpl(provider);
    }

    /**
     * Get text resource
     *
     * @return a {@link UnitsResource} instance
     */
    public static UnitsResource textResource() {
        return UnitsUtils.getUnitType().isImperial() ? IMPERIAL_UNITS_RESOURCE : UNITS_RESOURCE;
    }
}
