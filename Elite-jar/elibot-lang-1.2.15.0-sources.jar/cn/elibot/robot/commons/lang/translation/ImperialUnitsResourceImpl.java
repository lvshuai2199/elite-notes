package cn.elibot.robot.commons.lang.translation;

import cn.elibot.robot.commons.lang.resource.LocaleProvider;

/**
 * @author shi
 */
public class ImperialUnitsResourceImpl extends UnitsResourceImpl {

    public ImperialUnitsResourceImpl(LocaleProvider provider) {
        super(provider);
    }

    @Override
    public String get(String key) {
        if ("UNIT_MM".equals(key)) {
            return this.unitIn();
        } else if ("UNIT_KG".equals(key)) {
            return this.unitLb();
        } else if ("UNIT_DEG_C".equals(key)) {
            return this.unitDegF();
        } else if ("UNIT_N".equals(key)) {
            return this.unitLbForce();
        } else if ("UNIT_NM".equals(key)) {
            return this.unitLbft();
        } else if ("UNIT_MM_S".equals(key)) {
            return this.unitInS();
        } else {
            return "UNIT_MM_S2".equals(key) ? this.unitInS2() : super.get(key);
        }
    }
}
