package cn.elibot.robot.commons.lang;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Stream utils
 *
 * @author elt
 */
public class StreamUtils {
    /**
     * Read string from stream
     *
     * @param stream      the stream object for reading
     * @param defaultText the default {@link String} value for returning
     * @return {@link String}
     */
    public static String readFromStream(InputStream stream, String defaultText) {
        String result;
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            String line = reader.readLine();
            while (line != null) {
                builder.append(line);

                line = reader.readLine();
                if (line == null) {
                    break;
                }

                builder.append("\n");
            }

            result = builder.toString();

            return result;
        } catch (IOException ex) {
            ex.printStackTrace();
            result = defaultText;
        } finally {
            IOUtils.closeQuietly(reader);
        }

        return result;
    }
}
