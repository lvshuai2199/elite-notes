package cn.elibot.robot.commons.lang.injection;

import com.google.inject.*;
import com.google.inject.util.Types;

import java.lang.annotation.Annotation;
import java.util.Set;

/**
 * Represents the service builder
 *
 * @author elt
 */
class GuiceServiceBuilder implements ServiceBuilder {
    private final Injector injector;

    public GuiceServiceBuilder(GuiceServiceBinder binder) {
        this.injector = Guice.createInjector(binder, new AbstractModule() {
            @Override
            protected void configure() {
                this.bind(ServiceBuilder.class).toInstance(GuiceServiceBuilder.this);
            }
        });
    }

    public GuiceServiceBuilder(GuiceServiceBinder binder, GuiceServiceBuilder parentBuilder) {
        this.injector = parentBuilder.injector.createChildInjector(binder);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> T get(Class<T> type) {
        return type.equals(Injector.class) ? (T) this.injector : this.injector.getInstance(type);
    }

    @Override
    public <T> T get(ServiceKey<T> type) {
        return this.injector.getInstance(Key.get(type.getTypeLiteral()));
    }

    @Override
    public <T> T get(ServiceKey<T> type, Annotation annotation) {
        Key<T> key = Key.get(type.getTypeLiteral(), annotation);

        return this.injector.getInstance(key);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> T get(Class<T> type, Annotation annotation) {
        if (type.equals(Injector.class)) {
            return (T) this.injector;
        }

        Key<T> key = Key.get(type, annotation);

        return this.injector.getInstance(key);
    }

    @Override
    public <T> T get(TypeLiteral<T> type, Annotation annotation) {
        Key<T> key = Key.get(type, annotation);

        return this.injector.getInstance(key);
    }

    @Override
    public <T> Set<T> getExtensions(Class<T> type) {
        return this.injector.getInstance(Key.get(this.setOf(type)));
    }

    @SuppressWarnings("unchecked")
    private <T> TypeLiteral<Set<T>> setOf(Class<T> type) {
        return (TypeLiteral<Set<T>>) TypeLiteral.get(Types.setOf(type));
    }

    @Override
    public void inject(Object service) {
        this.injector.injectMembers(service);
    }
}