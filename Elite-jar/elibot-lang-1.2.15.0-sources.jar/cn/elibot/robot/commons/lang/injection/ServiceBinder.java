package cn.elibot.robot.commons.lang.injection;

import javax.inject.Provider;
import java.lang.annotation.Annotation;

/**
 * Represents the service binder interface
 *
 * @author elt
 */
public interface ServiceBinder {
    /**
     * Bind the class to the type
     *
     * @param type  the binding type
     * @param clazz the binding class
     * @param <T>   the binding class type
     */
    <T> void bindClass(Class<T> type, Class<? extends T> clazz);

    /**
     * Bind the generic class to the type
     *
     * @param type  the binding type
     * @param clazz the binding class
     * @param <T>   the binding class type
     */
    <T> void bindClass(ServiceKey<T> type, Class<? extends T> clazz);

    /**
     * Bind the class to the type, when the specified binding relationship does not exist
     *
     * @param type  the binding type
     * @param clazz the binding class
     * @param <T>   the binding class type
     */
    <T> void bindClassIfAbsent(Class<T> type, Class<? extends T> clazz);

    /**
     * Bind the instance to the type
     *
     * @param type     the binding type
     * @param instance the binding instance
     * @param <T>      the binding class type
     */
    <T> void bindInstance(Class<T> type, T instance);

    /**
     * Bind the instance to the type
     *
     * @param type     the binding type
     * @param instance the binding instance
     * @param <T>      the binding class type
     */
    <T> void bindInstance(ServiceKey<T> type, T instance);

    /**
     * Bind the instance to the type with annotation
     *
     * @param type           the binding type
     * @param instance       the binding instance
     * @param annotationType the binding qualifier
     * @param <T>            the binding class type
     */
    <T> void bindInstanceWithQualifier(Class<T> type, T instance, Class<? extends Annotation> annotationType);

    /**
     * Bind the instance to the type with annotation
     *
     * @param type           the binding type
     * @param instance       the binding instance
     * @param annotationType the binding qualifier
     * @param <T>            the binding class type
     */
    <T> void bindInstanceWithQualifier(ServiceKey<T> type, T instance, Class<? extends Annotation> annotationType);

    /**
     * Bind the instance to the type with annotation
     *
     * @param type       the binding type
     * @param instance   the binding instance
     * @param annotation the binding qualifier
     * @param <T>        the binding class type
     */
    <T> void bindInstanceWithQualifier(ServiceKey<T> type, T instance, Annotation annotation);

    /**
     * Bind the class to the type with annotation
     *
     * @param type           the binding type
     * @param clazz          the binding class
     * @param annotationType the binding qualifier
     * @param <T>            the binding class type
     */
    <T> void bindClassWithQualifier(Class<T> type, Class<? extends T> clazz, Class<? extends Annotation> annotationType);

    /**
     * Bind the class to the type with annotation
     *
     * @param type           the binding type
     * @param clazz          the binding class
     * @param annotationType the binding qualifier
     * @param <T>            the binding class type
     */
    <T> void bindClassWithQualifier(ServiceKey<T> type, Class<? extends T> clazz, Class<? extends Annotation> annotationType);

    /**
     * Bind multi class to the type
     *
     * @param type  the binding extension point type
     * @param clazz the binding extension point class
     * @param <T>   the binding extension point class type
     */
    <T> void bindMultiClass(Class<T> type, Class<? extends T> clazz);

    /**
     * Bind multi instance to the type
     *
     * @param type     the binding extension point type
     * @param instance the binding extension point instance
     * @param <T>      the binding extension point class type
     */
    <T> void bindMultiInstance(Class<T> type, T instance);

    /**
     * Bind the extension point class to the type
     *
     * @param type  the binding extension point type
     * @param clazz the binding extension point class
     * @param <T>   the binding extension point class type
     */
    <T> void bindToExtensionPoint(Class<T> type, Class<? extends T> clazz);

    /**
     * Bind the extension point instance to the type
     *
     * @param type     the binding extension point type
     * @param instance the binding extension point instance
     * @param <T>      the binding extension point class type
     */
    <T> void bindToExtensionPoint(Class<T> type, T instance);

    /**
     * Bind the extension point class to the type with the key
     *
     * @param key   the binding extension point key
     * @param type  the binding extension point type
     * @param clazz the binding extension point class
     * @param <T>   the binding extension point class type
     */
    <T> void bindKeyToExtensionPoint(Object key, Class<T> type, Class<? extends T> clazz);

    /**
     * Bind the extension point class to the type with the key
     *
     * @param key   the binding extension point key
     * @param type  the binding extension point type
     * @param clazz the binding extension point class
     * @param <T>   the binding extension point class type
     */
    <T> void bindKeyToExtensionPoint(Enum<?> key, Class<T> type, Class<? extends T> clazz);

    /**
     * Bind the service provider to the type
     *
     * @param type     the binding type
     * @param provider the provider of service
     * @param <T>      the service type
     */
    <T> void bindProvider(Class<T> type, Provider<T> provider);

    /**
     * Bind the service provider to the type
     *
     * @param type           the binding type
     * @param provider       the provider of service
     * @param annotationType the annotation class of the binding service
     * @param <T>            the service type
     */
    <T> void bindProvider(Class<T> type, Provider<T> provider, Class<? extends Annotation> annotationType);

    /**
     * Bind the service provider class to the type
     *
     * @param type          the binding type
     * @param providerClazz the provider class of service
     * @param <T>           the service type
     */
    <T> void bindProvider(Class<T> type, Class<? extends Provider<T>> providerClazz);

    /**
     * Bind the service provider class to the type
     *
     * @param type           the binding type
     * @param providerClazz  the provider class of service
     * @param annotationType the annotation class of the binding service
     * @param <T>            the service type
     */
    <T> void bindProvider(Class<T> type, Class<? extends Provider<T>> providerClazz, Class<? extends Annotation> annotationType);

    /**
     * Bind the service provider class to the type
     *
     * @param type          the binding type
     * @param providerClazz the provider class of service
     * @param <T>           the service type
     */
    <T> void bindProvider(ServiceKey<T> type, Class<? extends Provider<? extends T>> providerClazz);

    /**
     * Bind the service provider class to the type
     *
     * @param type           the binding type
     * @param providerClazz  the provider class of service
     * @param annotationType the annotation class of the binding service
     * @param <T>            the service type
     */
    <T> void bindProvider(ServiceKey<T> type, Class<? extends Provider<? extends T>> providerClazz, Class<? extends Annotation> annotationType);

    /**
     * Bind the service provider class to the type with annotation class
     *
     * @param type           the binding type
     * @param providerClazz  the provider class of service
     * @param annotationType the annotation class of the binding service
     * @param <T>            the service type
     */
    <T> void bindProviderWithQualifier(Class<T> type, Class<? extends Provider<T>> providerClazz, Class<? extends Annotation> annotationType);

    /**
     * Upon successful creation, the {@link ServiceBinder} will inject static fields and methods in the
     * given class.
     *
     * @param type for which static members will be injected
     * @param <T>  the service type
     */
    <T> void requestStaticBinding(Class<T> type);

    /**
     * Upon the dependency service has ready, the {@link ServiceBinder} will inject fields and methods in the
     * given class.
     *
     * @param instance for which members will be injected
     * @param <T>      the service type
     * @return oneself which members has been injected
     */
    <T> T injectWhenReady(T instance);

}
