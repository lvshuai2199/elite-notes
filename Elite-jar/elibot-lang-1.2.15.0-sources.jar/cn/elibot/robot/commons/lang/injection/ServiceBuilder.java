package cn.elibot.robot.commons.lang.injection;

import com.google.inject.TypeLiteral;

import java.lang.annotation.Annotation;
import java.util.Set;

/**
 * The binding builder interface service
 *
 * @author elt
 */
public interface ServiceBuilder {
    /**
     * Return the binding type instance.
     *
     * @param type the binding type
     * @param <T>  the binding class type
     * @return the binding type instance
     */
    <T> T get(Class<T> type);

    /**
     * Return the binding type instance.
     *
     * @param type the binding class wrapped type
     * @param <T>  the binding class type
     * @return the binding class instance
     */
    <T> T get(ServiceKey<T> type);

    /**
     * Return the binding type instance.
     *
     * @param type       the binding class wrapped type
     * @param annotation the binding annotation
     * @param <T>        the binding class type
     * @return the binding class instance
     */
    <T> T get(ServiceKey<T> type, Annotation annotation);

    /**
     * Return the instance by the binding type and annotation
     *
     * @param type       the binding type
     * @param annotation the binding annotation
     * @param <T>        the binding class type
     * @return the binding class instance
     */
    <T> T get(Class<T> type, Annotation annotation);

    /**
     * Return the binding type instance.
     *
     * @param type       the binding class wrapped type
     * @param annotation the binding annotation
     * @param <T>        the binding class type
     * @return the binding class instance
     */
    <T> T get(TypeLiteral<T> type, Annotation annotation);

    /**
     * Return the extensions by the binding type
     *
     * @param type the binding extension type
     * @param <T>  the extension class type
     * @return the extensions
     */
    <T> Set<T> getExtensions(Class<T> type);

    /**
     * Upon successful creation, the {@link ServiceBinder} will inject instance fields and methods of the
     * given object.
     *
     * @param instance for which members will be injected
     */
    void inject(Object instance);
}
