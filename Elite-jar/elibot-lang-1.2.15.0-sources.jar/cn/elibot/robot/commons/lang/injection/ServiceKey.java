package cn.elibot.robot.commons.lang.injection;

import com.google.inject.TypeLiteral;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

/**
 * Service Key
 *
 * @author elt
 */
public class ServiceKey<T> {
    private static Method fromSuperclassTypeParameterMethod;

    static {
        fromSuperclassTypeParameterMethod = findMethod();
    }

    TypeLiteral<T> typeLiteral;

    protected ServiceKey() {
        typeLiteral = MoreTypes.canonicalizeForKey(Objects.requireNonNull(newTypeLiteral(getClass())));
    }

    private static Method findMethod() {
        Optional<Method> result = Arrays.stream(TypeLiteral.class.getDeclaredMethods())
                .filter(method -> "fromSuperclassTypeParameter".equals(method.getName()))
                .findAny();

        return result.orElse(null);
    }

    TypeLiteral<T> getTypeLiteral() {
        return typeLiteral;
    }

    @SuppressWarnings("unchecked")
    private TypeLiteral<T> newTypeLiteral(Class<?> subClass) {
        try {
            Method method = fromSuperclassTypeParameterMethod;
            if (method == null) {
                return null;
            }

            method.setAccessible(true);
            return (TypeLiteral<T>) method.invoke(null, subClass);
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
        return null;
    }
}
