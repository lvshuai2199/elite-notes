package cn.elibot.robot.commons.lang.injection;

import cn.elibot.robot.commons.lang.ClassUtils;
import cn.elibot.robot.commons.lang.annotation.HasKey;
import cn.elibot.robot.commons.lang.exception.ServiceBindException;
import com.google.inject.AbstractModule;
import com.google.inject.Module;
import com.google.inject.multibindings.MapBinder;
import com.google.inject.multibindings.Multibinder;
import com.google.inject.name.Names;

import javax.inject.Provider;
import javax.inject.Qualifier;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Represents the service binder
 *
 * @author elt
 */
public class GuiceServiceBinder extends AbstractModule implements ServiceBinder {
    private final List<Object> objectsToBeInjected = new ArrayList<>();
    private final List<Module> toInstall = new ArrayList<>();
    private final List<BindIfAbsent<?>> bindIfAbsent = new ArrayList<>();
    private List<ServiceModule> modules;
    private Map<String, Class<?>> boundClass = new HashMap<>();

    public GuiceServiceBinder(List<ServiceModule> modules) {
        this.modules = modules;
    }

    @Override
    public <T> void bindClass(Class<T> type, Class<? extends T> clazz) {
        this.validateInterface(type);

        try {
            HasKey annotation = clazz.getAnnotation(HasKey.class);
            String value = annotation.value();
            this.bind(type).annotatedWith(Names.named(value)).to(clazz);
        } catch (Exception ex) {
            this.bind(type).to(clazz);
        }
    }

    @Override
    public <T> void bindClass(ServiceKey<T> type, Class<? extends T> clazz) {
        try {
            HasKey annotation = clazz.getAnnotation(HasKey.class);
            String value = annotation.value();
            this.bind(type.getTypeLiteral()).annotatedWith(Names.named(value)).to(clazz);
        } catch (Exception ex) {
            this.bind(type.getTypeLiteral()).to(clazz);
        }
    }

    @Override
    public <T> void bindClassIfAbsent(Class<T> type, Class<? extends T> clazz) {
        this.bindIfAbsent.add(new BindIfAbsent<>(type, clazz));
    }

    @Override
    public <T> void bindInstance(Class<T> type, T instance) {
        this.validateInterface(type);

        try {
            HasKey annotation = instance.getClass().getAnnotation(HasKey.class);
            String value = annotation.value();
            this.bind(type).annotatedWith(Names.named(value)).toInstance(instance);
        } catch (Exception ex) {
            this.bind(type).toInstance(instance);
        }
    }

    @Override
    public <T> void bindInstance(ServiceKey<T> type, T instance) {
        try {
            HasKey annotation = instance.getClass().getAnnotation(HasKey.class);
            String value = annotation.value();
            this.bind(type.getTypeLiteral()).annotatedWith(Names.named(value)).toInstance(instance);
        } catch (Exception ex) {
            this.bind(type.getTypeLiteral()).toInstance(instance);
        }
    }

    @Override
    public <T> void bindInstanceWithQualifier(Class<T> type, T instance, Class<? extends Annotation> annotationType) {
        this.validateInterface(type);

        try {
            this.bind(type).annotatedWith(annotationType).toInstance(instance);
        } catch (Exception ex) {
            this.bind(type).toInstance(instance);
        }
    }

    @Override
    public <T> void bindInstanceWithQualifier(ServiceKey<T> type, T instance, Class<? extends Annotation> annotationType) {
        try {
            this.bind(type.getTypeLiteral()).annotatedWith(annotationType).toInstance(instance);
        } catch (Exception ex) {
            this.bind(type.getTypeLiteral()).toInstance(instance);
        }
    }

    @Override
    public <T> void bindInstanceWithQualifier(ServiceKey<T> type, T instance, Annotation annotation) {
        try {
            this.bind(type.getTypeLiteral()).annotatedWith(annotation).toInstance(instance);
        } catch (Exception ex) {
            this.bind(type.getTypeLiteral()).toInstance(instance);
        }
    }

    @Override
    public <T> void bindClassWithQualifier(Class<T> type, Class<? extends T> clazz, Class<? extends Annotation> annotationType) {
        this.validateInterface(type);

        try {
            this.bind(type).annotatedWith(annotationType).to(clazz);
        } catch (Exception ex) {
            this.bind(type).to(clazz);
        }
    }

    @Override
    public <T> void bindClassWithQualifier(ServiceKey<T> type, Class<? extends T> clazz, Class<? extends Annotation> annotationType) {
        try {
            this.bind(type.getTypeLiteral()).annotatedWith(annotationType).to(clazz);
        } catch (Exception ex) {
            this.bind(type.getTypeLiteral()).to(clazz);
        }
    }

    @Override
    public <T> void bindMultiClass(Class<T> type, Class<? extends T> clazz) {
        this.validateInterface(type);

        try {
            HasKey annotation = clazz.getAnnotation(HasKey.class);
            String value = annotation.value();

            Multibinder<T> uriBinder = Multibinder.newSetBinder(this.binder(), type, Names.named(value));
            uriBinder.addBinding().to(clazz);
        } catch (Exception ex) {
            Multibinder<T> uriBinder = Multibinder.newSetBinder(this.binder(), type);
            uriBinder.addBinding().to(clazz);
        }
    }

    @Override
    public <T> void bindMultiInstance(Class<T> type, T instance) {
        this.validateInterface(type);

        try {
            HasKey annotation = instance.getClass().getAnnotation(HasKey.class);
            String value = annotation.value();

            Multibinder<T> uriBinder = Multibinder.newSetBinder(this.binder(), type, Names.named(value));
            uriBinder.addBinding().toInstance(instance);
        } catch (Exception ex) {
            Multibinder<T> uriBinder = Multibinder.newSetBinder(this.binder(), type);
            uriBinder.addBinding().toInstance(instance);
        }
    }

    @Override
    public <T> void bindToExtensionPoint(Class<T> type, Class<? extends T> clazz) {
        this.validateInterface(type);

        try {
            HasKey annotation = clazz.getAnnotation(HasKey.class);
            String value = annotation.value();

            Multibinder<T> uriBinder = Multibinder.newSetBinder(this.binder(), type, Names.named(value));
            uriBinder.addBinding().to(clazz);
        } catch (Exception ex) {
            Multibinder<T> uriBinder = Multibinder.newSetBinder(this.binder(), type);
            uriBinder.addBinding().to(clazz);
        }
    }

    @Override
    public <T> void bindToExtensionPoint(Class<T> type, T instance) {
        this.validateInterface(type);

        try {
            HasKey annotation = instance.getClass().getAnnotation(HasKey.class);
            String value = annotation.value();

            Multibinder<T> uriBinder = Multibinder.newSetBinder(this.binder(), type, Names.named(value));
            uriBinder.addBinding().toInstance(instance);
        } catch (Exception ex) {
            Multibinder<T> uriBinder = Multibinder.newSetBinder(this.binder(), type);
            uriBinder.addBinding().toInstance(instance);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> void bindKeyToExtensionPoint(Object key, Class<T> type, Class<? extends T> clazz) {
        this.validateInterface(type);
        MapBinder<Object, T> mapBinder = MapBinder.newMapBinder(this.binder(), (Class<Object>) key.getClass(), type);
        mapBinder.addBinding(key).to(clazz);
    }

    @Override
    public <T> void bindKeyToExtensionPoint(Enum<?> key, Class<T> type, Class<? extends T> clazz) {
        this.bindKeyToExtensionPoint((Object) key, type, clazz);
    }

    @Override
    public <T> void bindProvider(Class<T> type, Provider<T> provider) {
        this.validateInterface(type);

        Annotation[] annotations = provider.getClass().getDeclaredAnnotations();
        for (Annotation annotation : annotations) {
            if (annotation.annotationType().isAnnotationPresent(Qualifier.class)) {
                this.bind(type).annotatedWith(annotation).toProvider(provider::get);
                return;
            }
        }

        this.bind(type).toProvider(provider::get);
    }

    @Override
    public <T> void bindProvider(Class<T> type, Provider<T> provider, Class<? extends Annotation> annotationType) {
        if (annotationType != null) {
            this.bind(type).annotatedWith(annotationType).toProvider(provider::get);
        } else {
            this.bind(type).toProvider(provider::get);
        }
    }

    private void bindProvider(Class<?> type, Class<?> providerClazz, Consumer<Annotation> consumer) {
        Annotation[] annotations = providerClazz.getDeclaredAnnotations();
        for (Annotation annotation : annotations) {
            if (annotation.annotationType().isAnnotationPresent(Qualifier.class)) {
                consumer.accept(annotation);
                return;
            }
        }

        consumer.accept(null);
    }

    @Override
    public <T> void bindProvider(Class<T> type, Class<? extends Provider<T>> providerClazz) {
        this.bindProvider(type, providerClazz, annotation -> {
            if (annotation != null) {
                this.bind(type).annotatedWith(annotation).toProvider(providerClazz);
            } else {
                this.bind(type).toProvider(providerClazz);
            }
        });
    }

    @Override
    public <T> void bindProvider(Class<T> type, Class<? extends Provider<T>> providerClazz, Class<? extends Annotation> annotationType) {
        if (annotationType != null) {
            this.bind(type).annotatedWith(annotationType).toProvider(providerClazz);
        } else {
            this.bind(type).toProvider(providerClazz);
        }
    }

    @Override
    public <T> void bindProvider(ServiceKey<T> type, Class<? extends Provider<? extends T>> providerClazz) {
        this.bindProvider(type.getClass(), providerClazz, annotation -> {
            if (annotation != null) {
                this.bind(type.getTypeLiteral()).annotatedWith(annotation).toProvider(providerClazz);
            } else {
                this.bind(type.getTypeLiteral()).toProvider(providerClazz);
            }
        });
    }

    @Override
    public <T> void bindProvider(ServiceKey<T> type, Class<? extends Provider<? extends T>> providerClazz, Class<? extends Annotation> annotationType) {
        if (annotationType != null) {
            this.bind(type.getTypeLiteral()).annotatedWith(annotationType).toProvider(providerClazz);
        } else {
            this.bind(type.getTypeLiteral()).toProvider(providerClazz);
        }
    }

    @Override
    public <T> void bindProviderWithQualifier(Class<T> type, Class<? extends Provider<T>> providerClazz, Class<? extends Annotation> annotationType) {
        this.bind(type).annotatedWith(annotationType).toProvider(providerClazz);
    }

    @Override
    public <T> void requestStaticBinding(Class<T> type) {
        this.requestStaticInjection(type);
    }

    @Override
    public <T> T injectWhenReady(T instance) {
        this.objectsToBeInjected.add(instance);
        return instance;
    }

    /**
     * Validate interface
     *
     * @param serviceInterface the service interface
     * @param <T>              the service type
     */
    private <T> void validateInterface(Class<T> serviceInterface) {
        if (this.boundClass.containsKey(serviceInterface.getName())
                && this.boundClass.get(serviceInterface.getName()) != serviceInterface) {
            throw new ServiceBindException(serviceInterface);
        } else {
            this.boundClass.put(serviceInterface.getName(), serviceInterface);
        }
    }

    @Override
    public void install(Module binder) {
        this.toInstall.add(binder);
    }

    @Override
    protected void configure() {
        this.modules.forEach(binder -> binder.bind(this));
        this.bindIfAbsent
                .stream()
                .filter(it -> !this.boundClass.containsKey(it.getType().getName()))
                .forEach(it -> this.bindClass(ClassUtils.<Class<Object>>cast(it.getType()), it.getClazz()));
        this.objectsToBeInjected.forEach(this::requestInjection);
        this.toInstall.forEach(this::install);
    }

    private static class BindIfAbsent<T> {
        private final Class<T> type;
        private final Class<? extends T> clazz;

        BindIfAbsent(Class<T> type, Class<? extends T> clazz) {
            this.type = type;
            this.clazz = clazz;
        }

        public Class<T> getType() {
            return type;
        }

        public Class<? extends T> getClazz() {
            return clazz;
        }
    }
}
