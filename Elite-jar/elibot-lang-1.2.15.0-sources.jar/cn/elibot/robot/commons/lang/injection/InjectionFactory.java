package cn.elibot.robot.commons.lang.injection;

import cn.elibot.robot.commons.lang.exception.ServiceBindException;
import com.google.inject.CreationException;

import java.util.ArrayList;
import java.util.List;

/**
 * Inject factory
 *
 * @author elt
 */
public class InjectionFactory {
    /**
     * Create service module aggregator instance
     *
     * @param builder service builder
     * @return a {@link ModuleAggregator} instance
     */
    public static ModuleAggregator createModuleAggregator(ServiceBuilder builder) {
        return new ModuleAggregator(builder);
    }

    /**
     * Create service module aggregator instance
     *
     * @return a {@link ModuleAggregator} instance
     */
    public static ModuleAggregator createModuleAggregator() {
        return new ModuleAggregator();
    }

    /**
     * Service module aggregator
     */
    public static class ModuleAggregator {
        private List<ServiceModule> modules;
        private ServiceBuilder parent;

        ModuleAggregator() {
            this((ServiceBuilder) null);
        }

        ModuleAggregator(ServiceBuilder parent) {
            this.modules = new ArrayList<>();
            this.parent = parent;
        }

        public void add(ServiceModule binder) {
            this.modules.add(binder);
        }

        public ServiceBuilder createBuilder() {
            GuiceServiceBinder binder = new GuiceServiceBinder(this.modules);

            GuiceServiceBuilder builder;
            try {
                builder = this.parent == null ? new GuiceServiceBuilder(binder) : new GuiceServiceBuilder(binder, (GuiceServiceBuilder) this.parent);
            } catch (CreationException ex) {
                if (ex.getCause() instanceof ServiceBindException) {
                    throw (ServiceBindException) ex.getCause();
                }

                throw ex;
            }

            return builder;
        }
    }
}
