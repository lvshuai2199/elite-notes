package cn.elibot.robot.commons.lang.injection;

/**
 * The services binder
 *
 * @author elt
 */
public interface ServiceModule {
    /**
     * Bind services
     *
     * @param binder the service binder
     */
    void bind(ServiceBinder binder);

    /**
     * Load services
     *
     * @param builder the service builder
     */
    default void load(ServiceBuilder builder) {

    }
}
