package cn.elibot.robot.commons.lang;

import java.util.Arrays;

/**
 * Static utility methods pertaining to {@code Defense} instances.
 *
 * @author elt
 * @since 1.0
 */
public final class Defense {
    private Defense() {
    }

    public static <T> T isNull(T subject) {
        return isNull(subject, "Expect subject of type %class% to be null");
    }

    public static <T> T isNull(T subject, String message) {
        if (subject != null) {
            throw new DefenseCheckException(subject, message);
        }

        return null;
    }

    public static <T> T notNull(T subject) {
        return notNull(subject, "Expect subject to NOT be null");
    }

    public static <T> T notNull(T subject, String message) {
        if (subject == null) {
            throw new DefenseCheckException(null, message);
        }

        return subject;
    }

    public static String notNullOrEmpty(String subject) {
        return notNullOrEmpty(subject, "String cannot be empty");
    }

    public static String notNullOrEmpty(String sub, String mes) {
        notNull(sub, mes);
        isNotEmpty(sub, mes);
        return sub;
    }

    public static <T> T isLength(T subject, int expectedLength) {
        int actualLength = ArrayUtils.sizeOf(subject);
        if (actualLength != expectedLength) {
            throw new DefenseCheckException(subject, "Expected %class% to have length " + expectedLength + ", but was " + actualLength);
        }

        return subject;
    }

    public static <T> T isLength(T subject, int expectedLength, String message) {
        if (ArrayUtils.sizeOf(subject) != expectedLength) {
            throw new DefenseCheckException(subject, message);
        }

        return subject;
    }

    public static void sameLength(Object first, Object second, String message) {
        if (ArrayUtils.sizeOf(first) != ArrayUtils.sizeOf(second)) {
            throw new DefenseCheckException(first, message);
        }
    }

    @SafeVarargs
    public static <T> T isOneOf(T subject, T... options) {
        for (T each : options) {
            if (subject.equals(each)) {
                return subject;
            }
        }

        throw new DefenseCheckException(subject, "Expected subject [%instance%] to be contained in " + Arrays.toString(options) + ", but no match found.");
    }

    public static <T> T isNotEmpty(T subject, String message) {
        if (ArrayUtils.sizeOf(subject) <= 0) {
            throw new DefenseCheckException(subject, message);
        }

        return subject;
    }

    public static <T> T isInstanceOf(T subject, Class<?> expectedTypeOfSubject) {
        return isInstanceOf(subject, expectedTypeOfSubject, "Expected subject [%instance%] to be of type " + expectedTypeOfSubject.getName() + ", but was %class%");
    }

    public static <T> T isInstanceOf(T subject, Class<?> exTypeOfSubject, String message) {
        notNull(subject);
        if (!exTypeOfSubject.isInstance(subject)) {
            throw new DefenseCheckException(subject, message);
        } else {
            return subject;
        }
    }

    public static void isCondition(boolean condition, String message) {
        if (!condition) {
            throw new DefenseCheckException(message);
        }
    }

    public static final class DefenseCheckException extends AssertionError {
        private final String message;

        public DefenseCheckException(Object subject, String message) {
            message = message.replaceAll("%instance%", StringUtils.toString(subject));
            message = message.replaceAll("%class%", ClassUtils.getClassName(subject));
            this.message = message;
        }

        public DefenseCheckException(String message) {
            this.message = message;
        }

        @Override
        public String getMessage() {
            return this.message;
        }
    }
}