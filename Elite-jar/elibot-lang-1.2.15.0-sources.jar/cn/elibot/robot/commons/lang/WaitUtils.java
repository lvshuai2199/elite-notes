package cn.elibot.robot.commons.lang;

import cn.elibot.robot.commons.lang.thread.ThreadPoolUtils;

import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

/**
 * Waiting utility
 *
 * @author elt
 */
public class WaitUtils {
    private WaitUtils() {
    }

    public static void pause(long time, TimeUnit unit) {
        try {
            Thread.sleep(unit.toMillis(time));
        } catch (InterruptedException ignored) {
        }
    }
    public static void pause(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException ignored) {
        }
    }

    public static boolean until(WaitUtils.ItHappens itHappens, int timeout, TimeUnit unit) {
        return (new WaitUtils.Waiter(itHappens)).waitFor(unit.toMillis(timeout));
    }

    public static boolean until(WaitUtils.ItHappens itHappens, int timeout, int period, TimeUnit unit) {
        return (new WaitUtils.Waiter(itHappens, unit.toMillis(period))).waitFor(unit.toMillis(timeout));
    }

    public static WaitUtils.ItHappens negationOf(WaitUtils.ItHappens itHappens) {
        return new WaitUtils.NegationOf(itHappens);
    }

    public static <T> WaitUtils.ItHappens given(final T subject, final Predicate<T> hasCondition) {
        return () -> hasCondition.test(subject);
    }

    public interface ItHappens {
        /**
         * Return {@code true} if the something happen
         *
         * @return {@code true} if the something happen
         */
        boolean itHappened();
    }

    private static final class Waiter {
        private final WaitUtils.ItHappens ih;
        private final Object lock;
        private boolean finished;
        private long period = 10L;

        public Waiter(WaitUtils.ItHappens ih) {
            this.ih = ih;
            this.lock = new Object();
        }

        public Waiter(WaitUtils.ItHappens ih, long period) {
            this.ih = ih;
            this.lock = new Object();
            this.period = period;
        }

        boolean waitFor(long timeout) {
            final boolean[] didItHappen = new boolean[]{false};
            Executor executor = ThreadPoolUtils.newCachedThreadPool("wait_thread");

            try {
                synchronized (this.lock) {
                    executor.execute(() -> {
                        while (!Waiter.this.finished) {
                            WaitUtils.pause((int) Waiter.this.period, TimeUnit.MILLISECONDS);
                            didItHappen[0] = Waiter.this.ih.itHappened();
                            if (didItHappen[0]) {
                                Waiter.this.finished = true;
                            }
                        }

                        synchronized (Waiter.this.lock) {
                            Waiter.this.lock.notify();
                        }
                    });

                    this.lock.wait(timeout);
                }
            } catch (InterruptedException exception) {
                this.finished = true;
                return false;
            }

            this.finished = true;
            return didItHappen[0];
        }
    }

    public static final class NegationOf implements WaitUtils.ItHappens {
        WaitUtils.ItHappens eventToNegate;

        public NegationOf(WaitUtils.ItHappens eventToNegate) {
            this.eventToNegate = eventToNegate;
        }

        @Override
        public boolean itHappened() {
            return !this.eventToNegate.itHappened();
        }
    }
}
