package cn.elibot.robot.commons.lang.resource;


import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * @author shi
 */
public class ImageIconWrapper extends ImageIcon {
    private final String name;
    private final String fullPath;

    public ImageIconWrapper(String fullPath, BufferedImage image) {
        super(image);
        this.name = fullPath.substring(fullPath.lastIndexOf(File.separator) + 1);
        this.fullPath = fullPath;
    }

    @Override
    public String getDescription() {
        return this.fullPath;
    }

    @Override
    public String toString() {
        return "ImageIcon '" + this.name + "'";
    }
}
