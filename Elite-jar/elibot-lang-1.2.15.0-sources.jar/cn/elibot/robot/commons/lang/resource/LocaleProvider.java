package cn.elibot.robot.commons.lang.resource;

import java.util.Locale;

/**
 * @author shi
 */
public interface LocaleProvider {
    /**
     * getLocale
     *
     * @return Locale
     */
    Locale getLocale();
}
