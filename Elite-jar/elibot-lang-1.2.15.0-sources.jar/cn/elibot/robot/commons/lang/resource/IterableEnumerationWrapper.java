package cn.elibot.robot.commons.lang.resource;

import java.util.Enumeration;
import java.util.Iterator;

/**
 * @author shi
 */
public class IterableEnumerationWrapper<T> implements Iterable<T> {
    private final Enumeration<T> enumeration;

    public IterableEnumerationWrapper(Enumeration<T> enumeration) {
        this.enumeration = enumeration;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            @Override
            public boolean hasNext() {
                return IterableEnumerationWrapper.this.enumeration.hasMoreElements();
            }

            @Override
            public T next() {
                return IterableEnumerationWrapper.this.enumeration.nextElement();
            }

            @Override
            public void remove() {
                throw new IllegalStateException("Enumerations do not support this function, therefore this Iterable which WRAPS one doesn't either!!!");
            }
        };
    }
}
