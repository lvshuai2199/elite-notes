package cn.elibot.robot.commons.lang.resource;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PushbackInputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.ResourceBundle.Control;

/**
 * @author shi
 */
public class UTF8Control extends Control {
    private static final byte BOM_FIRST = -17;
    private static final byte BOM_SECOND = -69;
    private static final byte BOM_LAST = -65;


    @Override
    public ResourceBundle newBundle(String baseName, Locale locale, String format, ClassLoader loader, boolean reload) throws IOException {
        String bundleName = this.toBundleName(baseName, locale);
        String resourceName = this.toResourceName(bundleName, "properties");

        ResourceBundle bundle;
        try (PushbackInputStream stream = new PushbackInputStream(this.getInputStream(loader, reload, resourceName), 3)) {
            byte[] bom = new byte[3];
            int size = stream.read(bom, 0, 3);
            if (size == 3 && (bom[0] != BOM_FIRST || bom[1] != BOM_SECOND || bom[2] != BOM_LAST)) {
                stream.unread(bom[2]);
                stream.unread(bom[1]);
                stream.unread(bom[0]);
            }

            bundle = new PropertyResourceBundle(new InputStreamReader(stream, StandardCharsets.UTF_8));
        }

        return bundle;
    }

    private InputStream getInputStream(ClassLoader loader, boolean reload, String resourceName) throws IOException {
        InputStream stream = null;
        if (reload) {
            URL url = loader.getResource(resourceName);
            if (url != null) {
                URLConnection connection = url.openConnection();
                if (connection != null) {
                    connection.setUseCaches(false);
                    stream = connection.getInputStream();
                }
            }
        } else {
            stream = loader.getResourceAsStream(resourceName);
        }

        return stream;
    }
}
