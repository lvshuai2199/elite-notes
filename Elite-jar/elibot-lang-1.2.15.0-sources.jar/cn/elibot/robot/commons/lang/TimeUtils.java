package cn.elibot.robot.commons.lang;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility class for handling time-related operations.
 * Provides methods for converting time formats between UTC and China time zones.
 *
 * @author ELITECO SDK API
 * @since ELITECO SDK 1.2.13.0
 */
public class TimeUtils {

    /**
     * DateTimeFormatter for UTC time format.
     * Format: "yyyy-MM-dd'T'HH:mm:ss'Z'"
     */
    public static final DateTimeFormatter TIME_FORMAT_FOR_UTC = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");

    /**
     * DateTimeFormatter for China time format.
     * Format: "yyyy-MM-dd HH:mm:ss"
     */
    public static final DateTimeFormatter TIME_FORMAT_FOR_CHINA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Converts a timestamp from UTC format to China time format.
     *
     * @param timestampUTC the timestamp in UTC format
     * @return the timestamp in China time format, or the original timestamp if parsing fails
     */
    public static String conversionTimeFormat(String timestampUTC) {
        try {
            LocalDateTime dateUTC = LocalDateTime.parse(timestampUTC, TIME_FORMAT_FOR_UTC);
            ZonedDateTime dateZoneForUTC = ZonedDateTime.of(dateUTC, ZoneId.of("GMT"));
            return TIME_FORMAT_FOR_CHINA.format(dateZoneForUTC.withZoneSameInstant(ZoneId.of("Asia/Shanghai")));
        } catch (Exception ignore) {
            return timestampUTC;
        }
    }
}